(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.Group = function() {
	this.initialize(img.Group);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1053,1053);


(lib.Group_1 = function() {
	this.initialize(img.Group_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,287);


(lib.Group_0 = function() {
	this.initialize(img.Group_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,591,96);


(lib.Group_1_1 = function() {
	this.initialize(img.Group_1_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,590,190);


(lib.Image = function() {
	this.initialize(img.Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,388,586);


(lib.Artboard1 = function() {
	this.initialize(img.Artboard1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2048,1536);


(lib.Artboard5 = function() {
	this.initialize(img.Artboard5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2048,1536);


(lib.Artboard3 = function() {
	this.initialize(img.Artboard3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2048,1536);


(lib.lite_bg = function() {
	this.initialize(img.lite_bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2048,1536);


(lib.ribbon = function() {
	this.initialize(img.ribbon);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3487,1111);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AvgSDQg8AAgqgTQgpgSgbggQgcgegMgoIgNhQIALhQQALgoAbgfQAcgfArgTQArgUA8AAIfBAAQA7AAArAUQAsATAbAfQAbAfAMAoIALBQIgNBQQgMAogcAeQgbAggqASQgqATg7AAgAwwEdQhPg1gOhcQgMhWAuhGQAthHBhgRQCEgUB8g1QB+g2BjhOQBhhQBBhnQBAhnAKh3IpzAAQg8AAgngTQgpgVgcgeQgbgggLgmIgNhPIANhNQAMgnAZghQAaggArgUQAogUA8AAIcHAAQA8AAApAUQApAUAbAgQAZAhAMAnIANBNIgNBPQgMAmgbAgQgcAegpAVQgpATg5AAIp7AAIgJBjIgUBbIAbAAQCkAACbA0QCdA0B9BqQB7BoBQCgQBPCfANDXIn/AAQgmjcidh1Qidh3jlAAIgZACIgeAEQhWBjhsBPQhsBRh3A6Qh2A7h6AjQh6AihyAIQgSACgSAAQhVAAhCgsg");
	this.shape.setTransform(935.3,211.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AurScQhOg1gCheQgEi+C5gVIB0gaQA4gRAqgjQApgiAZguQAYgvAAg+IAAheImqAAQh2AAg0hCQgyhDAAhTIALhOQALgmAbggQAcgfAqgUQApgTA8AAIMxAAQAhhOAVhlIsXAAQh8AAg4g8Qg4g8AAhXQAAhUA3g8QA2g7B/AAIMsAAIAAhtQAAg6hBAAIreAAQh/AAg4g8Qg4g9AAhcQAAhUA3g+QA3g+CBAAIO1AAQC9AABPBLQBNBMAACMIAAGWQAACcgUB5QgWB4gjBTIAHAAQA8AAAqATQAqAUAZAfQAbAgALAmIAMBOIgMBQQgLAogcAeQgbAdgqASQgqATg5AAIlpAAIAABeQAACpg/B8QhAB9hoBVQhoBUiGArQiIAriQADIgJAAQhnAAhKgzgAKWS6MAAAgiIQAAh/BNhAQBOhBBoAAQBoAABPBBQBNBAAAB/MAAAAiIg");
	this.shape_1.setTransform(671.825,211.5556);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AsfTFQhXAAhGgdQhFgcgvgyQgvgxgYhAQgZg/AAhHIAAgfQAAiNBfhUQBfhSCzAAITnAAIAAhDIgIghIghgJI2CAAQhNAAghgvQgigvAAg8QAAg2AigxQAhgwBNAAIZ+AAQCvAABHA8QBHA7AACaIAAGgI4JAAQgdAAgOAOQgOAQAAAUIAAAIQAAAUAOAPQAOAOAdAAIW5AAQBOAAAjAyQAiAxAAA8QAAA2ghAxQgiAwhQAAgAHDAhIAAvkQAAh/BNhBQBMhBBpAAQBlAABOBDQBOBCAAB8IAAChIBQAAQA8AAAnAUQAoAUAXAhIAiBHIAKBNIgKBQQgKApgYAeQgXAggpATQgpATg5AAIhQAAIAAGJgAtvgLQh0AAhKgTQhIgUgpguQgpgsgOhNQgOhKAAhzIAAlkQAAhwAOhMQAOhOApguQApgtBIgTQBKgTB0AAIK+AAQB1AABIATQBJATAoAtQAoAuAOBOQAPBMAABwIAALvgArssBQgLAOAAAlIAAEJQAAAqALANQAMANAnAAIGRAAIAAlNQAAglgOgOQgNgOgnAAIlPAAQgnAAgMAOg");
	this.shape_2.setTransform(405.025,210.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AtBTCQioAAhHhIQhEhHAAicIAAn7QAAifBEhIQBHhHCoAAIamAAQBTAAAjAzQAjAyAAA1QAAA5gkAwQgkAwhRAAI2TAAQg2AAAAAvIAAA8IW/AAQBSAAAiAsQAjArgBA3QABA0gjAsQgiAthSAAI2/AAIAAA+QAAAdANAJIApAJIW8AAQBRAAAhAwQAjAxAAA0QAAA5gjAwQgkAwhOAAgAHBAgIAAvhQABh/BNhAQBMhBBpAAQBlAABOBCQBOBCAAB8IAACfIBQAAQA7AAAoAUQAoATAWAhIAiBIIAKBNIgKBQQgKApgYAeQgWAggpATQgpATg5AAIhQAAIAAGIgAtwgTQi7AAhbhNQhchMAAi/IAAonQAAiEBLg7QBKg8BtAAQBtAABJA8QBIA7AACEIAAGuQABAsAOALQAMAMAsAAILvAAQB4AAAtA7QAtA9AABQQAABUguA5QgvA5h1AAg");
	this.shape_3.setTransform(145.15,210.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,51,0,0.094)").s().p("AvgSDQg8AAgqgTQgpgSgbggQgcgegMgoIgNhQIALhQQALgoAbgfQAcgfArgTQArgUA8AAIfBAAQA7AAArAUQAsATAbAfQAbAfAMAoIALBQIgNBQQgMAogcAeQgbAggqASQgqATg7AAgAwwEdQhPg1gOhcQgMhWAuhGQAthHBhgRQCEgUB8g1QB+g2BjhOQBhhQBBhnQBAhnAKh3IpzAAQg8AAgngTQgpgVgcgeQgbgggLgmIgNhPIANhNQAMgnAZghQAaggArgUQAogUA8AAIcHAAQA8AAApAUQApAUAbAgQAZAhAMAnIANBNIgNBPQgMAmgbAgQgcAegpAVQgpATg5AAIp7AAIgJBjIgUBbIAbAAQCkAACbA0QCdA0B9BqQB7BoBQCgQBPCfANDXIn/AAQgmjcidh1Qidh3jlAAIgZACIgeAEQhWBjhsBPQhsBRh3A6Qh2A7h6AjQh6AihyAIQgSACgSAAQhVAAhCgsg");
	this.shape_4.setTransform(935.3,227.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,51,0,0.094)").s().p("AurScQhOg1gCheQgEi+C5gVIB0gaQA4gRAqgjQApgiAZguQAYgvAAg+IAAheImqAAQh2AAg0hCQgyhDAAhTIALhOQALgmAbggQAcgfAqgUQApgTA8AAIMxAAQAhhOAVhlIsXAAQh8AAg4g8Qg4g8AAhXQAAhUA3g8QA2g7B/AAIMsAAIAAhtQAAg6hBAAIreAAQh/AAg4g8Qg4g9AAhcQAAhUA3g+QA3g+CBAAIO1AAQC9AABPBLQBNBMAACMIAAGWQAACcgUB5QgWB4gjBTIAHAAQA8AAAqATQAqAUAZAfQAbAgALAmIAMBOIgMBQQgLAogcAeQgbAdgqASQgqATg5AAIlpAAIAABeQAACpg/B8QhAB9hoBVQhoBUiGArQiIAriQADIgJAAQhnAAhKgzgAKWS6MAAAgiIQAAh/BNhAQBOhBBoAAQBoAABPBBQBNBAAAB/MAAAAiIg");
	this.shape_5.setTransform(671.825,227.6056);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,51,0,0.094)").s().p("AsfTFQhXAAhGgdQhFgcgvgyQgvgxgYhAQgZg/AAhHIAAgfQAAiNBfhUQBfhSCzAAITnAAIAAhDIgIghIghgJI2CAAQhNAAghgvQgigvAAg8QAAg2AigxQAhgwBNAAIZ+AAQCvAABHA8QBHA7AACaIAAGgI4JAAQgdAAgOAOQgOAQAAAUIAAAIQAAAUAOAPQAOAOAdAAIW5AAQBOAAAjAyQAiAxAAA8QAAA2ghAxQgiAwhQAAgAHDAhIAAvkQAAh/BNhBQBMhBBpAAQBlAABOBDQBOBCAAB8IAAChIBQAAQA8AAAnAUQAoAUAXAhIAiBHIAKBNIgKBQQgKApgYAeQgXAggpATQgpATg5AAIhQAAIAAGJgAtvgLQh0AAhKgTQhIgUgpguQgpgsgOhNQgOhKAAhzIAAlkQAAhwAOhMQAOhOApguQApgtBIgTQBKgTB0AAIK+AAQB1AABIATQBJATAoAtQAoAuAOBOQAPBMAABwIAALvgArssBQgLAOAAAlIAAEJQAAAqALANQAMANAnAAIGRAAIAAlNQAAglgOgOQgNgOgnAAIlPAAQgnAAgMAOg");
	this.shape_6.setTransform(405.025,226.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,51,0,0.094)").s().p("AtBTCQioAAhHhIQhEhHAAicIAAn7QAAifBEhIQBHhHCoAAIamAAQBTAAAjAzQAjAyAAA1QAAA5gkAwQgkAwhRAAI2TAAQg2AAAAAvIAAA8IW/AAQBSAAAiAsQAjArgBA3QABA0gjAsQgiAthSAAI2/AAIAAA+QAAAdANAJIApAJIW8AAQBRAAAhAwQAjAxAAA0QAAA5gjAwQgkAwhOAAgAHBAgIAAvhQABh/BNhAQBMhBBpAAQBlAABOBCQBOBCAAB8IAACfIBQAAQA7AAAoAUQAoATAWAhIAiBIIAKBNIgKBQQgKApgYAeQgWAggpATQgpATg5AAIhQAAIAAGIgAtwgTQi7AAhbhNQhchMAAi/IAAonQAAiEBLg7QBKg8BtAAQBtAABJA8QBIA7AACEIAAGuQABAsAOALQAMAMAsAAILvAAQB4AAAtA7QAtA9AABQQAABUguA5QgvA5h1AAg");
	this.shape_7.setTransform(145.15,226.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.t2, new cjs.Rectangle(2,82,1065.5,280.1), null);


(lib.t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E2E50").s().p("AvlSEQh2AAgyhCQgyhBAAhQIALhNQAMglAZgeQAbgdApgTQAqgTA8ABILdAAIAAlvIlVAAQkEAAiAh5QiBh5gBjRIAAgyQABjTCBh6QCAh7EEAAIR1AAIAAhNIgNgyQgOgWgrAAI1QAAQhdAAg1hAQg1hBAAhPQAAhPA1hBQA1hBBdAAIXgAAQCIAABYAfQBZAdA0A1QA0A2AWBKQAWBMAABeIAAInI4NAAQhXABAABIIAAANQAABJBXAAIWBAAQA2AAAmASQAmARAZAdQAXAcAMAkIAKBJQAABMgvA/QgvA9hqABIqZAAIAAFvILcAAQA7gBAqATQAqATAbAdQAZAeAMAlIALBNQAABQgxBBQgzBCh2AAg");
	this.shape.setTransform(1036.6,333.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2E2E50").s().p("AMLTFMAAAgisQAAhtBHg4QBGg4BbAAIBVAOQAqAOAhAeQAgAcAUAoQATApAAA2MAAAAisgADSTFIAAzyIjUAAQg8AAgpgTQgogTgbghQgcghgLgoIgMhQIAMhOQALgpAbggQAZgeAqgWQAqgUA8AAIDUAAIAAn7QAAhtBBg4QBAg4BcAAQBZAABEA4QBFA4AABtMAAAAisgAxZRBQgugRgigqQgggkgKgsQgKgsAGguQAGgtAZgsQAWgqAogiQBlhbBChxQBChxAoibQAnibAPjPQAQjSAAkfIAAkFQAAh+BFg7QBHg8BmAAQBiAABJA+QBJA+AAB5IAAEDQAAE4gfECQB4A5BbBZQBdBZA6CJQA8CIAYC9QAXC8gPD/InZAAQAgjngXicQgVichGhhQhFDlhiCXQhjCXh3BTIhVApIhiASIgHAAQguAAgrgQg");
	this.shape_1.setTransform(771.222,332.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B43634").s().p("AvlSEQh2AAgyhCQgyhBAAhQIALhNQAMglAZgeQAbgdApgTQAqgTA8ABILdAAIAAlvIlUAAQkFAAiAh5QiBh5gBjRIAAgyQABjTCBh6QCAh7EFAAIR0AAIAAhNIgNgyQgOgWgrAAI1QAAQhdAAg1hAQg1hBAAhPQAAhPA1hBQA1hBBdAAIXhAAQCIAABXAfQBZAdA0A1QA0A2AWBKQAWBMAABeIAAInI4MAAQhYABAABIIAAANQAABJBYAAIWAAAQA2AAAmASQAmARAZAdQAYAcALAkIAKBJQAABMgvA/QgvA9hqABIqZAAIAAFvILcAAQA7gBAqATQAqATAbAdQAZAeAMAlIALBNQAABQgxBBQgzBCh2AAg");
	this.shape_2.setTransform(503.7,333.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B43634").s().p("AHRTFMAAAgiNQAAh9BPg/QBNhABmAAQAyAAAvARQAuAQAjAgQAjAfAWAvQAXAvAAA+IAAKRIBVAAQA7AAAoAWQAnAUAXAhIAiBJIAKBQIgKBOIgiBIQgXAhgoAUQgpAWg5AAIhVAAIAAQ3gAxZRTQgugOgigcQgkgegUgrQgVgqAAg5QAAhUAvg3QAvg4BjgNQCYgTCEguQCDgvBfhgQBfhhA3idQA2idAAjuIAAmyQAAgegQgRQgSgSgeAAIpRAAQg8AAgpgWQgogUgbghQgcgggLgoIgMhPIAMhQQALgpAbgeQAZggAqgUQAqgWA8AAIL8AAQDdAABdBjQBcBjAAC2IAAI8QAAFZhXDwQhYDuidCZQieCYjWBIQjXBJj7AOIgQAAQgnAAgmgKg");
	this.shape_3.setTransform(237.075,332.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.t1, new cjs.Rectangle(96,204.1,1072.8,264), null);


(lib.star2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah3BHIiLh0ICxgmIBFioIBaCdIC1ANIh4CGIArCxIimhJIiZBfg");
	this.shape.setTransform(41.125,25.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#B59713","#FFCB17"],[0,0.851],-24.8,3.6,26.5,-3.6).s().p("Ah4BHIiKh0ICxgmIBFioIBaCdIC1ANIh5CHIArCwIimhJIiZBfg");
	this.shape_1.setTransform(25.925,43.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.star2, new cjs.Rectangle(0,0,67.1,68.9), null);


(lib.star1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPCcIimBJIAriwIh4iGIC0gOIBbicIBFCoICxAnIiLB0IASC0g");
	this.shape.setTransform(41.1,25.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#B59713","#FFCB17"],[0,0.851],-25.9,0,25.9,0).s().p("AgOCdIinBJIAsixIh5iGIC1gNIBbidIBDCoICyAmIiKB1IASC0g");
	this.shape_1.setTransform(25.9,43.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.star1, new cjs.Rectangle(0,0,67,68.6), null);


(lib.star_blost = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#493728").s().p("AgsAnIhOgrIBRgjIAShXIA5BDIBZgKIguBLIAlBRIhWgUIhBA8g");
	this.shape.setTransform(368.9,17);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},18).wait(3));

	// Layer_7
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#493728").s().p("AhsBMIiWhpICvg2IA2ivIBpCWIC3gDIhuCSIA7CtIitg7IiSBug");
	this.shape_1.setTransform(-355.275,237.275);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(2).to({_off:false},0).to({_off:true},13).wait(6));

	// Layer_8
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#493728").s().p("AhtBMIiVhpICvg2IA3ivIBoCWIC3gDIhtCSIA6CtIitg7IiRBug");
	this.shape_2.setTransform(-230.55,-172.025);
	this.shape_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(5).to({_off:false},0).to({_off:true},7).wait(9));

	// Layer_9
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#493728").s().p("AgFBqIhtA0IAZh2IhThXIB4gMIA5hrIAxBvIB3AWIhaBQIAQB4g");
	this.shape_3.setTransform(-71.1,-246.475);
	this.shape_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(7).to({_off:false},0).to({_off:true},3).wait(11));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-381.1,-263.1,762.3,526.3);


(lib.show_timer_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.play();
	}
	this.frame_19 = function() {
		ths.show_wrong_pop();
		this.gotoAndStop(0);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(18).call(this.frame_19).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F3BB4C").ss(1,1,1).p("AjWiLIGtAAIAAEXImtAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#281800").s().p("AjWCMIAAkXIGtAAIAAEXg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(20));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-15,45,30);


(lib.ClipGroup_162 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A1QVQMAAAgqgMAqgAAAMAAAAqgg");
	mask.setTransform(136.05,136.05);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD019").s().p("A0kUkQgrgrAAg+QAAg+ArgsMAl1gl0QAVgVAcgNQAbgLAeAAQAdAAAbALQAcANAWAVQArAsAAA+QAAA9grAsMgl0Al0QgtAtg9gBQg+ABgtgtg");
	this.shape.setTransform(136.025,136.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_162, new cjs.Rectangle(0,0,272.1,272.1), null);


(lib.ClipGroup_159 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgKgEQAJgIAKAAIALACIgnAXQABgMAIgFg");
	this.shape.setTransform(135.85,169.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_159, new cjs.Rectangle(133.8,168.5,4.099999999999994,2.5999999999999943), null);


(lib.ClipGroup_158 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgcACIA1gWQAEAHAAAGQAAALgJAIQgJAJgLAAQgTgBgJgSg");
	this.shape.setTransform(56.625,7.75);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_158, new cjs.Rectangle(53.8,5.7,5.700000000000003,4.1000000000000005), null);


(lib.ClipGroup_157 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(71.3,6.9);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_157, new cjs.Rectangle(68.4,4,5.799999999999997,5.800000000000001), null);


(lib.ClipGroup_156 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgJgIAAgMQAAgLAJgIQAJgJALAAQAMAAAJAJQAJAIAAALQgBAMgJAIQgJAJgLAAQgLAAgJgJg");
	this.shape.setTransform(86.025,6.9);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_156, new cjs.Rectangle(83.1,4,5.900000000000006,5.800000000000001), null);


(lib.ClipGroup_155 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgWAQQAcgXAPgLQACAGAAAEQgBAKgIAIQgJAKgLgBQgFAAgLgDg");
	this.shape.setTransform(33.75,20.65);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_155, new cjs.Rectangle(31.5,18.7,4.5,3.900000000000002), null);


(lib.ClipGroup_154 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQgBALgHAJQgJAJgMAAQgLAAgJgIg");
	this.shape.setTransform(47.8,19.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_154, new cjs.Rectangle(44.9,16.8,5.800000000000004,5.800000000000001), null);


(lib.ClipGroup_153 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAALgIAJQgJAJgMAAQgLAAgIgIg");
	this.shape.setTransform(62.475,19.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_153, new cjs.Rectangle(59.6,16.8,5.800000000000004,5.800000000000001), null);


(lib.ClipGroup_152 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAALgJAJQgIAJgMAAQgLAAgJgIg");
	this.shape.setTransform(77.15,19.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_152, new cjs.Rectangle(74.3,16.8,5.799999999999997,5.800000000000001), null);


(lib.ClipGroup_151 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgHAIgNAAQgLAAgIgIg");
	this.shape.setTransform(27.15,32.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_151, new cjs.Rectangle(24.3,29.5,5.800000000000001,5.899999999999999), null);


(lib.ClipGroup_150 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(41.9,32.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_150, new cjs.Rectangle(39,29.5,5.799999999999997,5.899999999999999), null);


(lib.ClipGroup_149_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(56.575,32.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_149_0, new cjs.Rectangle(53.7,29.5,5.799999999999997,5.899999999999999), null);


(lib.ClipGroup_149 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgUABIAngPIACAJQgBAHgGAHQgHAGgHAAQgPAAgFgOg");
	this.shape.setTransform(41.45,5.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_149, new cjs.Rectangle(39.4,4.2,4.200000000000003,3), null);


(lib.ClipGroup_148_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgJgIg");
	this.shape.setTransform(71.3,32.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_148_0, new cjs.Rectangle(68.4,29.5,5.799999999999997,5.899999999999999), null);


(lib.ClipGroup_148 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAGgGQAHgGAHAAQAJAAAGAHQAGAFAAAIQAAAIgHAHQgFAGgJAAQgIAAgGgGg");
	this.shape.setTransform(52.05,5.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_148, new cjs.Rectangle(50,3,4.200000000000003,4.2), null);


(lib.ClipGroup_147_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgJgJAAgMQAAgLAJgJQAJgIALAAQALAAAKAIQAJAJAAALQgBAMgJAJQgJAIgLAAQgLAAgJgIg");
	this.shape.setTransform(86.025,32.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_147_0, new cjs.Rectangle(83.1,29.5,5.900000000000006,5.899999999999999), null);


(lib.ClipGroup_147 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(62.7268,5.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_147, new cjs.Rectangle(60.7,3,4.099999999999994,4.2), null);


(lib.ClipGroup_146_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(18.4,45.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_146_0, new cjs.Rectangle(15.5,42.2,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_146 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgPALIAegYIABAHQABAIgGAGQgHAGgIAAQgGAAgFgDg");
	this.shape.setTransform(24.6321,14.95);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_146, new cjs.Rectangle(23.1,13.6,3.099999999999998,2.799999999999999), null);


(lib.ClipGroup_145_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(33.075,45.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_145_0, new cjs.Rectangle(30.2,42.2,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_145 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAGAAAIQABAJgGAGQgHAGgJAAQgIAAgGgGg");
	this.shape.setTransform(34.8321,14.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_145, new cjs.Rectangle(32.8,12.1,4.100000000000001,4.299999999999999), null);


(lib.ClipGroup_144_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQgBAMgHAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(47.8,45.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_144_0, new cjs.Rectangle(44.9,42.2,5.800000000000004,5.799999999999997), null);


(lib.ClipGroup_144 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgHAGgHQAGgGAIAAQAJAAAGAGQAGAHAAAHQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(45.5518,14.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_144, new cjs.Rectangle(43.5,12.1,4.200000000000003,4.299999999999999), null);


(lib.ClipGroup_143_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgIgIg");
	this.shape.setTransform(62.475,45.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_143_0, new cjs.Rectangle(59.6,42.2,5.800000000000004,5.799999999999997), null);


(lib.ClipGroup_143 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQABAJgHAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(56.2317,14.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_143, new cjs.Rectangle(54.2,12.1,4.099999999999994,4.299999999999999), null);


(lib.ClipGroup_142_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgJgIg");
	this.shape.setTransform(77.15,45.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_142_0, new cjs.Rectangle(74.3,42.2,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_142 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAFQgHAHgIAAQgIAAgGgHg");
	this.shape.setTransform(19.9268,23.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_142, new cjs.Rectangle(17.9,21.5,4.100000000000001,4.199999999999999), null);


(lib.ClipGroup_141_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgIgIg");
	this.shape.setTransform(12.475,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_141_0, new cjs.Rectangle(9.6,55,5.800000000000001,5.899999999999999), null);


(lib.ClipGroup_141 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgHAGQgGAHgIAAQgIAAgGgHg");
	this.shape.setTransform(30.625,23.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_141, new cjs.Rectangle(28.6,21.5,4.100000000000001,4.199999999999999), null);


(lib.ClipGroup_140_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgHAIgNAAQgLAAgIgIg");
	this.shape.setTransform(27.15,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_140_0, new cjs.Rectangle(24.3,55,5.800000000000001,5.899999999999999), null);


(lib.ClipGroup_140 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgHAGQgGAHgIAAQgIAAgGgHg");
	this.shape.setTransform(41.325,23.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_140, new cjs.Rectangle(39.3,21.5,4.100000000000001,4.199999999999999), null);


(lib.ClipGroup_139_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(41.9,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_139_0, new cjs.Rectangle(39,55,5.799999999999997,5.899999999999999), null);


(lib.ClipGroup_139 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAGgGQAHgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgHAFQgFAHgJAAQgIAAgGgHg");
	this.shape.setTransform(52.05,23.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_139, new cjs.Rectangle(50,21.5,4.200000000000003,4.199999999999999), null);


(lib.ClipGroup_138_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(56.575,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_138_0, new cjs.Rectangle(53.7,55,5.799999999999997,5.899999999999999), null);


(lib.ClipGroup_138 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(62.7268,23.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_138, new cjs.Rectangle(60.7,21.5,4.099999999999994,4.199999999999999), null);


(lib.ClipGroup_137_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgJgIg");
	this.shape.setTransform(71.3,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_137_0, new cjs.Rectangle(68.4,55,5.799999999999997,5.899999999999999), null);


(lib.ClipGroup_137 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQABAJgGAFQgHAHgJAAQgIAAgGgHg");
	this.shape.setTransform(13.4321,32.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_137, new cjs.Rectangle(11.4,30.8,4.1,4.199999999999999), null);


(lib.ClipGroup_136_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgJgJAAgMQAAgLAJgJQAJgIALAAQALAAAKAIQAJAJAAALQgBAMgJAJQgJAIgLAAQgLAAgJgIg");
	this.shape.setTransform(86.025,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_136_0, new cjs.Rectangle(83.1,55,5.900000000000006,5.899999999999999), null);


(lib.ClipGroup_136 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQABAIgGAGQgHAHgJAAQgIAAgGgHg");
	this.shape.setTransform(24.1321,32.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_136, new cjs.Rectangle(22.1,30.8,4.099999999999998,4.199999999999999), null);


(lib.ClipGroup_135_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgXAXIAMgyIAHgBQALAAAIAIQAJAJAAALQAAAMgJAJQgIAIgLAAQgKAAgJgGg");
	this.shape.setTransform(4.15,70.575);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_135_0, new cjs.Rectangle(1.8,67.7,4.8,5.799999999999997), null);


(lib.ClipGroup_135 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQABAIgGAGQgHAHgJAAQgIAAgGgHg");
	this.shape.setTransform(34.8321,32.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_135, new cjs.Rectangle(32.8,30.8,4.100000000000001,4.199999999999999), null);


(lib.ClipGroup_134_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape.setTransform(18.4,70.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_134_0, new cjs.Rectangle(15.5,67.7,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_134 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAJgGAFQgHAHgIAAQgIAAgGgHg");
	this.shape.setTransform(45.5518,32.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_134, new cjs.Rectangle(43.5,30.8,4.200000000000003,4.199999999999999), null);


(lib.ClipGroup_133_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(33.075,70.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_133_0, new cjs.Rectangle(30.2,67.7,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_133 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQABAJgHAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(56.2317,32.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_133, new cjs.Rectangle(54.2,30.8,4.099999999999994,4.199999999999999), null);


(lib.ClipGroup_132_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQgBAMgHAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(47.8,70.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_132_0, new cjs.Rectangle(44.9,67.7,5.800000000000004,5.799999999999997), null);


(lib.ClipGroup_132 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAFgGAIAAQAIAAAHAHQAGAGAAAHQAAAIgGAGQgHAHgIAAQgIAAgGgGg");
	this.shape.setTransform(9.25,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_132, new cjs.Rectangle(7.2,40.1,4.2,4.199999999999996), null);


(lib.ClipGroup_131_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgIgJg");
	this.shape.setTransform(62.475,70.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_131_0, new cjs.Rectangle(59.6,67.7,5.800000000000004,5.799999999999997), null);


(lib.ClipGroup_131 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgHAHgIAAQgIAAgGgGg");
	this.shape.setTransform(19.9268,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_131, new cjs.Rectangle(17.9,40.1,4.100000000000001,4.199999999999996), null);


(lib.ClipGroup_130_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(77.15,70.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_130_0, new cjs.Rectangle(74.3,67.7,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_130 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgHAGQgGAHgIAAQgIAAgGgGg");
	this.shape.setTransform(30.625,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_130, new cjs.Rectangle(28.6,40.1,4.100000000000001,4.199999999999996), null);


(lib.ClipGroup_129_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AAAgOQACAGAAAHQAAAJgDAHIABgdg");
	this.shape.setTransform(0.4,83.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_129_0, new cjs.Rectangle(0.2,82,0.49999999999999994,3), null);


(lib.ClipGroup_129 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgHAGQgGAHgIAAQgIAAgGgGg");
	this.shape.setTransform(41.325,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_129, new cjs.Rectangle(39.3,40.1,4.100000000000001,4.199999999999996), null);


(lib.ClipGroup_128_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgIgJg");
	this.shape.setTransform(12.475,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_128_0, new cjs.Rectangle(9.6,80.4,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_128 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAHgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgHAGQgGAHgIAAQgIAAgGgGg");
	this.shape.setTransform(52.05,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_128, new cjs.Rectangle(50,40.1,4.200000000000003,4.199999999999996), null);


(lib.ClipGroup_127_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgHAJgNAAQgLAAgIgJg");
	this.shape.setTransform(27.15,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_127_0, new cjs.Rectangle(24.3,80.4,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_127 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgGAHgJAAQgIAAgGgGg");
	this.shape.setTransform(62.7268,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_127, new cjs.Rectangle(60.7,40.1,4.099999999999994,4.199999999999996), null);


(lib.ClipGroup_126_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape.setTransform(41.9,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_126_0, new cjs.Rectangle(39,80.4,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_126 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgQAQIAJgkIAFAAQAHAAAGAGQAHAGAAAIQAAAIgHAGQgGAHgHAAQgIAAgGgFg");
	this.shape.setTransform(3.1,51.325);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_126, new cjs.Rectangle(1.4,49.2,3.5000000000000004,4.299999999999997), null);


(lib.ClipGroup_125_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(56.575,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_125_0, new cjs.Rectangle(53.7,80.4,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_125 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(13.425,51.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_125, new cjs.Rectangle(11.4,49.3,4.1,4.200000000000003), null);


(lib.ClipGroup_124_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(71.3,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_124_0, new cjs.Rectangle(68.4,80.4,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_124 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(24.125,51.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_124, new cjs.Rectangle(22.1,49.3,4.099999999999998,4.200000000000003), null);


(lib.ClipGroup_123_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgJgIAAgMQAAgLAJgIQAJgJALAAQAMAAAJAJQAJAIAAALQgBAMgJAIQgJAJgLAAQgLAAgJgJg");
	this.shape.setTransform(86.025,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_123_0, new cjs.Rectangle(83.1,80.4,5.900000000000006,5.799999999999997), null);


(lib.ClipGroup_123 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(34.825,51.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_123, new cjs.Rectangle(32.8,49.3,4.100000000000001,4.200000000000003), null);


(lib.ClipGroup_122_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape.setTransform(101.4,6.9);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_122_0, new cjs.Rectangle(98.5,4,5.799999999999997,5.800000000000001), null);


(lib.ClipGroup_122 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgHAGgHQAHgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgHAGgIAAQgIAAgGgGg");
	this.shape.setTransform(45.55,51.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_122, new cjs.Rectangle(43.5,49.3,4.200000000000003,4.200000000000003), null);


(lib.ClipGroup_121_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(116.075,6.9);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_121_0, new cjs.Rectangle(113.2,4,5.799999999999997,5.800000000000001), null);


(lib.ClipGroup_121 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(56.225,51.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_121, new cjs.Rectangle(54.2,49.3,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_120_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgHAEQgHgFgDgHIAjAQIgJABQgJAAgHgFg");
	this.shape.setTransform(129.9,8.9);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_120_0, new cjs.Rectangle(128.1,8,3.5999999999999943,1.8000000000000007), null);


(lib.ClipGroup_120 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AAAgKQACAGAAAEQAAADgDAIQAAgJABgMg");
	this.shape.setTransform(0.45,60.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_120, new cjs.Rectangle(0.3,59.7,0.39999999999999997,2.1999999999999957), null);


(lib.ClipGroup_119_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAALgIAJQgJAJgMAAQgLAAgJgIg");
	this.shape.setTransform(92.575,19.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_119_0, new cjs.Rectangle(89.7,16.8,5.799999999999997,5.800000000000001), null);


(lib.ClipGroup_119 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAFgGAIAAQAIAAAHAGQAGAGAAAIQAAAJgGAGQgHAGgIAAQgIAAgGgHg");
	this.shape.setTransform(9.25,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_119, new cjs.Rectangle(7.2,58.6,4.2,4.199999999999996), null);


(lib.ClipGroup_118_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAALgJAJQgIAJgMAAQgLAAgJgIg");
	this.shape.setTransform(107.3,19.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_118_0, new cjs.Rectangle(104.4,16.8,5.799999999999997,5.800000000000001), null);


(lib.ClipGroup_118 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgHg");
	this.shape.setTransform(19.9268,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_118, new cjs.Rectangle(17.9,58.6,4.100000000000001,4.199999999999996), null);


(lib.ClipGroup_117_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAALgIAJQgJAJgMAAQgLAAgIgIg");
	this.shape.setTransform(121.975,19.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_117_0, new cjs.Rectangle(119.1,16.8,5.800000000000011,5.800000000000001), null);


(lib.ClipGroup_117 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgHAGQgGAGgIAAQgIAAgGgHg");
	this.shape.setTransform(30.625,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_117, new cjs.Rectangle(28.6,58.6,4.100000000000001,4.199999999999996), null);


(lib.ClipGroup_116_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAALgJAJQgIAJgMAAQgLAAgIgIg");
	this.shape.setTransform(136.65,19.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_116_0, new cjs.Rectangle(133.8,16.8,5.799999999999983,5.800000000000001), null);


(lib.ClipGroup_116 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgHAGQgGAGgIAAQgIAAgGgHg");
	this.shape.setTransform(41.325,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_116, new cjs.Rectangle(39.3,58.6,4.100000000000001,4.199999999999996), null);


(lib.ClipGroup_115_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgJgIQAKAIAJAJQgLgDgIgOg");
	this.shape.setTransform(149.55,21.65);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_115_0, new cjs.Rectangle(148.6,20.8,2,1.6999999999999993), null);


(lib.ClipGroup_115 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAGgGQAHgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgHAGQgFAGgJAAQgIAAgGgHg");
	this.shape.setTransform(52.05,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_115, new cjs.Rectangle(50,58.6,4.200000000000003,4.199999999999996), null);


(lib.ClipGroup_114_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(101.4,32.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_114_0, new cjs.Rectangle(98.5,29.5,5.799999999999997,5.899999999999999), null);


(lib.ClipGroup_114 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgHg");
	this.shape.setTransform(62.7268,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_114, new cjs.Rectangle(60.7,58.6,4.099999999999994,4.199999999999996), null);


(lib.ClipGroup_113_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(116.075,32.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_113_0, new cjs.Rectangle(113.2,29.5,5.799999999999997,5.899999999999999), null);


(lib.ClipGroup_113 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(73.9269,5.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_113, new cjs.Rectangle(71.9,3,4.099999999999994,4.2), null);


(lib.ClipGroup_112_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(130.8,32.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_112_0, new cjs.Rectangle(127.9,29.5,5.799999999999983,5.899999999999999), null);


(lib.ClipGroup_112 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(84.625,5.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_112, new cjs.Rectangle(82.6,3,4.1000000000000085,4.2), null);


(lib.ClipGroup_111_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgIgIg");
	this.shape.setTransform(145.475,32.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_111_0, new cjs.Rectangle(142.6,29.5,5.800000000000011,5.899999999999999), null);


(lib.ClipGroup_111 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgMgGIAZALIgGACQgNAAgGgNg");
	this.shape.setTransform(94.625,6.525);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_111, new cjs.Rectangle(93.4,5.9,2.5,1.2999999999999998), null);


(lib.ClipGroup_110_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgPASQgJgJAAgLQABgPAKgIIAmAsQgLAHgKAAQgKAAgJgIg");
	this.shape.setTransform(159.7,32.725);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_110_0, new cjs.Rectangle(157.3,30.1,4.899999999999977,5.299999999999997), null);


(lib.ClipGroup_110 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgHAGgHQAHgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAGQgHAGgIAAQgIAAgGgGg");
	this.shape.setTransform(67.55,14.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_110, new cjs.Rectangle(65.5,12.1,4.200000000000003,4.299999999999999), null);


(lib.ClipGroup_109_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(92.575,45.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_109_0, new cjs.Rectangle(89.7,42.2,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_109 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(78.2268,14.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_109, new cjs.Rectangle(76.2,12.1,4.099999999999994,4.299999999999999), null);


(lib.ClipGroup_108_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgJgIg");
	this.shape.setTransform(107.3,45.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_108_0, new cjs.Rectangle(104.4,42.2,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_108 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(88.9269,14.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_108, new cjs.Rectangle(86.9,12.1,4.099999999999994,4.299999999999999), null);


(lib.ClipGroup_107_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgIgIg");
	this.shape.setTransform(121.975,45.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_107_0, new cjs.Rectangle(119.1,42.2,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_107 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(99.625,14.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_107, new cjs.Rectangle(97.6,12.1,4.1000000000000085,4.299999999999999), null);


(lib.ClipGroup_106_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgHAIgNAAQgLAAgIgIg");
	this.shape.setTransform(136.65,45.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_106_0, new cjs.Rectangle(133.8,42.2,5.799999999999983,5.799999999999997), null);


(lib.ClipGroup_106 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgGgFIANALQgJgDgEgIg");
	this.shape.setTransform(109.125,15.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_106, new cjs.Rectangle(108.4,15.2,1.5,1.1999999999999993), null);


(lib.ClipGroup_105_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgJgIg");
	this.shape.setTransform(151.4,45.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_105_0, new cjs.Rectangle(148.5,42.2,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_105 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(73.9269,23.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_105, new cjs.Rectangle(71.9,21.5,4.099999999999994,4.199999999999999), null);


(lib.ClipGroup_104_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQADADAFALIABAHQAAALgIAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(166.075,45.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_104_0, new cjs.Rectangle(163.2,42.2,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_104 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(84.625,23.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_104, new cjs.Rectangle(82.6,21.5,4.1000000000000085,4.199999999999999), null);


(lib.ClipGroup_103_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(101.4,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_103_0, new cjs.Rectangle(98.5,55,5.799999999999997,5.899999999999999), null);


(lib.ClipGroup_103 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(95.325,23.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_103, new cjs.Rectangle(93.3,21.5,4.1000000000000085,4.199999999999999), null);


(lib.ClipGroup_102_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(116.075,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_102_0, new cjs.Rectangle(113.2,55,5.799999999999997,5.899999999999999), null);


(lib.ClipGroup_102 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAGgGQAHgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(106.05,23.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_102, new cjs.Rectangle(104,21.5,4.200000000000003,4.199999999999999), null);


(lib.ClipGroup_101_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(130.8,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_101_0, new cjs.Rectangle(127.9,55,5.799999999999983,5.899999999999999), null);


(lib.ClipGroup_101 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgLAMQgGgFAAgIQAAgLAIgGQAPAQAMAQQgHAFgIAAQgIAAgGgHg");
	this.shape.setTransform(116.425,23.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_101, new cjs.Rectangle(114.7,21.9,3.5,3.8000000000000007), null);


(lib.ClipGroup_100_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgIgIg");
	this.shape.setTransform(145.475,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_100_0, new cjs.Rectangle(142.6,55,5.800000000000011,5.899999999999999), null);


(lib.ClipGroup_100 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAGgGQAHgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAFQgHAHgIAAQgIAAgGgHg");
	this.shape.setTransform(67.55,32.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_100, new cjs.Rectangle(65.5,30.8,4.200000000000003,4.199999999999999), null);


(lib.ClipGroup_99_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgHAIgNAAQgLAAgIgIg");
	this.shape.setTransform(160.15,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_99_0, new cjs.Rectangle(157.3,55,5.799999999999983,5.899999999999999), null);


(lib.ClipGroup_99 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(78.2268,32.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_99, new cjs.Rectangle(76.2,30.8,4.099999999999994,4.199999999999999), null);


(lib.ClipGroup_98_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgNAVQgJgJAAgMQAAgKAIgIQAGgIAKgCQAOAhAGAUQgKAEgGAAQgLAAgIgIg");
	this.shape.setTransform(174.25,57.925);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_98_0, new cjs.Rectangle(172,55,4.5,5.899999999999999), null);


(lib.ClipGroup_98 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(88.9269,32.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_98, new cjs.Rectangle(86.9,30.8,4.099999999999994,4.199999999999999), null);


(lib.ClipGroup_97_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(92.575,70.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_97_0, new cjs.Rectangle(89.7,67.7,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_97 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(99.625,32.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_97, new cjs.Rectangle(97.6,30.8,4.1000000000000085,4.199999999999999), null);


(lib.ClipGroup_96_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(107.3,70.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_96_0, new cjs.Rectangle(104.4,67.7,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_96 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(110.325,32.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_96, new cjs.Rectangle(108.3,30.8,4.1000000000000085,4.199999999999999), null);


(lib.ClipGroup_95_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgIgJg");
	this.shape.setTransform(121.975,70.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_95_0, new cjs.Rectangle(119.1,67.7,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_95 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgIAGgGQAGgGAIAAQAJAAAGAGIAGAKIAAAFQAAAIgGAGQgHAGgIAAQgIAAgGgHg");
	this.shape.setTransform(121.075,32.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_95, new cjs.Rectangle(119,30.8,4.200000000000003,4.199999999999999), null);


(lib.ClipGroup_94_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgHAJgNAAQgLAAgIgJg");
	this.shape.setTransform(136.65,70.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_94_0, new cjs.Rectangle(133.8,67.7,5.799999999999983,5.799999999999997), null);


(lib.ClipGroup_94 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgGAHgJAAQgIAAgGgGg");
	this.shape.setTransform(73.9269,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_94, new cjs.Rectangle(71.9,40.1,4.099999999999994,4.199999999999996), null);


(lib.ClipGroup_93_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(151.4,70.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_93_0, new cjs.Rectangle(148.5,67.7,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_93 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgGAHgJAAQgIAAgGgGg");
	this.shape.setTransform(84.625,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_93, new cjs.Rectangle(82.6,40.1,4.1000000000000085,4.199999999999996), null);


(lib.ClipGroup_92_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(166.075,70.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_92_0, new cjs.Rectangle(163.2,67.7,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_92 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgGAHgJAAQgIAAgGgGg");
	this.shape.setTransform(95.325,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_92, new cjs.Rectangle(93.3,40.1,4.1000000000000085,4.199999999999996), null);


(lib.ClipGroup_91_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgEAQQgGgJAAgJQAAgNAKgKIALAzQgKgCgFgIg");
	this.shape.setTransform(178.975,70.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_91_0, new cjs.Rectangle(177.9,68.2,2.1999999999999886,5.200000000000003), null);


(lib.ClipGroup_91 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAHgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgGAHgJAAQgIAAgGgGg");
	this.shape.setTransform(106.05,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_91, new cjs.Rectangle(104,40.1,4.200000000000003,4.199999999999996), null);


(lib.ClipGroup_90_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape.setTransform(101.4,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_90_0, new cjs.Rectangle(98.5,80.4,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgGAHgJAAQgIAAgGgGg");
	this.shape.setTransform(116.7268,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_90, new cjs.Rectangle(114.7,40.1,4.099999999999994,4.199999999999996), null);


(lib.ClipGroup_89_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(116.075,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_89_0, new cjs.Rectangle(113.2,80.4,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_89 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgKAPQgFgGAAgJQgBgHAGgGQAFgGAHgBIAOAmQgHADgFAAQgIAAgGgGg");
	this.shape.setTransform(127,42.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_89, new cjs.Rectangle(125.4,40.1,3.299999999999983,4.199999999999996), null);


(lib.ClipGroup_88_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape.setTransform(130.8,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_88_0, new cjs.Rectangle(127.9,80.4,5.799999999999983,5.799999999999997), null);


(lib.ClipGroup_88 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgHAGgHQAHgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgHAGgIAAQgIAAgGgGg");
	this.shape.setTransform(67.55,51.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_88, new cjs.Rectangle(65.5,49.3,4.200000000000003,4.200000000000003), null);


(lib.ClipGroup_87_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgIgJg");
	this.shape.setTransform(145.475,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_87_0, new cjs.Rectangle(142.6,80.4,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_87 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(78.225,51.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_87, new cjs.Rectangle(76.2,49.3,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_86_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgHAJgNAAQgLAAgIgJg");
	this.shape.setTransform(160.15,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_86_0, new cjs.Rectangle(157.3,80.4,5.799999999999983,5.799999999999997), null);


(lib.ClipGroup_86 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(88.925,51.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_86, new cjs.Rectangle(86.9,49.3,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_85_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape.setTransform(174.9,83.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_85_0, new cjs.Rectangle(172,80.4,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_85 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(99.625,51.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_85, new cjs.Rectangle(97.6,49.3,4.1000000000000085,4.200000000000003), null);


(lib.ClipGroup_84_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape.setTransform(3.65,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_84_0, new cjs.Rectangle(0.8,92.2,5.8,5.799999999999997), null);


(lib.ClipGroup_84 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(110.325,51.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_84, new cjs.Rectangle(108.3,49.3,4.1000000000000085,4.200000000000003), null);


(lib.ClipGroup_83_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape.setTransform(18.4,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_83_0, new cjs.Rectangle(15.5,92.2,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_83 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(121.05,51.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_83, new cjs.Rectangle(119,49.3,4.200000000000003,4.200000000000003), null);


(lib.ClipGroup_82_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(33.075,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_82_0, new cjs.Rectangle(30.2,92.2,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_82 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgCALQgFgGAAgGQAAgLAHgGIAIAlQgHgCgDgGg");
	this.shape.setTransform(130.425,51.575);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_82, new cjs.Rectangle(129.7,49.7,1.5,3.799999999999997), null);


(lib.ClipGroup_81_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQgBAMgHAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(47.8,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_81_0, new cjs.Rectangle(44.9,92.2,5.800000000000004,5.799999999999997), null);


(lib.ClipGroup_81 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgHg");
	this.shape.setTransform(73.9269,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_81, new cjs.Rectangle(71.9,58.6,4.099999999999994,4.199999999999996), null);


(lib.ClipGroup_80_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgIgJg");
	this.shape.setTransform(62.475,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_80_0, new cjs.Rectangle(59.6,92.2,5.800000000000004,5.799999999999997), null);


(lib.ClipGroup_80 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgHg");
	this.shape.setTransform(84.625,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_80, new cjs.Rectangle(82.6,58.6,4.1000000000000085,4.199999999999996), null);


(lib.ClipGroup_79_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(77.15,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_79_0, new cjs.Rectangle(74.3,92.2,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_79 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgHg");
	this.shape.setTransform(95.325,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_79, new cjs.Rectangle(93.3,58.6,4.1000000000000085,4.199999999999996), null);


(lib.ClipGroup_78_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgIgIg");
	this.shape.setTransform(12.475,107.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_78_0, new cjs.Rectangle(9.6,104.9,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_78 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAGgGQAHgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgHg");
	this.shape.setTransform(106.05,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_78, new cjs.Rectangle(104,58.6,4.200000000000003,4.199999999999996), null);


(lib.ClipGroup_77_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgHAIgNAAQgLAAgIgIg");
	this.shape.setTransform(27.15,107.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_77_0, new cjs.Rectangle(24.3,104.9,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_77 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgHg");
	this.shape.setTransform(116.7268,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_77, new cjs.Rectangle(114.7,58.6,4.099999999999994,4.199999999999996), null);


(lib.ClipGroup_76_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(41.9,107.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_76_0, new cjs.Rectangle(39,104.9,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_76 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQABAJgGAGQgHAGgJAAQgIAAgGgHg");
	this.shape.setTransform(127.4321,60.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_76, new cjs.Rectangle(125.4,58.6,4.099999999999994,4.199999999999996), null);


(lib.ClipGroup_75_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(56.575,107.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_75_0, new cjs.Rectangle(53.7,104.9,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_75 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAIgGAHQgHAGgIAAQgIAAgGgGg");
	this.shape.setTransform(2.7518,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_75, new cjs.Rectangle(0.7,67.1,4.2,4.300000000000011), null);


(lib.ClipGroup_74_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgJgIg");
	this.shape.setTransform(71.3,107.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_74_0, new cjs.Rectangle(68.4,104.9,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_74 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQABAIgGAHQgHAGgJAAQgIAAgGgGg");
	this.shape.setTransform(13.4321,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_74, new cjs.Rectangle(11.4,67.1,4.1,4.300000000000011), null);


(lib.ClipGroup_73_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgJgJAAgMQAAgLAJgJQAJgIALAAQAMAAAJAIQAJAJAAALQgBAMgJAJQgJAIgLAAQgLAAgJgIg");
	this.shape.setTransform(86.025,107.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_73_0, new cjs.Rectangle(83.1,104.9,5.900000000000006,5.799999999999997), null);


(lib.ClipGroup_73 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQABAIgGAHQgHAGgJAAQgIAAgGgGg");
	this.shape.setTransform(24.1321,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_73, new cjs.Rectangle(22.1,67.1,4.099999999999998,4.300000000000011), null);


(lib.ClipGroup_72_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgMgYQAMABAGAIQAHAJAAAKQAAALgJAKg");
	this.shape.setTransform(5.275,120.15);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_72_0, new cjs.Rectangle(4,117.6,2.5999999999999996,5.1000000000000085), null);


(lib.ClipGroup_72 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQABAIgGAHQgHAGgJAAQgIAAgGgGg");
	this.shape.setTransform(34.8321,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_72, new cjs.Rectangle(32.8,67.1,4.100000000000001,4.300000000000011), null);


(lib.ClipGroup_71_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAIQgIAJgMAAQgLAAgIgIg");
	this.shape.setTransform(18.4,120.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_71_0, new cjs.Rectangle(15.5,117.7,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_71 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAIgGAHQgHAGgIAAQgIAAgGgGg");
	this.shape.setTransform(45.5518,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_71, new cjs.Rectangle(43.5,67.1,4.200000000000003,4.300000000000011), null);


(lib.ClipGroup_70_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAIQgJAJgMAAQgLAAgJgIg");
	this.shape.setTransform(33.075,120.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_70_0, new cjs.Rectangle(30.2,117.7,5.800000000000001,5.799999999999997), null);


(lib.ClipGroup_70 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQABAIgHAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(56.2317,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_70, new cjs.Rectangle(54.2,67.1,4.099999999999994,4.300000000000011), null);


(lib.ClipGroup_69_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQgBAMgHAIQgJAJgMAAQgLAAgJgIg");
	this.shape.setTransform(47.8,120.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_69_0, new cjs.Rectangle(44.9,117.7,5.800000000000004,5.799999999999997), null);


(lib.ClipGroup_69 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAFgGAIAAQAIAAAHAHQAGAFAAAIQAAAJgGAGQgHAGgIAAQgIAAgGgGg");
	this.shape.setTransform(9.25,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_69, new cjs.Rectangle(7.2,76.4,4.2,4.199999999999989), null);


(lib.ClipGroup_68_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAIQgJAJgMAAQgLAAgIgIg");
	this.shape.setTransform(62.475,120.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_68_0, new cjs.Rectangle(59.6,117.7,5.800000000000004,5.799999999999997), null);


(lib.ClipGroup_68 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(19.9268,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_68, new cjs.Rectangle(17.9,76.4,4.100000000000001,4.199999999999989), null);


(lib.ClipGroup_67_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAIQgIAJgMAAQgLAAgJgIg");
	this.shape.setTransform(77.15,120.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_67_0, new cjs.Rectangle(74.3,117.7,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_67 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAJgHAGQgGAGgIAAQgIAAgGgGg");
	this.shape.setTransform(30.625,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_67, new cjs.Rectangle(28.6,76.4,4.100000000000001,4.199999999999989), null);


(lib.ClipGroup_66_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgFAdQgGgJgQgfQAJgRASAAQALAAAJAJQAIAJAAALQAAALgIAJQgJAIgLAAg");
	this.shape.setTransform(12.6,133.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_66_0, new cjs.Rectangle(9.8,130.4,5.6,5.799999999999983), null);


(lib.ClipGroup_66 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAJgHAGQgGAGgIAAQgIAAgGgGg");
	this.shape.setTransform(41.325,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_66, new cjs.Rectangle(39.3,76.4,4.100000000000001,4.199999999999989), null);


(lib.ClipGroup_65_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgHAJgNgBQgLABgIgJg");
	this.shape.setTransform(27.15,133.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_65_0, new cjs.Rectangle(24.3,130.3,5.800000000000001,5.899999999999977), null);


(lib.ClipGroup_65 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAHgGAHAAQAJAAAGAHQAGAFAAAIQAAAJgHAGQgFAGgJAAQgIAAgGgGg");
	this.shape.setTransform(52.05,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_65, new cjs.Rectangle(50,76.4,4.200000000000003,4.199999999999989), null);


(lib.ClipGroup_64_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAJgMgBQgLABgIgJg");
	this.shape.setTransform(41.9,133.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_64_0, new cjs.Rectangle(39,130.3,5.799999999999997,5.899999999999977), null);


(lib.ClipGroup_64 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(62.7268,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_64, new cjs.Rectangle(60.7,76.4,4.099999999999994,4.199999999999989), null);


(lib.ClipGroup_63_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAJgMgBQgLABgJgJg");
	this.shape.setTransform(56.575,133.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_63_0, new cjs.Rectangle(53.7,130.3,5.799999999999997,5.899999999999977), null);


(lib.ClipGroup_63 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgJgRQAIABAFAGQAFAFAAAIQABAJgHAGQgEgLgIgYg");
	this.shape.setTransform(3.9018,87.425);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_63, new cjs.Rectangle(3,85.6,1.9000000000000004,3.700000000000003), null);


(lib.ClipGroup_62_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAJgMgBQgLABgJgJg");
	this.shape.setTransform(71.3,133.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_62_0, new cjs.Rectangle(68.4,130.3,5.799999999999997,5.899999999999977), null);


(lib.ClipGroup_62 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQABAIgGAGQgHAHgJAAQgIAAgGgHg");
	this.shape.setTransform(13.4321,87.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_62, new cjs.Rectangle(11.4,85.7,4.1,4.200000000000003), null);


(lib.ClipGroup_61_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgJgJAAgMQAAgLAJgJQAJgIALAAQAMAAAJAIQAJAJAAALQgBAMgJAJQgJAJgLgBQgLABgJgJg");
	this.shape.setTransform(86.025,133.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_61_0, new cjs.Rectangle(83.1,130.3,5.900000000000006,5.899999999999977), null);


(lib.ClipGroup_61 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQABAIgGAGQgHAHgJAAQgIAAgGgHg");
	this.shape.setTransform(24.1321,87.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_61, new cjs.Rectangle(22.1,85.7,4.099999999999998,4.200000000000003), null);


(lib.ClipGroup_60_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgVgUQAIgFAHAAQAMAAAIAIQAJAJAAALQgBAOgJAJQgTgYgPgWg");
	this.shape.setTransform(19.05,145.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_60_0, new cjs.Rectangle(16.8,143,4.5,5.199999999999989), null);


(lib.ClipGroup_60 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQABAIgGAGQgHAHgJAAQgIAAgGgHg");
	this.shape.setTransform(34.8321,87.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_60, new cjs.Rectangle(32.8,85.7,4.100000000000001,4.200000000000003), null);


(lib.ClipGroup_59_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(33.075,146);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_59_0, new cjs.Rectangle(30.2,143.1,5.800000000000001,5.800000000000011), null);


(lib.ClipGroup_59 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAGgGQAGgGAIAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgHAHgIAAQgIAAgGgHg");
	this.shape.setTransform(45.5518,87.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_59, new cjs.Rectangle(43.5,85.7,4.200000000000003,4.200000000000003), null);


(lib.ClipGroup_58_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQgBAMgHAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(47.8,146);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_58_0, new cjs.Rectangle(44.9,143.1,5.800000000000004,5.800000000000011), null);


(lib.ClipGroup_58 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQABAIgHAGQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(56.2317,87.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_58, new cjs.Rectangle(54.2,85.7,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_57_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgIgIg");
	this.shape.setTransform(62.475,146);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_57_0, new cjs.Rectangle(59.6,143.1,5.800000000000004,5.800000000000011), null);


(lib.ClipGroup_57 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgDAWIgQgdQAFgOAOAAQAJAAAGAHQAFAGAAAIQAAAJgHAGQgGAHgHAAg");
	this.shape.setTransform(9.375,97.025);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_57, new cjs.Rectangle(7.4,94.9,4,4.299999999999997), null);


(lib.ClipGroup_56_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgJgIg");
	this.shape.setTransform(77.15,146);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_56_0, new cjs.Rectangle(74.3,143.1,5.799999999999997,5.800000000000011), null);


(lib.ClipGroup_56 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgHQAGgFAHgBQAJAAAGAHQAGAGAAAIQAAAIgGAHQgHAGgIAAQgIAAgGgGg");
	this.shape.setTransform(19.9268,97.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_56, new cjs.Rectangle(17.9,94.9,4.100000000000001,4.299999999999997), null);


(lib.ClipGroup_55_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgNgMQALAAAIAHQAIAHABALg");
	this.shape.setTransform(28.6,157.175);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_55_0, new cjs.Rectangle(27.2,155.9,2.900000000000002,2.5999999999999943), null);


(lib.ClipGroup_55 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgHQAGgFAHgBQAJAAAGAHQAGAGAAAIQAAAIgHAHQgGAGgIAAQgIAAgGgGg");
	this.shape.setTransform(30.625,97.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_55, new cjs.Rectangle(28.6,94.9,4.100000000000001,4.299999999999997), null);


(lib.ClipGroup_54_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape.setTransform(41.9,158.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_54_0, new cjs.Rectangle(39,155.9,5.799999999999997,5.799999999999983), null);


(lib.ClipGroup_54 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgHQAGgFAHgBQAJAAAGAHQAGAGAAAIQAAAIgHAHQgGAGgIAAQgIAAgGgGg");
	this.shape.setTransform(41.325,97.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_54, new cjs.Rectangle(39.3,94.9,4.100000000000001,4.299999999999997), null);


(lib.ClipGroup_53_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(56.575,158.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_53_0, new cjs.Rectangle(53.7,155.9,5.799999999999997,5.799999999999983), null);


(lib.ClipGroup_53 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAGgHQAHgFAHgBQAJAAAGAHQAGAGAAAIQAAAIgHAHQgFAGgJAAQgIAAgGgGg");
	this.shape.setTransform(52.05,97.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_53, new cjs.Rectangle(50,94.9,4.200000000000003,4.299999999999997), null);


(lib.ClipGroup_52_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(71.3,158.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_52_0, new cjs.Rectangle(68.4,155.9,5.799999999999997,5.799999999999983), null);


(lib.ClipGroup_52 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgHQAGgFAHgBQAJAAAGAHQAGAGAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(62.7268,97.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_52, new cjs.Rectangle(60.7,94.9,4.099999999999994,4.299999999999997), null);


(lib.ClipGroup_51_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgJgIAAgMQAAgLAJgIQAJgJALAAQAMAAAJAJQAJAIAAALQgBAMgJAIQgJAJgLAAQgLAAgJgJg");
	this.shape.setTransform(86.025,158.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_51_0, new cjs.Rectangle(83.1,155.9,5.900000000000006,5.799999999999983), null);


(lib.ClipGroup_51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgQgOQAFgEAHAAQAIABAGAGQAGAGAAAIQACAJgJAGQgPgSgKgOg");
	this.shape.setTransform(13.9113,106);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_51, new cjs.Rectangle(12.3,104.2,3.299999999999999,3.700000000000003), null);


(lib.ClipGroup_50_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgZgHQAIgLAPAAQALAAAJAJQAIAIAAALIgBAJg");
	this.shape.setTransform(48,170.525);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_50_0, new cjs.Rectangle(45.4,168.7,5.200000000000003,3.700000000000017), null);


(lib.ClipGroup_50 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQABAIgGAHQgHAGgJAAQgIAAgGgGg");
	this.shape.setTransform(24.1321,106.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_50, new cjs.Rectangle(22.1,104.3,4.099999999999998,4.200000000000003), null);


(lib.ClipGroup_49_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgIgJg");
	this.shape.setTransform(62.475,171.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_49_0, new cjs.Rectangle(59.6,168.6,5.800000000000004,5.800000000000011), null);


(lib.ClipGroup_49 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQABAIgGAHQgHAGgJAAQgIAAgGgGg");
	this.shape.setTransform(34.8321,106.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_49, new cjs.Rectangle(32.8,104.3,4.100000000000001,4.200000000000003), null);


(lib.ClipGroup_48_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(77.15,171.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_48_0, new cjs.Rectangle(74.3,168.6,5.799999999999997,5.800000000000011), null);


(lib.ClipGroup_48 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAGgGQAGgGAIAAQAJAAAGAHQAGAFAAAIQAAAIgGAHQgHAGgIAAQgIAAgGgGg");
	this.shape.setTransform(45.5518,106.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_48, new cjs.Rectangle(43.5,104.3,4.200000000000003,4.200000000000003), null);


(lib.ClipGroup_47_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgOABQAJgDAFAAQAIAAAHAFg");
	this.shape.setTransform(86.05,181.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_47_0, new cjs.Rectangle(84.6,181.4,3,0.5), null);


(lib.ClipGroup_47 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQABAIgHAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(56.2317,106.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_47, new cjs.Rectangle(54.2,104.3,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_46_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(92.575,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_46_0, new cjs.Rectangle(89.7,92.2,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_46 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgJgJQAIABAEAGQAHAEAAAIIgTgTg");
	this.shape.setTransform(21,114.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_46, new cjs.Rectangle(20,113.4,2.1000000000000014,2), null);


(lib.ClipGroup_45_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(107.3,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_45_0, new cjs.Rectangle(104.4,92.2,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_45 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgHAHABQAJAAAGAGQAGAGAAAIQAAAIgHAHQgGAGgIABQgIgBgGgGg");
	this.shape.setTransform(30.625,115.55);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_45, new cjs.Rectangle(28.6,113.4,4.100000000000001,4.299999999999997), null);


(lib.ClipGroup_44_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgIgJg");
	this.shape.setTransform(121.975,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_44_0, new cjs.Rectangle(119.1,92.2,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_44 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgHAHABQAJAAAGAGQAGAGAAAIQAAAIgHAHQgGAGgIABQgIgBgGgGg");
	this.shape.setTransform(41.325,115.55);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_44, new cjs.Rectangle(39.3,113.4,4.100000000000001,4.299999999999997), null);


(lib.ClipGroup_43_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgHAJgNAAQgLAAgIgJg");
	this.shape.setTransform(136.65,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_43_0, new cjs.Rectangle(133.8,92.2,5.799999999999983,5.799999999999997), null);


(lib.ClipGroup_43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAGgGQAHgHAHABQAJAAAGAGQAGAGAAAIQAAAIgHAHQgFAGgJABQgIgBgGgGg");
	this.shape.setTransform(52.05,115.55);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_43, new cjs.Rectangle(50,113.4,4.200000000000003,4.299999999999997), null);


(lib.ClipGroup_42_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(151.4,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_42_0, new cjs.Rectangle(148.5,92.2,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgHAHABQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJABQgIgBgGgGg");
	this.shape.setTransform(62.7268,115.55);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_42, new cjs.Rectangle(60.7,113.4,4.099999999999994,4.299999999999997), null);


(lib.ClipGroup_41_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(166.075,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_41_0, new cjs.Rectangle(163.2,92.2,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgSgFQAHgIAKAAQAIAAAGAGQAGAHAAAHQAAACgBAFQgQgIgUgLg");
	this.shape.setTransform(35.1063,124.15);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_41, new cjs.Rectangle(33.2,122.8,3.799999999999997,2.799999999999997), null);


(lib.ClipGroup_40_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AAKAdQgLAAgJgJQgJgIABgMIABgIIASgSIAJgCQAEAAAGACQAAAcgDAbg");
	this.shape.setTransform(179.85,95.1);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_40_0, new cjs.Rectangle(177.9,92.2,3.9000000000000057,5.799999999999997), null);


(lib.ClipGroup_40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgHAGgHQAGgGAIAAQAJAAAGAGQAGAHAAAHQAAAJgGAFQgHAHgIAAQgIAAgGgHg");
	this.shape.setTransform(45.5518,124.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_40, new cjs.Rectangle(43.5,122.8,4.200000000000003,4.200000000000003), null);


(lib.ClipGroup_39_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFE422").s().p("AAJgIIgRARQAFgOAMgDg");
	this.shape.setTransform(178.9,93.2);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_39_0, new cjs.Rectangle(178,92.3,1.8000000000000114,1.7999999999999972), null);


(lib.ClipGroup_39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQABAJgHAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(56.2317,124.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_39, new cjs.Rectangle(54.2,122.8,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_38_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(101.4,107.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_38_0, new cjs.Rectangle(98.5,104.9,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgKABQADgBAHAAQAGgCAFAEg");
	this.shape.setTransform(62.8,132.1942);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_38, new cjs.Rectangle(61.7,132.1,2.1999999999999957,0.30000000000001137), null);


(lib.ClipGroup_37_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(116.075,107.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_37_0, new cjs.Rectangle(113.2,104.9,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAHgGAHAAQAJAAAGAGQAGAGAAAIQAAAIgGAHQgHAGgIAAQgIAAgGgGg");
	this.shape.setTransform(67.55,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_37, new cjs.Rectangle(65.5,67.1,4.200000000000003,4.300000000000011), null);


(lib.ClipGroup_36_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(130.8,107.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_36_0, new cjs.Rectangle(127.9,104.9,5.799999999999983,5.799999999999997), null);


(lib.ClipGroup_36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(78.2268,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_36, new cjs.Rectangle(76.2,67.1,4.099999999999994,4.300000000000011), null);


(lib.ClipGroup_35_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgIgIg");
	this.shape.setTransform(145.475,107.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_35_0, new cjs.Rectangle(142.6,104.9,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(88.9269,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_35, new cjs.Rectangle(86.9,67.1,4.099999999999994,4.300000000000011), null);


(lib.ClipGroup_34_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgWARQgFgHAAgJQAAgLAJgIQAIgJALAAQAJAAAIAGQAHAFADAHIglAlQgIgDgFgIg");
	this.shape.setTransform(160.05,107.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_34_0, new cjs.Rectangle(157.3,104.9,5.599999999999994,5.599999999999994), null);


(lib.ClipGroup_34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(99.625,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_34, new cjs.Rectangle(97.6,67.1,4.1000000000000085,4.300000000000011), null);


(lib.ClipGroup_33_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFE422").s().p("AgTASIAlglQACAEAAAHQAAAKgFAGIgGAGQgIAGgJAAQgFAAgGgCg");
	this.shape.setTransform(161.05,108.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_33_0, new cjs.Rectangle(159.1,106.7,4,4), null);


(lib.ClipGroup_33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(110.325,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_33, new cjs.Rectangle(108.3,67.1,4.1000000000000085,4.300000000000011), null);


(lib.ClipGroup_32_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(174.9,107.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_32_0, new cjs.Rectangle(172,104.9,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAFgGAIAAQAJAAAGAGQAGAGAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(121.05,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_32, new cjs.Rectangle(119,67.1,4.200000000000003,4.300000000000011), null);


(lib.ClipGroup_31_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAIQgJAJgMAAQgLAAgJgIg");
	this.shape.setTransform(92.575,120.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_31_0, new cjs.Rectangle(89.7,117.7,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgHAPQgGgGAAgJQAAgIAHgGQAGgGAHAAIAHABQAAAVgCASIgFABQgIAAgGgGg");
	this.shape.setTransform(131.025,69.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_31, new cjs.Rectangle(129.7,67.1,2.700000000000017,4.300000000000011), null);


(lib.ClipGroup_30_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAIQgIAJgMAAQgLAAgJgIg");
	this.shape.setTransform(107.3,120.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_30_0, new cjs.Rectangle(104.4,117.7,5.799999999999997,5.799999999999997), null);


(lib.ClipGroup_30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(73.9269,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_30, new cjs.Rectangle(71.9,76.4,4.099999999999994,4.199999999999989), null);


(lib.ClipGroup_29_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAIQgJAJgMAAQgLAAgIgIg");
	this.shape.setTransform(121.975,120.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_29_0, new cjs.Rectangle(119.1,117.7,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(84.625,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_29, new cjs.Rectangle(82.6,76.4,4.1000000000000085,4.199999999999989), null);


(lib.ClipGroup_28_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAIQgIAJgMAAQgLAAgIgIg");
	this.shape.setTransform(136.65,120.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_28_0, new cjs.Rectangle(133.8,117.7,5.799999999999983,5.799999999999997), null);


(lib.ClipGroup_28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(95.325,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_28, new cjs.Rectangle(93.3,76.4,4.1000000000000085,4.199999999999989), null);


(lib.ClipGroup_27_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVIAogoQAJAIAAALQAAAMgKAIQgIAKgMgBQgLABgIgJgAgdAAQAAgLAIgJQAJgJAMABIAFAAIghAig");
	this.shape.setTransform(151.4,120.55);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_27_0, new cjs.Rectangle(148.4,117.6,6,5.900000000000006), null);


(lib.ClipGroup_27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAHgGAHAAQAJAAAGAHQAGAFAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(106.05,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_27, new cjs.Rectangle(104,76.4,4.200000000000003,4.199999999999989), null);


(lib.ClipGroup_26_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFE422").s().p("AgYAKIAigiQAIABAHAIIgoAoQgJgIAAgHg");
	this.shape.setTransform(151.025,120.15);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_26_0, new cjs.Rectangle(148.5,117.6,5.099999999999994,5.1000000000000085), null);


(lib.ClipGroup_26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(116.7268,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_26, new cjs.Rectangle(114.7,76.4,4.099999999999994,4.199999999999989), null);


(lib.ClipGroup_25_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAIQgJAJgMAAQgLAAgJgIg");
	this.shape.setTransform(166.075,120.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_25_0, new cjs.Rectangle(163.2,117.7,5.800000000000011,5.799999999999997), null);


(lib.ClipGroup_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgGAAgJQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQABAJgGAGQgHAGgJAAQgIAAgGgGg");
	this.shape.setTransform(127.4321,78.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_25, new cjs.Rectangle(125.4,76.4,4.099999999999994,4.199999999999989), null);


(lib.ClipGroup_24_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAJgMgBQgLABgIgJg");
	this.shape.setTransform(101.4,133.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_24_0, new cjs.Rectangle(98.5,130.3,5.799999999999997,5.899999999999977), null);


(lib.ClipGroup_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAGgGQAHgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgHAHgIAAQgIAAgGgHg");
	this.shape.setTransform(67.55,87.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_24, new cjs.Rectangle(65.5,85.7,4.200000000000003,4.200000000000003), null);


(lib.ClipGroup_23_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAJgMgBQgLABgJgJg");
	this.shape.setTransform(116.075,133.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_23_0, new cjs.Rectangle(113.2,130.3,5.799999999999997,5.899999999999977), null);


(lib.ClipGroup_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(78.2268,87.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_23, new cjs.Rectangle(76.2,85.7,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_22_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAJgMgBQgLABgIgJg");
	this.shape.setTransform(130.8,133.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_22_0, new cjs.Rectangle(127.9,130.3,5.799999999999983,5.899999999999977), null);


(lib.ClipGroup_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(88.9269,87.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_22, new cjs.Rectangle(86.9,85.7,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_21_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAJgMgBQgLABgIgJg");
	this.shape.setTransform(145.475,133.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_21_0, new cjs.Rectangle(142.6,130.3,5.800000000000011,5.899999999999977), null);


(lib.ClipGroup_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(99.625,87.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_21, new cjs.Rectangle(97.6,85.7,4.1000000000000085,4.200000000000003), null);


(lib.ClipGroup_20_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgNAaIAmgoQAFAFAAAJQAAAMgJAJQgIAJgNgBQgHAAgGgDgAgdAAQAAgLAJgJQAJgIALAAQAHAAAGACIgmAmQgDgHgBgFg");
	this.shape.setTransform(160.1,133.25);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_20_0, new cjs.Rectangle(157.2,130.3,5.900000000000006,5.899999999999977), null);


(lib.ClipGroup_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(110.325,87.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_20, new cjs.Rectangle(108.3,85.7,4.1000000000000085,4.200000000000003), null);


(lib.ClipGroup_19_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFE422").s().p("AgZANIAmgmQAJAFAEAHIgnAnQgIgFgEgIg");
	this.shape.setTransform(160.1,133.225);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19_0, new cjs.Rectangle(157.5,130.6,5.199999999999989,5.300000000000011), null);


(lib.ClipGroup_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgGAAgIQAAgIAHgGQAFgGAIAAQAJAAAGAHQAGAGAAAHQAAAIgGAGQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(121.05,87.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19, new cjs.Rectangle(119,85.7,4.200000000000003,4.200000000000003), null);


(lib.ClipGroup_18_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAJAIQAIAJAAALQAAAMgIAJQgJAIgMAAQgLAAgJgIg");
	this.shape.setTransform(92.575,146);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18_0, new cjs.Rectangle(89.7,143.1,5.799999999999997,5.800000000000011), null);


(lib.ClipGroup_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgHQAGgFAHgBQAJAAAGAHQAGAGAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(73.9269,97.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18, new cjs.Rectangle(71.9,94.9,4.099999999999994,4.299999999999997), null);


(lib.ClipGroup_17_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgJgIg");
	this.shape.setTransform(107.3,146);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17_0, new cjs.Rectangle(104.4,143.1,5.799999999999997,5.800000000000011), null);


(lib.ClipGroup_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgHQAGgFAHgBQAJAAAGAHQAGAGAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(84.625,97.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17, new cjs.Rectangle(82.6,94.9,4.1000000000000085,4.299999999999997), null);


(lib.ClipGroup_16_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgWASQgFgIAAgJQAAgLAJgJQAIgIAMAAQAIAAAIAFQAHAFADAIIglAlQgHgDgGgHg");
	this.shape.setTransform(121.85,145.9);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16_0, new cjs.Rectangle(119.1,143.1,5.6000000000000085,5.599999999999994), null);


(lib.ClipGroup_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgHQAGgFAHgBQAJAAAGAHQAGAGAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(95.325,97.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16, new cjs.Rectangle(93.3,94.9,4.1000000000000085,4.299999999999997), null);


(lib.ClipGroup_15_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFE422").s().p("AgTATIAlgmIACALQAAAKgGAIIgGAFQgIAFgIAAQgHAAgEgBg");
	this.shape.setTransform(122.9,146.9);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_15_0, new cjs.Rectangle(120.9,144.9,4,4), null);


(lib.ClipGroup_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAGgHQAHgFAHgBQAJAAAGAHQAGAGAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(106.05,97.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_15, new cjs.Rectangle(104,94.9,4.200000000000003,4.299999999999997), null);


(lib.ClipGroup_14_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAVQgJgJAAgMQAAgLAJgJQAIgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgHAIgNAAQgLAAgIgIg");
	this.shape.setTransform(136.65,146);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14_0, new cjs.Rectangle(133.8,143.1,5.799999999999983,5.800000000000011), null);


(lib.ClipGroup_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgHQAGgFAHgBQAJAAAGAHQAGAGAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(116.7268,97.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14, new cjs.Rectangle(114.7,94.9,4.099999999999994,4.299999999999997), null);


(lib.ClipGroup_13_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgIgIAAgMIAdgdQALAAAJAJQAIAIAAALQAAAMgJAJQgIAJgMgBQgLABgJgJg");
	this.shape.setTransform(151.4,145.95);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13_0, new cjs.Rectangle(148.5,143,5.800000000000011,5.900000000000006), null);


(lib.ClipGroup_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAGgGQAHgGAHAAQAJAAAGAHQAGAFAAAIQAAAIgGAHQgHAGgIAAQgIAAgGgGg");
	this.shape.setTransform(67.55,106.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13, new cjs.Rectangle(65.5,104.3,4.200000000000003,4.200000000000003), null);


(lib.ClipGroup_12_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFE422").s().p("AgOAOQAAgMAIgIQAIgIAMAAIABAAIgdAdg");
	this.shape.setTransform(149.9,144.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12_0, new cjs.Rectangle(148.4,143.1,3,3), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(78.2268,106.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(76.2,104.3,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_11_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgEgDQAFgIAJgDQgMAUgHAIQAAgKAFgHg");
	this.shape.setTransform(164.1,144.65);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11_0, new cjs.Rectangle(163.1,143.2,2.0999999999999943,2.9000000000000057), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(88.9269,106.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(86.9,104.3,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_10_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgIgJg");
	this.shape.setTransform(101.4,158.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10_0, new cjs.Rectangle(98.5,155.9,5.799999999999997,5.799999999999983), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(99.625,106.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(97.6,104.3,4.1000000000000085,4.200000000000003), null);


(lib.ClipGroup_9_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAVQgHgHgCgMIAfgeQALABAIAJQAJAIAAAKQgBAMgIAIQgKAJgLAAQgLAAgJgIg");
	this.shape.setTransform(116.1,158.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9_0, new cjs.Rectangle(113.2,155.9,5.8999999999999915,5.799999999999983), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgGAHAAQAJAAAGAHQAGAFAAAIQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(110.325,106.35);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(108.3,104.3,4.1000000000000085,4.200000000000003), null);


(lib.ClipGroup_8_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFE422").s().p("AgPAOQAAgMAJgIQAIgIALAAIADAAIgfAdg");
	this.shape.setTransform(114.7,157.375);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8_0, new cjs.Rectangle(113.2,155.9,3.0999999999999943,3), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgCgCQADgGAHgCIgPAVQAAgIAFgFg");
	this.shape.setTransform(119.625,105.3);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(118.9,104.3,1.5,2.1000000000000085), null);


(lib.ClipGroup_7_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgVATQgHgIAAgLQAAgLAJgIQAIgJALAAQALAAAIAHQAIAIACAKIggAgQgKgCgIgIg");
	this.shape.setTransform(130.8,158.7);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7_0, new cjs.Rectangle(127.9,155.8,5.799999999999983,5.799999999999983), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgHAHABQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJABQgIgBgGgGg");
	this.shape.setTransform(73.9269,115.55);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(71.9,113.4,4.099999999999994,4.299999999999997), null);


(lib.ClipGroup_6_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFE422").s().p("AgPARIAgghIAAAEQgBAMgIAIQgIAJgMAAg");
	this.shape.setTransform(132.05,160.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6_0, new cjs.Rectangle(130.4,158.4,3.299999999999983,3.299999999999983), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgHAHABQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJABQgIgBgGgGg");
	this.shape.setTransform(84.625,115.55);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(82.6,113.4,4.1000000000000085,4.299999999999997), null);


(lib.ClipGroup_5_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgTAUQgJgIAAgMQAAgLAJgIQAIgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgIgJg");
	this.shape.setTransform(145.475,158.8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5_0, new cjs.Rectangle(142.6,155.9,5.800000000000011,5.799999999999983), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAHgGQAGgHAHABQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJABQgIgBgGgGg");
	this.shape.setTransform(95.325,115.55);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(93.3,113.4,4.1000000000000085,4.299999999999997), null);


(lib.ClipGroup_4_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAJAJQAIAIAAALQAAAMgIAIQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(92.575,171.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_0, new cjs.Rectangle(89.7,168.6,5.799999999999997,5.800000000000011), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAPQgGgHAAgIQAAgIAGgGQAHgHAHABQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJABQgIgBgGgGg");
	this.shape.setTransform(106.05,115.55);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(104,113.4,4.200000000000003,4.299999999999997), null);


(lib.ClipGroup_3_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgUAUQgIgIAAgMQAAgLAIgIQAJgJALAAQAMAAAIAJQAJAIAAALQAAAMgJAIQgIAJgMAAQgLAAgJgJg");
	this.shape.setTransform(107.3,171.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_0, new cjs.Rectangle(104.4,168.6,5.799999999999997,5.800000000000011), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgHAGgHQAHgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAFQgHAHgIAAQgIAAgGgHg");
	this.shape.setTransform(67.55,124.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(65.5,122.8,4.200000000000003,4.200000000000003), null);


(lib.ClipGroup_2_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD51B").s().p("AgNAZIAmgmQAFAKAAAEQAAALgJAJQgJAJgLAAQgJAAgFgFgAgdAAQAAgLAJgJQAJgJALAAQAGAAAHAEIgmAmQgEgHAAgGg");
	this.shape.setTransform(121.95,171.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_0, new cjs.Rectangle(119,168.5,5.900000000000006,5.900000000000006), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(78.2268,124.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(76.2,122.8,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_1_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlhNGQijhFh+h+Qh9h+hGijQhHipAAi5QAAi4BHipQBGijB9h+QB+h+CjhFQCphHC4AAQC5AACpBHQCjBFB+B+QB9B+BGCjQBHCpAAC4QAAC5hHCpQhGCjh9B+Qh+B+ijBFQipBHi5AAQi4AAiphHg");
	mask.setTransform(90.9,90.925);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFE422").s().p("AgZANIAmgmQAHADAGAJIgnAnQgIgEgEgJg");
	this.shape.setTransform(121.9,171.4);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_0, new cjs.Rectangle(119.3,168.8,5.200000000000003,5.199999999999989), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgOAOQgGgFAAgJQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAFQgGAHgJAAQgIAAgGgHg");
	this.shape.setTransform(88.9269,124.85);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(86.9,122.8,4.099999999999994,4.200000000000003), null);


(lib.ClipGroup_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnTHUQjCjCAAkSQAAkRDCjCQDBjCESAAQETAADBDCQDCDCAAERQAAESjCDCQjBDCkTAAQkRAAjCjCg");
	mask.setTransform(66.2,66.1749);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgGgDQAFgGAIABQADAAAEABQgNAJgOAIQABgJAGgEg");
	this.shape.setTransform(98.975,123.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0, new cjs.Rectangle(97.6,122.7,2.8000000000000114,1.8999999999999915), null);


(lib.hit_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("EgiTgO3MBEnAAAQChAAByByQBzByAACiIAARjQAACihzByQhyByihAAMhEnAAAQihAAhzhyQhyhyAAiiIAAxjQAAiiByhyQBzhyChAAg");
	this.shape.setTransform(0,0.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#273864").s().p("EgiSAO4QiiAAhyhyQhzhyAAiiIAAxjQAAiiBzhyQByhyCiAAMBElAAAQCiAAByByQByByABCiIAARjQgBCihyByQhyByiiAAg");
	this.shape_1.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-259.5,-96.2,519.1,192.5);


(lib.ClipGroup_1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Eg9AAxVMAAAhipMB6BAAAMAAABipg");
	mask_1.setTransform(390.475,315.7);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#493728").s().p("Al3BdQBFhbBZg9QEYjHFtCeQhrgPihAbQlAA1kKDOg");
	this.shape_1.setTransform(351.6,221.5085);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#493728").s().p("AAJi7QBzgnBwAaQjfASiRDGQhJBkgdBgQAOlBDlhOg");
	this.shape_2.setTransform(177.05,296.3459);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#493728").s().p("Ak1idQCbiQDignQCjgbC3AbQBcAOA7ATQnegLl5FPQh2BpheB/QguA/gYArQBDlODAiyg");
	this.shape_3.setTransform(281.925,217.3812);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DCDDDD").s().p("ACjHZQjFhnhzi+Qhyi9AAjfIAAgIQABiHAuh/QAyCLBiBwQBhBxCGBHIBlA1IgzBlQgwBfAABrQAABjAqBaIAMAZg");
	this.shape_4.setTransform(105.175,416.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DCDDDD").s().p("AFBTIQiJhFhZh6Ig5hNIhVApQiAA7iNAAQhqAAhjgiQhjgihUhAIhYhFIhIBWQhzCJigBLQifBLiyAAQkCAAjRiWQjRiXhQj1IgihjIhmAWQgwALgxgBQi7AAiFiEQiFiFAAi8IABgIQAChoAthZIAlhLQBABXBfAxQBiA0BvgBQAxAAAwgKIBmgWIAiBjQBQD1DRCXQDRCWECAAQCxAACghLQCghLBziJIBIhVIBYBEQBUBBBjAhQBjAiBqAAQCNAACAg7IBVgpIA5BNQCmB1BwAjQBbAdCjAAQDhgBCliNQCQh9BNjSIAOh6IB5AVQBFAMBEAAQCiAACVg/QCRg8BwhvQBwhvA9iQQBBiVABijIABhQIBLgcQCpg/B+iCQB8iAA8inQAtB/ABCJIABAJQAAD7iRDRQiRDQjsBZIhLAbIgBBRQgBCihBCVQg9CPhwBwQhwBuiRA9QiVBAiigBQhDAAhGgLIh5gVIgOB6QgeDti1CfQi0CfjwAAQiXAAiHhEg");
	this.shape_5.setTransform(413.6,482.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("A7AeMQjRiXhRj1IghhjIhmAWQgwAKgxAAQhvABhjg0Qhfgyg/hXIglBLQgtBagDBoIAAgKQAAhrAwhfIAzhnIg6gdQgphbAAhiQAAhsAwhfIAzhmIhmg1QiFhHhjhwQhhhxgyiKQgtB8gDCEIAAgEQAAj7CRjPQCRjNDrhVIBNgcIAAhTQAAiyB5iCQB6iDCxgNIBmgHIAGhnQALjHBUi0QBSiuCNiEQCMiGCyhIQC5hLDIABQCOAACHAmQCIAmB4BKIBZA2IBAhRQBOhjByg4QBvg2B/AAQClAACIBaIBJAvIBCg3QBhhRB4gsQB3grB/AAQEIAADJCpQDJCpAtEEIATBvIBvgOQA2gIAyAAQCkAACWBAQCRA+BwBvQBwBwA9CRQBACWAACkQAABcgVBaIgRBJIA8AuQCZBzBVCpQBUCoAADAIgBAJQgBiJgth/Qg8Cnh8CAQh/CCioA/IhMAcIAABQQgBCjhBCVQg9CQhwBvQhwBviRA9QiVA/ijAAQhEAAhFgMIh4gVIgPB6QhMDSiQB9QilCNjiABQiiAAhbgdQhwgjimh1Ig5hNIhXApQh/A7iMAAQhqAAhjgiQhjghhUhBIhZhEIhIBVQhyCJigBLQigBLiyAAQkCAAjQiWgEghdgKQQjmBOgOFBQAdhgBJhjQCTjIDegSQgtgKgsAAQhFAAhFAYgAwF4/QjjAnibCPQjAC0hDFNQAYgqAug/QBeiAB2hoQF6lRHeAMQg7gUhcgOQhagNhWAAQhXAAhTAOgApvz8QhYA+hFBaIg0BOQELjOFBg2QCggbBqAPQighGiRAAQi3AAidBwg");
	this.shape_6.setTransform(392.125,343.3);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_1, new cjs.Rectangle(78.8,135.1,626.7,477), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Eg9AAxVMAAAhipMB6BAAAMAAABipg");
	mask.setTransform(390.475,315.7);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#493728").s().p("EAKQAqxQihhThsiTQibBJitAAQiMAAhcgpQhqgxiDiLQiSCvisBpQjNB+jKAAQk0AAj4i2QjziyhekcQg8ANhBAAQj0AAidiZQidiaAAjyQAAhCAfhlQAahXAihEQjzh/iWjJQipjiAAkBQAAkCCDjbQB/jXDYh8QiNi5nTmnIm4mCQECDJGYDxQEKCdEhCWQA2iqCLhwQCOhxC1gNQANjkBhjOQBejICgiYQChiZDMhTQDUhXDnABQEAAADpBrQAZkZg7oEIASBjQAWB3AaBuQBSFdBPBtQBdhXB2gxQB7gxCGAAQBbAABzA6QA5AdB9BTQCMh/Bzg8QCLhHCTAAQE+AADxDNQDvDLA1E0QA+gJA9ABQDCgBCxBLQCrBICDCFQCECDBICrQBLCxAADBIgBApQBoATB3AJQDOAPCrgXQhrAXh4ApQjwBRhDBWQCJCEBLCuQBNCyAADGQAAErjEDpQi8Dek1BdQAPDDg9C4Qg8Cwh5CLQh7CLilBNQirBQjAAAQhQgBhSgOQgkEhjZDCQjcDEknAAQi9gBimhWgEAHaAlDQBaB6CIBFQCHBECXAAQDwAAC1ifQC0ifAejtIAPh5IB4AUQBGAMBDAAQCjAACVg/QCQg9BwhvQBwhvA+iQQBAiUABikIABhQIBLgcQDshYCRjRQCRjQAAj8IAAgSQAAi/hUipQhUioiZhzIg8guIAQhKQAVhaAAhcQAAikg/iWQg+iQhvhwQhwhwiRg9QiWhAikAAQgyAAg3AHIhvAPIgThvQgskEjJipQjJiqkJAAQh/AAh3AsQh4ArhgBSIhDA3IhIgvQiJhaikAAQh/AAhxA2QhwA3hPBkIhABRIhYg2Qh4hLiIgmQiIgmiOAAQjIAAi4BLQiyBIiNCFQiMCEhSCuQhVC1gLDHIgFBnIhnAHQiwANh6CDQh6CCAACyIAABSIhMAcQjsBWiQDOQiRDNAAD7IAAASQAADfByC+QBzC+DGBnIA4AdIgMgYIA5AeIgzBmQgwBgAABrIAAASQAAC7CFCFQCFCFC7AAQAxAAAwgKIBngXIAhBjQBRD1DQCXQDRCXECAAQCygBCghKQCghMByiJIBIhVIBYBEQBVBBBiAhQBjAjBpAAQCNgBCAg7IBWgog");
	this.shape.setTransform(375.675,349.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,66.7,751.4,564.6999999999999), null);


(lib.ClipGroup_1_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("EguKAHcIAAu3MBcVAAAIAAO3g");
	mask_2.setTransform(295.5,47.575);

	// Layer_3
	this.instance = new lib.Group_0();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_2, new cjs.Rectangle(0,0,591,95.2), null);


(lib.ClipGroup_0_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EhT5BTIMAAAimQMCnzAAAMAAACmQg");
	mask_1.setTransform(537,532.05);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgfPBJ+QuamGrHrHQrHrImGuZQmTu7AAwVQAAwUGTu7QGGuaLHrHQLHrHOamGQO6mTQVgBQQVABO7GTQOZGGLILHQLHLHGGOaQGTO7AAQUQAAQWmTO6QmGOZrHLIQrILHuZGGQu7GTwVABQwVgBu6mTg");
	this.shape_1.setTransform(522.975,521.05);

	this.instance = new lib.Group();
	this.instance.setTransform(10.55,8.65);

	var maskedShapeInstanceList = [this.shape_1,this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0_1, new cjs.Rectangle(9.3,7.3,1054.3,1054.4), null);


(lib.ClipGroup_160 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AymlZIQUt4IU5YrIwVN4g");
	mask_1.setTransform(119.1,123.375);

	// Layer_3
	this.instance = new lib.Image();
	this.instance.setTransform(0,88.75,0.3532,0.3533,0,-40.2574,-40.3631);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_160, new cjs.Rectangle(0,0,238.2,246.8), null);


(lib.d7_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00BFF3").s().p("AoIIDIQRwHIgFQEQkEADkBABIlMABQi6AAgBgCg");
	this.shape.setTransform(52.125,51.665);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d7_4, new cjs.Rectangle(0,0,104.3,103.4), null);


(lib.d7_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EAE0BC").s().p("AgrHaQoEgngBgDIRhuwIhZQBQkBgTkCgUg");
	this.shape.setTransform(56.1,51.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d7_3, new cjs.Rectangle(0,0,112.2,102.5), null);


(lib.d7_2_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BB634F").s().p("An/CsIgCh0IgBgNIAAgqQgHm9ACg/IgBgKIFVFSIByBuICQCNIBtBsIFNFMImEABIh+ACIinABIlZACIgGlag");
	this.shape.setTransform(52.1,51.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d7_2_3, new cjs.Rectangle(0,0,104.2,103.6), null);


(lib.d7_2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF8A17").s().p("AnwCsIgLh0IgCgMIgDgrQgqm6gEhAIgBgKIFvE3IB6BkICbCCIB1BjIFmEwImDAgIh9ALIinAPIlYAdIghlYg");
	this.shape.setTransform(56,51.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d7_2_2, new cjs.Rectangle(0,0,112,103.2), null);


(lib.d7_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EAE9BC").s().p("AnYCpIgXhxIgCgNIgJgpQhWm1gKg+IgCgLIGMERICEBYICnByIB/BVIGDELIl+BGIh8AYIikAgIlUBAIhDlUg");
	this.shape.setTransform(60.475,50.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d7_2_1, new cjs.Rectangle(0,0,121,101.8), null);


(lib.d7_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF5C17").s().p("AhbGjQn+hYgBgDIS1tBIi4PzQkAgrj+gsg");
	this.shape.setTransform(60.275,50.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d7_2, new cjs.Rectangle(0,0,120.6,101.2), null);


(lib.d7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BB634F").s().p("AgPFuIhtgmIgMgEIgogPQmkiWg7gXIgJgEIG0jHICPhEIC4hWICKhBIGsjDIiHFrIgrB2Ig5CeIh4FEIlFh0g");
	this.shape.setTransform(66.525,48.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d7_1, new cjs.Rectangle(0,0,133.1,96.5), null);


(lib.d6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.ribbon, null, new cjs.Matrix2D(0.479,0,0,0.479,-835.9,-266.3)).s().p("EiCnApoMAAAhTPMEFPAAAMAAABTPg");
	this.shape.setTransform(835.95,266.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d6, new cjs.Rectangle(0,0,1671.9,532.7), null);


(lib.d4_sp1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDE26").s().p("Ay/Q8IGSgDIAAnNIHsAAIAAnMIHLAAIAAnLIHMAAIAAnMIHMAAIAAniICeAAIAAJ/InMAAIAAHMInMAAIAAHLInMAAIAAHNInrAAIAAHLIotAFg");
	this.shape.setTransform(121.6,124.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d4_sp1, new cjs.Rectangle(0,0,243.2,248.4), null);


(lib.d4_l1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDE26").s().p("AlnFnQgYgZAAgiQAAgiAYgZIJYpYQAZgYAiAAQAjAAAYAYQAZAZAAAiQAAAjgZAYIpYJYQgYAZgjAAQgiAAgZgZg");
	this.shape.setTransform(38.425,38.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d4_l1, new cjs.Rectangle(0,0,76.9,76.9), null);


(lib.d4_d1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDE26").s().p("AloA+QAAiuB8h8QB8h7CuAAQCuAAB8B7IpUJUQh8h7AAivg");
	this.shape.setTransform(36.05,36.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d4_d1, new cjs.Rectangle(0,0,72.1,72.1), null);


(lib.d2_s1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDB1E").s().p("AgkAmQgQgQAAgWIACgPIAAgBQAGgQANgKQAOgKARAAQAVAAAQAPQAPARAAAUQABAVgPARQgPAPgWAAQgVAAgQgPg");
	this.shape.setTransform(6.353,114.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFDB1E").s().p("AglAlQgPgPAAgWQAAgVAPgQQAQgPAVAAQAWAAAPAPQAQAQAAAVQAAAVgQAQQgPAQgWAAQgVAAgQgQg");
	this.shape_1.setTransform(16.625,187.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFDB1E").s().p("AgqArQgSgRAAgaQAAgQAJgPQAJgPAOgHQAKgFAIgBIAKgBQAYAAASASQASARAAAZQABAZgSASQgSASgZAAQgYAAgSgSg");
	this.shape_2.setTransform(147.7026,228.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFDB1E").s().p("AgqAsQgSgTAAgZQAAgbAWgTIANgIQAMgGANAAQAaAAARASQASASAAAYQgBAZgRATQgSARgZAAQgZAAgRgRg");
	this.shape_3.setTransform(47.425,57.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFDB1E").s().p("AgqArQgSgSAAgZQAAgSAKgPQAFgHAIgHQAQgMAVAAQAZAAASASQASARAAAZQAAAYgTASQgSARgYAAQgZAAgRgRg");
	this.shape_4.setTransform(215.55,179.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFDB1E").s().p("AhBBCQgbgcAAgmQAAgmAbgbQAcgbAlAAQAnAAAbAbQAbAbAAAmQAAAngbAbQgcAbgmAAQglAAgcgbg");
	this.shape_5.setTransform(72.825,11.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFDB1E").s().p("AhABCQgcgbAAgnQAAgmAbgbQAbgbAmAAQAmAAAbAbQAcAcAAAlQAAAngcAbQgbAbgmAAQglAAgbgbg");
	this.shape_6.setTransform(50.25,226);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFDB1E").s().p("AhABCQgbgbgBgnQAAghAYgbQAWgZAhgGIAOgBQAmAAAbAcQAaAbABAlQgBAVgGANQgKAagXARQgXAQgdAAQgmAAgbgbg");
	this.shape_7.setTransform(190.25,223.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFDB1E").s().p("AhBBBQgbgbAAgmQAAglAbgbQAbgcAmAAQAnAAAbAbQAbAbAAAmQgBAngbAbQgbAbgmAAQglAAgcgcg");
	this.shape_8.setTransform(235.325,63.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFDB1E").s().p("AACgZQAAgBAAgBQAAAAAAAAQABgBAAAAQABAAABAAIABAAIACACQAAAAAAAAQAAAAAAAAQAAABAAAAQgBAAAAAAIgGAaIgIAcg");
	this.shape_9.setTransform(99.7833,246);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFDB1E").s().p("AgNA7QgHgBACgHIAShlQABgIAJAAIACAAQAEABACADQACAEAAAEIAAACIgYBkQgDADgEAAg");
	this.shape_10.setTransform(103.5909,227.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFDB1E").s().p("AgNBAQgEgBgDgFQgDgEABgFIAUhkQABgFACgDQAEgDAFAAIACAAQAFABADAEQAEAFgBAFIgXBmQAAADgDADQgDADgEAAg");
	this.shape_11.setTransform(107.8075,207.65);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFDB1E").s().p("AgNBAQgGgBgDgEQgDgFABgGIAWhlQACgLALABIADAAQANADgCANIgWBlQgDALgKgBg");
	this.shape_12.setTransform(112.1008,187.35);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFDB1E").s().p("AgNBAQgFgCgDgEQgDgFABgFIAXhmQABgIAKgBIAEAAQAEACADAEQADAEgBAFIgUBkQgEAMgJAAg");
	this.shape_13.setTransform(116.375,167.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFDB1E").s().p("AgKA8QgEgCgDgDQgCgDAAgFIAAgBIAYhjQACgFAFgBIACAAQAHACgCAGIgTBmQAAAIgJABg");
	this.shape_14.setTransform(120.5599,146.75);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFDB1E").s().p("AgGAaIANg2IgIA3QAAABAAAAQAAAAgBAAQAAABgBAAQAAAAAAAAQgBAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBg");
	this.shape_15.setTransform(124.45,128.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFDB1E").s().p("AAHgYQAAAAAAgBQAAAAABgBQAAAAABAAQABAAAAAAIACAAQAAAAAAABQAAAAABAAQAAABAAABQAAAAAAABIgNAYIgMAZg");
	this.shape_16.setTransform(75.3,238);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFDB1E").s().p("AgZA3QgGgEADgFIAnhfQADgGAGAAIAEABQAEABABAFQACAEgBADIgsBdQgGAEgCAAIgDgBg");
	this.shape_17.setTransform(82.8321,221.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFDB1E").s().p("AgaA7QgEgCgCgFQgCgEADgFIAnheQADgJAJABIAFABQAFACADAFQACAFgDAGIgrBdQAAAIgKgBQgEAAgBgBg");
	this.shape_18.setTransform(91.175,202.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFDB1E").s().p("AgaA8QgFgCgCgFQgCgFACgGIApheQACgIALAAQAEAAACABQAFADACAFQACAFgCAFIgpBeQgEAIgJAAIgGgBg");
	this.shape_19.setTransform(99.5694,183.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFDB1E").s().p("AgZA7QgFgCgCgFQgCgFACgGIAqhdQAEgIAHABIAFABQAFACACAFQABAEgCAFIgoBeQgEAJgIgBQgEAAgBgBg");
	this.shape_20.setTransform(108.0071,164.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFDB1E").s().p("AgXA4QgEgCgBgEQgCgEACgEIAAgBIAshcQACgFAEAAQABAAAAABQABAAAAAAQABAAAAAAQAAABABAAQAGAEgDAEIgnBgQgCAHgGAAg");
	this.shape_21.setTransform(116.3791,145.35);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFDB1E").s().p("AgKAbQgBAAAAgBQAAAAAAAAQgBgBAAgBQAAAAAAgBIAZgxIgTA0IgDABg");
	this.shape_22.setTransform(123.85,128.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFDB1E").s().p("AgkAyQgCgCgBgDQAAgDABgCIA7hWQACgDAGAAIAGABQAIAFgFAKIg/BSQgDABgEAAIgEAAg");
	this.shape_23.setTransform(63.8768,210.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFDB1E").s().p("AglA1QgIgGAFgLIA7hUQAEgGAGAAIAJACQAEADABAGQABAFgDAFIg9BSQgEAGgGAAQgDAAgEgCg");
	this.shape_24.setTransform(76.09,193.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFDB1E").s().p("AglA1QgFgEgBgFQgBgGAEgEIA8hTQAEgGAHAAQAFAAADADQAEAEABAFQABAGgDAEIg8BTQgDAGgIAAQgFAAgDgDg");
	this.shape_25.setTransform(88.1425,176.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFDB1E").s().p("AglA0QgEgDgBgFQgBgGADgFIA9hSQADgEAHAAQADAAAEACQAIAGgFALIg7BUQgDAFgIAAIgIgDg");
	this.shape_26.setTransform(100.3039,159.95);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFDB1E").s().p("AgiAxQgHgGAEgIIA/hSQACgDAEAAIAEABQADACAAADQABADgCACIg6BVQgCAFgGAAIgGgCg");
	this.shape_27.setTransform(112.4719,143.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFDB1E").s().p("AgPAYQgBgBAAAAQgBgBAAAAQAAgBAAAAQAAgBABAAIAigrIgeAuIgBABg");
	this.shape_28.setTransform(123.2719,128.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFDB1E").s().p("AASgSIACgBIABABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAIgrAjg");
	this.shape_29.setTransform(33.85,207.95);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFDB1E").s().p("AgsAqQgDgGADgEIBKhHQADgEAEAAQAEAAADAEQADACAAAEQAAAFgDACIhOBEQgCABgDAAQgDAAgCgBg");
	this.shape_30.setTransform(47.6375,195.55);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFDB1E").s().p("AgvAsQgHgJAIgIIBLhGQAGgEADAAQAGAAAEAEQAEAEgBAFQAAAHgEADIhNBEQgEAEgEAAQgGAAgDgEg");
	this.shape_31.setTransform(63.0144,181.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFDB1E").s().p("AgwAsQgIgKAJgJIBNhGQAGgDADAAQAGAAAEAEQAIALgJAKIhMBEQgDAFgHAAQgGAAgEgGg");
	this.shape_32.setTransform(78.375,167.75);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFDB1E").s().p("AgvArQgEgEABgFQAAgGAEgEIBOhEQACgCAGAAQAGAAADADQADAEAAAFQgBAFgDAEIhMBGQgEACgFAAQgFAAgFgEg");
	this.shape_33.setTransform(93.7972,154.075);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFDB1E").s().p("AgqAoQgDgDAAgDQAAgFADgDIBOhCIAEgCQADAAACACQAEAGgFAEIhKBIQAAABgFAAQgEAAgDgDg");
	this.shape_34.setTransform(109.0889,140.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFDB1E").s().p("AgUATQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAIArgjIgoAmIgBABQgBAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAgBg");
	this.shape_35.setTransform(122.9,127.85);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFDB1E").s().p("AguAiQgEAAgCgEQgCgFAEgEIBYg1IAFgBQAGAAADAEQADAEgBAEQgBAEgEADIhbAwg");
	this.shape_36.setTransform(34.7946,177.95);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFDB1E").s().p("Ag4AhQgCgFACgEQABgFAEgDIBZg0QADgBADAAQAIgBAEAIQADAEgBAGQgCAGgFACIhaAxIgGABQgGAAgFgFg");
	this.shape_37.setTransform(52.6929,167.65);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFDB1E").s().p("Ag4AhQgDgFACgFQABgGAFgDIBZgzQAEgCADAAQAJAAADAHQADAFgCAGQgBAFgFADIhZAzQgDACgEAAQgIAAgEgHg");
	this.shape_38.setTransform(70.74,157.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFDB1E").s().p("Ag3AgQgDgFABgFQACgGAFgCIBagyIAGgCQAGAAAFAGQACAFgBAEQgBAFgEACIhZA0IgHADQgIAAgEgHg");
	this.shape_39.setTransform(88.6667,146.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFDB1E").s().p("AgzAeQgCgDABgEQABgEADgDIBbgxQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAQAFAAABAEQADAGgFADIhYA2QgBACgEAAQgGAAgCgFg");
	this.shape_40.setTransform(106.617,136.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFDB1E").s().p("AgWAPQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAABgBQAAAAABAAIAxgZIgvAdg");
	this.shape_41.setTransform(122.5479,127.35);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFDB1E").s().p("AAYgJIABAAIADACQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAIg1ANg");
	this.shape_42.setTransform(8.3143,163.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFDB1E").s().p("Ag4AUQgCgGAGgDIBkgjQAHAAACAHQABAEgCAEQgBAEgEABIhjAcIgBABQgGAAgBgFg");
	this.shape_43.setTransform(25.8661,157.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFDB1E").s().p("AgxAcQgJAAgDgIQgDgLALgEIBigfIAEgBQAKAAADAIQACAGgCAFQgDAFgFACIhiAdg");
	this.shape_44.setTransform(45.6413,151.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFDB1E").s().p("Ag+AUQgBgFADgFQACgFAFgDIBjgeIAEgBQAJgBAEALQABAFgCAFQgDAFgFACIhiAeIgEADQgKAAgEgLg");
	this.shape_45.setTransform(65.3888,145.15);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFDB1E").s().p("Ag8AUQgCgGACgEQACgGAGgBIBjgeIADgBQAKAAABAIQACAFgCAEQgCAEgGACIhiAgQABAAAAABQAAAAgBAAQAAABgBAAQgBAAgBAAQgJAAgDgJg");
	this.shape_46.setTransform(84.95,138.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFDB1E").s().p("AgvAZQgIAAgCgIQgBgDACgEQACgEADgBIABAAIBjgdIACAAQAFABACAFQACAFgGADIhhAjg");
	this.shape_47.setTransform(104.7961,132.55);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFDB1E").s().p("AgbAJQgBgBAAgBQABAAAAgBQAAAAAAgBQABAAABgBIA2gNIg0ATIgBABIgDgCg");
	this.shape_48.setTransform(122.3458,126.75);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFDB1E").s().p("AAbgDQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAABAAAAQgBAAAAAAQAAABAAAAQgBAAAAAAIg5ADg");
	this.shape_49.setTransform(2.975,138.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFDB1E").s().p("Ag7AHQAAgGAGgBIBmgNIABAAQAIgBACAJQABAEgDADQgDADgEAAIgBAAIhnAJQgGABAAgIg");
	this.shape_50.setTransform(21.3625,136.55);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFDB1E").s().p("Ag0ARQgEAAgEgDQgDgDgBgFQgBgKAMgBIBmgNIACAAQAMAAABANQABAFgDAEQgEAEgGAAIhnAKg");
	this.shape_51.setTransform(42.0031,134.55);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFDB1E").s().p("AgyATQgGAAgDgEQgEgDgCgFQAAgGAEgDQADgEAGgBIBmgLIABAAQAGAAAEAEQAEADABAFQAAAGgEADQgDAEgGABIhnALg");
	this.shape_52.setTransform(62.55,132.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFDB1E").s().p("Ag/AGQgBgFADgDQAEgFAGAAIBngKIABAAQAKAAACALQABAKgMABIhmANIgCABQgLAAgCgNg");
	this.shape_53.setTransform(83.2469,130.25);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFDB1E").s().p("AgxAOQgIAAgCgJQgBgDADgDQACgDAFgBIABAAIBngIQAHAAAAAHQAAAGgGAAIhnAOg");
	this.shape_54.setTransform(103.8958,128.2);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFDB1E").s().p("AgcACQAAgBAAAAQAAgBAAAAQAAAAABAAQAAAAABAAIA3gDIg2AHQgBAAgBAAQAAAAgBAAQAAgBAAAAQAAgBAAAAg");
	this.shape_55.setTransform(122.15,126.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFDB1E").s().p("AAxAOIhngOQgFgBAAgGQAAgGAGAAIBnAIQAFAAACAEQADACAAAEQgCAJgIAAg");
	this.shape_56.setTransform(21.4536,115);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFDB1E").s().p("AAxASIhmgMQgLgBAAgLQABgEADgDQAEgEAEAAIABAAIBnAKQAGABADAEQAEADgBAGQgBAEgEAEQgEADgFAAg");
	this.shape_57.setTransform(42.0531,117.1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFDB1E").s().p("AAzATIhogLQgFgBgEgEQgEgEACgFQAAgFAEgEQAEgDAFAAIABAAIBnALQAGABAEAFQAEADgCAFQgBAFgDAEQgEADgFAAg");
	this.shape_58.setTransform(62.6,119.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFDB1E").s().p("AgzAJQgFgCgEgEQgEgDABgFQABgFAEgEQAEgDAEAAIABAAIBmAMQALABAAAKQABAGgEADQgDAEgFAAg");
	this.shape_59.setTransform(83.1431,121.25);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFDB1E").s().p("AgyAGQgEAAgDgDQgCgDAAgEQAAgEADgDQADgCAEAAIABAAIBmANQAGAAAAAIQgBAGgGAAg");
	this.shape_60.setTransform(103.9458,123.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFDB1E").s().p("AgZABQgBAAgBAAQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAQABAAABAAIA2AHg");
	this.shape_61.setTransform(122.15,125.375);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFDB1E").s().p("AgbgJIA1ANQABAAAAAAQAAAAAAABQABAAAAABQAAABAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBAAg");
	this.shape_62.setTransform(8.325,87.9);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFDB1E").s().p("AAtAZIhigiQgDgBgBgDQgBgCABgDQACgGAFAAIACAAIBjAcQAJAEgCAJQgFAHgFABg");
	this.shape_63.setTransform(25.9738,93.65);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFDB1E").s().p("AAtAbIhiggQgFgBgCgEQgCgFABgEQADgJAJABIAEAAIBiAeQAFACADAFQADAFgCAFQgEAJgJgBIgEgBg");
	this.shape_64.setTransform(45.6,100.05);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFDB1E").s().p("AAuAdIhjgeQgFgCgCgFQgDgGABgFQAEgKAKAAIAEABIBiAeQAFACADAFQACAFgBAGQgDAKgKAAQgBAAgBAAQgBAAAAAAQgBAAAAAAQAAAAAAgBg");
	this.shape_65.setTransform(65.3888,106.25);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFDB1E").s().p("Ag0gCQgFgBgDgFQgDgGACgFQADgJAKAAIAEABIBiAgQAEACADAEQACAFgBAEQgFAJgHAAg");
	this.shape_66.setTransform(85.1112,112.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFDB1E").s().p("AAxAYIhjgcQgIgEABgIQACgHAIAAIADAAIBhAiQADABACACQABADgCADQgCAEgEAAg");
	this.shape_67.setTransform(104.8338,119.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFDB1E").s().p("AgagEQAAAAAAAAQgBAAAAAAQAAgBAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQABAAAAAAQABgBABAAIABAAIAzAVg");
	this.shape_68.setTransform(122.275,124.75);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFDB1E").s().p("AAWAPIgXgPIgYgOIAxAZQABAAAAABQABAAAAABQAAAAAAABQAAAAgBABg");
	this.shape_69.setTransform(18.7781,64.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFDB1E").s().p("AAmAhIhYg2QgFgDADgHQACgCAEAAIAEAAIBaAyQAEACABAEQABAEgCADQgDAEgGABIgFgCg");
	this.shape_70.setTransform(34.7604,73.65);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFDB1E").s().p("AAmAlIhZg0QgEgDgBgFQgCgEADgFQADgGAHAAQAEAAACACIBaAyQAEADADAFQABAFgDAFQgEAHgIAAIgGgCg");
	this.shape_71.setTransform(52.7,84);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFDB1E").s().p("AAmAmIhZgzQgFgDgCgFQgBgGADgFQAFgHAHAAQADAAAEACIAsAaIAtAZQAFADABAGQACAFgDAFQgFAHgHAAQgDAAgEgCg");
	this.shape_72.setTransform(70.75,94.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFDB1E").s().p("AAnAlIhagyQgEgDgCgFQgCgGADgEQAEgHAIAAIAHACIBZA0QAFADABAEQABAFgDAFQgFAGgGAAQgEAAgCgCg");
	this.shape_73.setTransform(88.71,104.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFDB1E").s().p("AArAhIhbgwQgEgDgBgEQgBgDACgEQADgEAGAAIAFAAIABAAIBYA2QAFAFgDAFIgHAEIgDgCg");
	this.shape_74.setTransform(106.6396,115.05);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFDB1E").s().p("AgXgJQgBAAAAgBQAAAAgBgBQAAgBAAAAQAAgBABAAIADgCIABAAIAuAfg");
	this.shape_75.setTransform(122.5333,124.2);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFDB1E").s().p("AgGAFQgFgFAFgEQACgDADAAQABAAAAABQAAAAAAAAQABAAAAABQABAAAAABIAHAEQgGACgGAFg");
	this.shape_76.setTransform(43.875,52.45);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFDB1E").s().p("AAdAsIhLhFQgIgJAHgIQACgFAHAAQAFAAADAEIBNBDQAEAEAAAFQABAGgEAEQgFAFgFAAQgFAAgEgEg");
	this.shape_77.setTransform(63.0644,69.85);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFDB1E").s().p("AAeAuIgngkIgmgiQgEgDAAgGQgBgGAEgEQAGgFAEgBQAHAAACAFIBNBFQAEADAAAGQABAGgEAFQgGAEgEAAQgHAAgCgDg");
	this.shape_78.setTransform(78.475,83.65);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFDB1E").s().p("AAfAtIhNhEQgFgEAAgFQAAgFAEgFQAGgFAEAAQAEAAAFADIBMBGQADADABAFQAAAFgDAEQgDAFgHAAQgFAAgDgDg");
	this.shape_79.setTransform(93.8222,97.5);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFDB1E").s().p("AAkApIhOhBQgEgDAAgFQAAgEADgDQADgDAFAAIAGABIBKBIQAFAEgFAFQgCADgDAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAgBg");
	this.shape_80.setTransform(109.2964,111.35);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFDB1E").s().p("AgVgOQAAgBAAAAQgBgBAAAAQAAgBABgBQAAAAAAgBIACgBIADABIAmAog");
	this.shape_81.setTransform(122.85,123.75);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFDB1E").s().p("AALAYQgIgNgGgLIgPgXIAjAqQABABAAABQABAAgBABQAAAAAAABQgBAAgBABIgDAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAg");
	this.shape_82.setTransform(53.2021,26.45);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFDB1E").s().p("AAVAuIg6hVQgDgGAFgEIAEgBQADAAADAEIA/BRQACADgBAEQAAAEgDACQgDACgEAAQgFAAgDgEg");
	this.shape_83.setTransform(63.933,41.35);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFDB1E").s().p("AATAxIg7hTQgDgFABgEQAAgGAFgCQAEgCADgBQAEABAGAEIA9BSQADAFgBAFQgBAGgEADQgEACgEABQgHgBgEgFg");
	this.shape_84.setTransform(76.0175,58.15);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFDB1E").s().p("AAUAyIg8hTQgEgEABgGQABgGAFgDQADgDAFAAQAGAAAFAGIA8BTQADAEgBAHQgBAFgEADQgDADgFAAQgHAAgEgGg");
	this.shape_85.setTransform(88.1925,74.9);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFDB1E").s().p("AAUAyIg8hSQgDgFABgFQABgGAEgDQADgDAFAAQAGAAAFAFIA7BUQADAEgBAFQAAAFgFADQgDADgFAAQgEAAgGgFg");
	this.shape_86.setTransform(100.45,91.6);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFDB1E").s().p("AAbAwIg/hSQgCgDAAgEQABgEADgDQADgCACAAQAFAAAEAEIA6BVQABACAAADQgBADgCACIgDACQgDAAgDgDg");
	this.shape_87.setTransform(112.4763,108.425);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFDB1E").s().p("AgQgSQgBgBAAAAQAAgBAAgBQAAAAAAgBQAAAAABgBIACgBQAAAAABABQAAAAAAAAQABAAAAAAQAAAAAAAAIAeAwg");
	this.shape_88.setTransform(123.3,123.35);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFDB1E").s().p("AALAyIAAgBIgnheQgCgDACgDQABgCADgBIADgCQAEABACAEIAsBcQABAEgBAEQgCAEgDACIgEACQgGAAgDgHg");
	this.shape_89.setTransform(82.75,30.45);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFDB1E").s().p("AAIA1IgohfQgCgFABgEQACgFAFgDIAFgBQAHAAAEAIIArBdQACAGgCAFQgCAFgFACIgGABQgJAAgDgHg");
	this.shape_90.setTransform(91.2623,49.35);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFDB1E").s().p("AAIA1IgpheQgCgFACgFQACgGAFgCIAGgBQAIAAAFAIIApBeQACAFgCAFQgCAFgFADIgGABQgIAAgFgIg");
	this.shape_91.setTransform(99.6444,68.4);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFDB1E").s().p("AAKA2IgqhfQgCgFACgFQACgFAFgDIAGgBQAJAAADAIIAoBgQACAEgCAFQgCAEgEACIgGACQgIgBgDgGg");
	this.shape_92.setTransform(108.0071,87.25);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFDB1E").s().p("AAQA0IgshdQgDgKAIgDQAAAAAAAAQABgBAAAAQABAAABAAQAAAAABAAQAGAAADAGIAnBfQADAIgHABIgDABQgEAAgCgEg");
	this.shape_93.setTransform(116.4291,106.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFDB1E").s().p("AgMgWQAAgBAAAAQAAAAAAgBQAAAAAAgBQABAAAAgBIABAAIADACIAUAzg");
	this.shape_94.setTransform(123.7833,123.1);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFDB1E").s().p("AACAbIgEgbIgEgcIANA1QACACgEACg");
	this.shape_95.setTransform(99.6446,5.7);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFDB1E").s().p("AAAA0IAAgBIgThmQAAgCABgDQACgCADAAIABAAQAGAAABAEIAYBkQABAEgCAEQgCAEgEABIgDABQgIgBgBgHg");
	this.shape_96.setTransform(103.5604,23.65);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFDB1E").s().p("AAKBAQgKgBgCgKIgUhmQgBgFADgEQADgDAEgBIACAAQAKAAABAJIAXBkQABAFgDAFQgDAFgFACg");
	this.shape_97.setTransform(107.8214,43.95);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFDB1E").s().p("AALBAQgKAAgDgLIgWhkQgBgGADgEQADgGAGgBIADAAQAKABADAKIAWBmQABAFgDAFQgDAFgGAAg");
	this.shape_98.setTransform(112.0125,64.25);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFDB1E").s().p("AAAA3IgWhlQgBgGADgFQADgEAFgBIADAAQAKgBACALIAUBkQABAFgDAEQgCAFgFABIgCABQgKAAgCgJg");
	this.shape_99.setTransform(116.325,84.55);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFDB1E").s().p("AANA6QgFABgCgGIgYhkQgBgEADgDQACgEADAAIACAAQAJgBAAAJIAAABIATBkQABADgCADQgCADgDgBQAAAAAAAAQABAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_100.setTransform(120.5407,104.95);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFDB1E").s().p("AgHgYQAAgBABgBQAAAAAAgBQAAAAABgBQAAAAABgBIABAAIACACIAIA5g");
	this.shape_101.setTransform(124.35,122.85);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFDB1E").s().p("AgCAaIACg2IACAbIABAbQABADgEAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQAAgBAAgBg");
	this.shape_102.setTransform(125.11,2.95);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFDB1E").s().p("AgGA7QgDgEAAgEIADhoQAAgHAGAAQAHAAAAAHIADBnQABAFgDADQgDADgFAAQgDAAgDgCg");
	this.shape_103.setTransform(125.1125,21.4);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFDB1E").s().p("AgIA8QgEgDAAgGIABhmQAAgFADgEQAEgDAEAAQAEAAAEADQAEAEAAAFIABBmQABAGgEADQgEAFgGAAQgEAAgEgFg");
	this.shape_104.setTransform(125.11,42.15);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFDB1E").s().p("AgJA+QgEgEAAgGIAAhnQAAgGAEgEQAEgEAFAAQAHAAADAEQAEAEAAAGIAABnQAAAGgEAEQgDAEgHAAQgFAAgEgEg");
	this.shape_105.setTransform(125.1,62.9);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFDB1E").s().p("AgIA9QgDgDAAgFIgBhnQAAgFAEgEQADgEAFgBQAFAAAEAEQAEAEAAAFIgBBnQAAANgMAAQgFAAgDgEg");
	this.shape_106.setTransform(125.15,83.6);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFDB1E").s().p("AgFA2IgEhoQAAgKAJAAQAEAAADADQADADAAAEIgDBpQAAAAAAABQAAAAAAABQAAAAgBABQAAAAgBAAQgCACgDABQgFgBAAgGg");
	this.shape_107.setTransform(125.1,104.35);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFDB1E").s().p("AgCgaQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABIgDA4g");
	this.shape_108.setTransform(125.125,122.8);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFDB1E").s().p("AgGAZIANg1IgEAcIgEAbQAAABAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAgBAAgBg");
	this.shape_109.setTransform(150.5,5.75);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFDB1E").s().p("AgKA8QgEgBgCgEQgDgDABgEIAAgCIAYhkQABgEAFAAIACAAQAHABgCAHIgTBlQAAAJgIAAg");
	this.shape_110.setTransform(146.7849,23.75);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFDB1E").s().p("AgMBAQgFgBgDgFQgDgFAAgGIAXhkQABgJAKAAIAEAAQAFABACADQADAFgBAEIgUBmQgBAEgDADQgEAEgFAAg");
	this.shape_111.setTransform(142.4857,43.95);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFDB1E").s().p("AgNBAQgGgBgDgEQgDgGABgEIAVhmQACgKAMgBIADAAQAFACADAFQAEAFgBAFIgLAyIgLAyQgDALgKAAg");
	this.shape_112.setTransform(138.3575,64.25);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFDB1E").s().p("AgOBAQgEgBgDgFQgCgEAAgFIAUhlQABgEADgDQAEgEAFABIADAAQAFABADAEQAEAEgBAHIgYBlQAAADgCADQgEACgEABg");
	this.shape_113.setTransform(133.9819,84.55);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFDB1E").s().p("AgNA7QgHgBACgHIAShlQABgIAJAAIACAAQAEABACADQACAEAAAEIAAABIgXBkQgFAEgEAAg");
	this.shape_114.setTransform(129.7909,104.9);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFDB1E").s().p("AABgaQAAgBAAAAQABAAAAgBQAAAAABAAQABAAABAAIABAAIACABQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAAAIgOA2g");
	this.shape_115.setTransform(125.8833,122.9);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFDB1E").s().p("AgMAXIAZgxIgTAzQAAABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgBAAgBgBQAAAAgBgBQAAAAAAgBQAAAAAAgBg");
	this.shape_116.setTransform(175.025,13.6);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFDB1E").s().p("AgXA4QgEgCgBgEQgCgEACgEIAAgBIAshcQACgEAEgBIADACQAGADgCAGIgnBeQAAAIgJAAg");
	this.shape_117.setTransform(167.4546,30.45);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFDB1E").s().p("AgZA7QgFgCgCgFQgCgFACgGIArhdQADgIAIAAIAFABQAFADABAFQACAEgCAFIgoBfQgFAHgIAAQgEAAgBgBg");
	this.shape_118.setTransform(159.225,49.35);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFDB1E").s().p("AgaA8QgFgDgCgFQgCgFACgFIApheQADgIAKAAIAGABQAFACACAGQACAFgCAFIgpBeQgDAIgKAAIgGgBg");
	this.shape_119.setTransform(150.725,68.4);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFDB1E").s().p("AgZA7QgFgCgCgEQgBgFACgEIAohgQADgIAJAAQAEAAABABQAFADACAFQACAGgDAEIgrBfQgDAGgGABIgFgCg");
	this.shape_120.setTransform(142.3873,87.25);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFDB1E").s().p("AgZA3QgGgEADgFIAnhfQADgGAGAAIAEABQAEACACAEQABADgCAEIAAABIgsBdQgDADgEAAIgDgBg");
	this.shape_121.setTransform(134.0454,106.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFDB1E").s().p("AAHgYIADgCIABAAQABAAAAAAQAAABABAAQAAABAAAAQAAABAAAAIgZAzg");
	this.shape_122.setTransform(126.4,123.05);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFDB1E").s().p("AgQAYQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIAjgrIgdAvg");
	this.shape_123.setTransform(197.3219,26.5);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFDB1E").s().p("AgiAwQgEgCgBgDQAAgFADgDIA/hRQABgEAFAAQAAAAABABQABAAAAAAQABAAAAABQAAAAABAAQAFAEgDAHIg6BUQgDADgHAAQgCAAgDgCg");
	this.shape_124.setTransform(186.4895,41.35);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFDB1E").s().p("AglA0QgEgDgBgFQgBgGADgFIA9hSQAEgEAGgBQADABAEACQAIAGgFALIg7BTQgFAFgFABIgJgDg");
	this.shape_125.setTransform(174.26,58.15);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFDB1E").s().p("AgmA1QgEgEgBgFQgCgFAEgFIA9hTQAEgGAHAAQAFAAADADQAFADABAGQAAAGgDAEIg8BTQgFAGgHAAQgFAAgDgDg");
	this.shape_126.setTransform(162.2,74.9);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFDB1E").s().p("AglA1QgIgHAFgKIA7hUQAEgGAHAAIAIACQAEADABAGQABAGgDAEIg9BSQgDAGgHAAQgDAAgEgCg");
	this.shape_127.setTransform(149.9824,91.6);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFDB1E").s().p("AgkAyQgGgEAFgGIA6hWQACgDAGAAIAGABQAIAFgFAKIg+BSIgIABIgEAAg");
	this.shape_128.setTransform(137.9081,108.45);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFDB1E").s().p("AANgWIACgBIACAAQAAABABAAQAAABAAAAQAAABAAAAQAAABAAAAIgjArg");
	this.shape_129.setTransform(126.9281,123.4);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFDB1E").s().p("AgUAUQgBgBAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBIAqgjIgnAoQAAAAAAAAQAAAAAAAAQAAAAgBAAQAAABAAAAQgBAAAAgBQAAAAgBAAQAAAAAAAAQAAAAAAAAg");
	this.shape_130.setTransform(216.375,43.65);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFDB1E").s().p("AgrAoQgDgDAAgEQAAgEADgDIBOhCQACgCADAAQADAAACACQAEAFgFAFIhKBHQgBACgFAAQgEAAgDgDg");
	this.shape_131.setTransform(202.7266,56);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFDB1E").s().p("AgvArQgEgEAAgFQAAgGAFgEIBNhDQADgEAFAAQAHAAACAFQAHAIgIAJIhLBFQgFAEgEAAQgGAAgEgFg");
	this.shape_132.setTransform(187.3106,69.85);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFDB1E").s().p("AgwAtQgJgLAKgJIBNhFQAGgFADAAQAHABADAFQAJAKgKAJIhMBGQgEADgGAAQgHAAgDgEg");
	this.shape_133.setTransform(171.925,83.65);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFDB1E").s().p("AgwAsQgHgJAIgIIBMhGQAGgEADAAQAGAAAEAEQAEAEAAAGQAAAFgFAEIhNBEQgFAEgEAAQgFAAgEgEg");
	this.shape_134.setTransform(156.5644,97.5);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFDB1E").s().p("AgsApQgDgFADgFIBKhHQADgCAEAAQAEAAADACQADAEAAAEQAAADgDAEIhOBBQgCADgDAAQgDAAgCgCg");
	this.shape_135.setTransform(141.1375,111.35);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFDB1E").s().p("AASgTIACgBQAAAAAAABQABAAAAAAQAAAAAAAAQAAAAAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAgBABIgrAjg");
	this.shape_136.setTransform(127.35,123.75);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFDB1E").s().p("AgzAeQgDgDABgEQABgEAEgDIABAAIBagxIAEgBQAEAAACAEQADAGgHADIhYA2QAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQgHAAgBgFg");
	this.shape_137.setTransform(215.6581,73.6);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFDB1E").s().p("Ag3AgQgDgFABgFQACgGAFgCIBagyIAGgCQAGAAAFAGQACAEgBAFQgBAEgEADIhZA0QgFADgCAAQgIAAgEgHg");
	this.shape_138.setTransform(197.6667,84);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFDB1E").s().p("Ag4AhQgDgFACgFQABgGAFgDIBZgzQADgCAEAAQAHAAAFAHQADAFgCAGQgCAFgEADIhZAzQgCACgFAAQgIAAgEgHg");
	this.shape_139.setTransform(179.625,94.3);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFDB1E").s().p("Ag3AhQgCgFABgEQABgFAEgDIBYg0QADgBAEAAQAIgBAEAIQADAEgCAGQgBAGgFACIhaAxQgBABgEAAQgHAAgEgFg");
	this.shape_140.setTransform(161.6429,104.65);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFDB1E").s().p("AgvAjQgEgBgCgEQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQABgDADgCIBYg2IAFAAQAFAAAEAEQACAEgBAEQgBAEgDACIhbAyg");
	this.shape_141.setTransform(143.8583,115.05);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFDB1E").s().p("AAWgPIABAAIAEABQAAABAAAAQAAABAAAAQAAABgBABQAAAAAAABIg0AZg");
	this.shape_142.setTransform(127.7917,124.25);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFDB1E").s().p("AgbAIQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBABAAIA1gNIgaAJQgWAKgDAAIgEgCg");
	this.shape_143.setTransform(241.8667,87.9);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFDB1E").s().p("AgvAZQgHgBgCgGQgCgEACgEQACgEAEgCIBjgcIACAAQAFAAACAGQABAFgFAEIhhAig");
	this.shape_144.setTransform(224.4339,93.65);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFDB1E").s().p("Ag8AUQgBgFACgFQACgGAFgBIBigeIAEgBQAKAAABAIQACAEgCAFQgDAEgFACIhiAgQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAgBAAQgJAAgEgJg");
	this.shape_145.setTransform(204.6405,100);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFDB1E").s().p("Ag9AUQgCgFADgFQADgGAFgBIBhgfIAEgBQAKAAADAKQACAFgDAFQgDAGgFABIhiAfQAAAAAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAQgJAAgEgKg");
	this.shape_146.setTransform(184.925,106.3);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFDB1E").s().p("AgxAcQgJAAgDgIQgCgEADgFQACgEAFgBIBighIAEAAQAKgBADAJQABAGgCAFQgCAFgFACIhiAdg");
	this.shape_147.setTransform(165.254,112.75);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFDB1E").s().p("Ag4AUQgCgFAGgEIBkgjQAHAAACAHQABAEgCAEQgBAEgEABIgBAAIhjAcQAAAAAAAAQABABAAAAQAAAAgBAAQAAAAAAAAQgGAAgBgFg");
	this.shape_148.setTransform(145.4661,119);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFDB1E").s().p("AAZgJIAAAAIAEACQAAABAAAAQAAABAAAAQgBABAAAAQgBABAAAAIg3ANg");
	this.shape_149.setTransform(127.9875,124.8);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFDB1E").s().p("AgcACQAAgBAAAAQAAgBAAAAQABAAAAAAQAAAAABAAIAbgCIAcgBIg2AHQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAAAgBg");
	this.shape_150.setTransform(247.35,113.1);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFDB1E").s().p("AgyANQgDABgDgDQgDgCgBgFQAAgDACgDQADgDAEAAIABAAIBngJIABAAQAHABAAAHQAAAGgGABIhmANg");
	this.shape_151.setTransform(229.0208,115.05);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFDB1E").s().p("Ag/AHQgBgGADgDQAEgEAFgCIBngJIABAAQAKgBACALQACAKgNADIhmAMIgBABQgMAAgBgMg");
	this.shape_152.setTransform(208.3795,117.05);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFDB1E").s().p("AgyAUQgFAAgFgEQgEgEgBgGQAAgFAEgDQADgEAGgCIA0gFIAygGIABAAQANABABANQABAFgDAEQgEADgFABIhoAMg");
	this.shape_153.setTransform(187.75,119.25);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFDB1E").s().p("Ag0ASQgEAAgEgEQgDgDgBgFQAAgEADgDQADgDAFgCIBmgLIACAAQAMAAABALQABAGgDADQgEAFgGABIhnAKIgBgBg");
	this.shape_154.setTransform(167.1075,121.35);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFDB1E").s().p("Ag7AHQAAgHAGAAIBmgNIABAAQAIAAACAJQABAEgDACQgDADgEABIgBAAIhmAIQgHAAAAgHg");
	this.shape_155.setTransform(146.5625,123.4);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFDB1E").s().p("AAagDQABAAABAAQAAAAABAAQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAAAQgBAAAAAAQgBAAgBAAIg3AFg");
	this.shape_156.setTransform(128.05,125.35);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFDB1E").s().p("AABADIgbgBQAAAAgBgBQgBAAAAAAQAAgBgBAAQAAAAAAAAQAAgBAAgBQABAAAAgBQAAAAABAAQABgBAAAAIA4AIIgdgBg");
	this.shape_157.setTransform(247.375,138.45);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFDB1E").s().p("AgyAGQgEAAgDgDQgDgDABgEQAAgDADgDQADgDAEAAIABAAIBmANQAHACgBAGQAAAGgHAAg");
	this.shape_158.setTransform(229.0097,136.6);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFDB1E").s().p("AA0ASIhngKQgGgBgDgDQgEgEABgFQABgGAEgDQADgDAFgBIABAAIBmANQALABAAALQAAAEgDAEQgDAEgFgBg");
	this.shape_159.setTransform(208.34,134.45);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFDB1E").s().p("AAzATIg0gFIg0gGQgFAAgEgFQgEgDABgGQABgFAFgDQADgEAFAAIACAAIBmALQAGABAEAEQAEAEgBAFQgBAFgEADQgFAEgEAAg");
	this.shape_160.setTransform(187.8,132.4);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFDB1E").s().p("AAyASIhmgMQgLgBAAgLQACgLAKAAIAAAAIBoAKQAFABAEAEQADAEgBAFQgBAFgDADQgEADgFAAg");
	this.shape_161.setTransform(167.1861,130.3);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFDB1E").s().p("AAxAOIhmgOQgHAAABgHQABgGAGAAIABAAIBnAIQAEAAADAEQACACAAAEQgBADgDADQgDADgEAAg");
	this.shape_162.setTransform(146.5479,128.2);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFDB1E").s().p("AgdgDIA4ADQABAAAAAAQABAAAAAAQABAAAAAAQAAABAAAAQgBABAAABQgBAAAAABQgBAAAAAAQgBABAAAAg");
	this.shape_163.setTransform(128.25,126.25);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFDB1E").s().p("AgZgDQgEAAACgEQAAAAABgBQAAAAAAAAQAAgBABAAQABAAAAAAIABAAIAzATg");
	this.shape_164.setTransform(242.0167,163.7);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFDB1E").s().p("AAxAYIhjgcQgJgEACgIQACgHAHAAIAEAAIBhAiQADABACADQABACgCADQgBAEgFAAg");
	this.shape_165.setTransform(224.419,158);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFDB1E").s().p("AAuAcIhigeQgFgCgDgEQgCgFABgGQADgJAKAAIAEABIBiAgQAFABACAFQADAEgCAFQgDAJgJAAIgEgBg");
	this.shape_166.setTransform(204.7388,151.6);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFDB1E").s().p("AAsAdIhhgeQgFgCgDgFQgCgGABgFQAEgLAJABQABAAABAAQABAAAAAAQABAAAAAAQAAAAAAABIBjAeQAFACACAFQADAGgBAFQgEALgKAAQgBAAgBgBQAAAAgBAAQgBAAAAAAQAAAAgBgBg");
	this.shape_167.setTransform(185.0612,145.15);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FFDB1E").s().p("AAuAbIhigfQgFgCgCgFQgDgEABgEQADgJAIAAIAEABIBiAfQAFABADAFQADAGgBAFQgFAIgHgBIgEgBg");
	this.shape_168.setTransform(165.275,138.95);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFDB1E").s().p("AAsAZIhhgjQgDAAgBgDQgBgDABgCQACgFAFgBIACAAIBjAdQAJADgCAIQgCAJgHAAg");
	this.shape_169.setTransform(145.5738,132.55);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FFDB1E").s().p("AAZAKIg1gTIA2AOQABAAAAAAQABAAAAABQAAAAAAABQAAABAAABQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAgBAAg");
	this.shape_170.setTransform(127.95,126.8);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FFDB1E").s().p("AgGgCQADgFAFAAIAFABIABAAQgHAFgGAJQgEgGADgEg");
	this.shape_171.setTransform(211.0357,175.3);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#FFDB1E").s().p("AAnAlIhagyQgEgDgCgFQgCgGADgEQAEgHAIAAIAHACIBZA0QAFADABAEQABAFgDAFQgFAGgGAAQgEAAgCgCg");
	this.shape_172.setTransform(197.71,167.6);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFDB1E").s().p("AAmAmIgsgaIgtgZQgFgDgCgFQgBgGADgFQAGgHAGAAQADAAAEACIBZAzQAFADABAGQACAFgDAFQgDAHgJAAQgEAAgDgCg");
	this.shape_173.setTransform(179.6025,157.2);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#FFDB1E").s().p("AAlAkIhYg0QgEgCgCgEQgBgGADgDQADgHAHABIAGABIBaAzQAFADACAFQABAFgDAFQgIAFgFAAIgGgCg");
	this.shape_174.setTransform(161.8,146.95);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FFDB1E").s().p("AAmAhIhYg2QgFgDADgHQACgCAEAAIAEABIBaAwQAEADABADQABAEgCAEQgCAEgHAAIgFgBg");
	this.shape_175.setTransform(143.7604,136.55);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FFDB1E").s().p("AAWAPIgvgdIAxAZQABAAAAABQAAAAABABQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAAAAAQAAAAgBAAQAAAAgBAAg");
	this.shape_176.setTransform(127.7667,127.35);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#FFDB1E").s().p("AgUgOQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAIABgBIACABIAoAmg");
	this.shape_177.setTransform(216.5,207.975);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#FFDB1E").s().p("AAjAqIhOhDQgHgHAGgHQAEgEAEAAQAEAAADADIBKBGQAFAFgFAFQgCAEgDAAIgFgCg");
	this.shape_178.setTransform(202.7241,195.5);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#FFDB1E").s().p("AAgAtIhOhEQgEgDAAgGQgBgFAEgFQAGgFAEAAQAEAAAGADIBKBGQAIAIgHAJQgCAFgGAAQgFAAgDgDg");
	this.shape_179.setTransform(187.2856,181.725);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#FFDB1E").s().p("AAeAtIgmgiIgngiQgFgEAAgGQAAgGAEgFQAGgEAEAAQAGAAADADIBNBFQAFAEAAAGQAAAGgEAEQgGAGgEAAQgGAAgDgFg");
	this.shape_180.setTransform(171.925,167.85);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#FFDB1E").s().p("AAeAsIhMhGQgIgHAHgKQACgDAHAAQAFAAADACIBNBFQAEADAAAGQABAFgEAFQgFADgEAAQgFAAgEgDg");
	this.shape_181.setTransform(156.4644,154.05);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#FFDB1E").s().p("AAeApIhKhHQgFgFAFgFQACgCADAAIAFACIBOBCQAHAIgGAGQgDADgFAAQgDAAgEgCg");
	this.shape_182.setTransform(141.1759,140.2);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#FFDB1E").s().p("AARATIgmgmIArAjQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAAAIgDABg");
	this.shape_183.setTransform(127.5,127.85);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#FFDB1E").s().p("AgkgeQgCgEAAgEQABgEADgDIAGgBQAFAAADADIA6BWIABADIgBAAIgOABg");
	this.shape_184.setTransform(186.5458,209.95);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#FFDB1E").s().p("AAVAyIg9hSQgDgFABgFQABgFAEgEQADgDAFAAQAGAAAFAFIA7BUQADAEAAAFQgBAFgFADQgCADgFAAQgFAAgFgFg");
	this.shape_185.setTransform(174.3425,193.425);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#FFDB1E").s().p("AAUAyIg8hTQgEgEABgGQABgGAFgDQAEgDAEAAQAGAAAFAGIA8BTQADAEgBAHQgBAFgEADQgDADgFAAQgIAAgDgGg");
	this.shape_186.setTransform(162.1925,176.7);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#FFDB1E").s().p("AATAxIg7hTQgDgFABgEQAAgGAFgCQACgCAFAAQAEAAAGAEIA9BSQADAFgBAFQgBAGgEADIgIADQgHgBgEgFg");
	this.shape_187.setTransform(150.0175,159.95);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#FFDB1E").s().p("AAVAuIg6hUQgBgDAAgDQABgDACgCIAEgBQADAAADAEIA+BSQACADAAAEQgBAEgDACQgBACgFAAQgFgBgDgEg");
	this.shape_188.setTransform(137.8208,143.15);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#FFDB1E").s().p("AAOAYQAAAAgBAAQAAAAAAAAQAAAAAAgBQgBAAAAAAIgdguIAjArQAAABAAAAQABABAAAAQAAABgBAAQAAAAAAABg");
	this.shape_189.setTransform(127.1,128.3);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#FFDB1E").s().p("AgMgWQAAAAAAgBQgBAAABgBQAAAAAAgBQAAAAABgBIABAAIADACIAJAZIAMAag");
	this.shape_190.setTransform(174.9969,238);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#FFDB1E").s().p("AAWA4QgEAAgCgEIgshdQgCgEACgEQABgEAEgBIAEgBQAFAAAEAGIAAABIAnBfQADAHgHACIgDAAg");
	this.shape_191.setTransform(167.6575,221.225);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#FFDB1E").s().p("AALA1IgrhdQgCgGACgFQACgFAFgCIAGgBQAJgBADAJIAoBeQACAFgCAEQgCAFgEACIgFABQgHABgEgIg");
	this.shape_192.setTransform(159.1127,202.15);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#FFDB1E").s().p("AAIA1IgpheQgCgFACgGQACgEAFgDQACgBAEAAQAIAAAFAIIApBeQACAGgCAFQgCAFgFACIgGABQgIAAgFgIg");
	this.shape_193.setTransform(150.825,183.3);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#FFDB1E").s().p("AAIA0IgoheQgCgFABgEQACgFAFgCIAFgBQAHgBAEAIIArBdQACAGgCAFQgCAFgFACIgGABQgJABgDgJg");
	this.shape_194.setTransform(142.4623,164.35);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#FFDB1E").s().p("AAKAzIAAgBIgnhgQgBgHAGgCIADgBQAEAAACAFIAsBcQADALgIACQAAABgBAAQAAABgBAAQAAAAgBAAQAAABgBAAQgGgBgEgFg");
	this.shape_195.setTransform(133.9582,145.35);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#FFDB1E").s().p("AAHAaIgTg0IAZAwQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAABIgCABg");
	this.shape_196.setTransform(126.5281,128.55);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#FFDB1E").s().p("AgGgYQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBABAAIABAAIADACIAEAbQABAOACAOg");
	this.shape_197.setTransform(150.6375,246);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#FFDB1E").s().p("AgGgBQACgCAEgBIABAAQAFAAAEAEQgHAAgLAGQgBgEADgDg");
	this.shape_198.setTransform(145.7958,222.55);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#FFDB1E").s().p("AAAA3IgWhmQgBgEADgGQADgEAFgBIADAAQAKAAACAKIAUBkQABAFgDAFQgCAEgFABQAAAAAAAAQAAAAAAAAQgBAAAAAAQgBABAAAAQgJgBgDgIg");
	this.shape_199.setTransform(142.425,207.65);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#FFDB1E").s().p("AAKBAQgKABgCgLIgWhlQgBgGADgEQADgGAGAAIADAAQAKgBADALIALA0IALAxQABAHgDAEQgDAFgGAAg");
	this.shape_200.setTransform(138.34,187.35);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#FFDB1E").s().p("AAKA/QgKAAgCgLIgUhlQgBgEADgFQACgDAFgBIACAAQAIAAADAJIAXBlQABAFgDAEQgDAFgFACQAAgBgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAg");
	this.shape_201.setTransform(134.0125,167.15);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#FFDB1E").s().p("AAAA0IAAgBIgShmQgBgGAHgCIABAAQAFABACAFIAXBjQABAEgCAEQgCAEgEAAIgCACQgHgBgDgHg");
	this.shape_202.setTransform(129.7292,146.75);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#FFDB1E").s().p("AABAbIgIg3IAPA2QAAABgBAAQAAABAAAAQAAABgBAAQAAAAgBAAIgEgCg");
	this.shape_203.setTransform(125.85,128.7);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#FFDB1E").s().p("AgBABIgBgbQAAAAAAgBQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAABAAAAIgDA3IgBgcg");
	this.shape_204.setTransform(125.15,248.65);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#FFDB1E").s().p("AgFA2IgEhoQAAgEADgDQADgCADAAQAEAAADACQADADAAAEIgDBpQAAAAAAABQAAAAAAABQAAAAgBABQAAAAgBAAQgCACgDAAQgFAAAAgGg");
	this.shape_205.setTransform(125.1,230.15);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#FFDB1E").s().p("AgIA+QgDgEAAgFIgBhnQAAgFAEgEQADgEAFgBQAFAAAEAEQAEAEAAAFIgBBnQAAANgMAAQgFAAgDgDg");
	this.shape_206.setTransform(125.15,209.4);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#FFDB1E").s().p("AgJA+QgEgEAAgGIAAhnQAAgGAEgEQAEgEAFAAQAHAAADAEQAEAEAAAGIAABnQAAAGgEAEQgDAEgHAAQgFAAgEgEg");
	this.shape_207.setTransform(125.1,188.7);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#FFDB1E").s().p("AgIA8QgEgDAAgGIABhmQAAgGADgDQAEgEAEAAQAEAAAEAEQAEADAAAGIABBmQAAAGgEADQgEAEgFABQgEgBgEgEg");
	this.shape_208.setTransform(125.225,167.95);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#FFDB1E").s().p("AgGA6QgDgDAAgEIADhoQAAgHAGAAQAHAAAAAHIADBnQABAEgDAEQgDADgFAAQgDAAgDgDg");
	this.shape_209.setTransform(125.1125,147.2);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#FFDB1E").s().p("AgCAaIACg2IADA2QAAABAAAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAgBAAgBg");
	this.shape_210.setTransform(125.125,128.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d2_s1, new cjs.Rectangle(0,0,250.4,251.6), null);


(lib.d1_l1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFDD1F").s().p("EgwXAv/MBgWhgWIAZAAMhgvBgvg");
	this.shape.setTransform(309.625,309.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d1_l1, new cjs.Rectangle(0,0,619.3,619.2), null);


(lib.chos_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_8
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E71").s().p("AOOFfIAAq8IBKAAIAAK8gAkkEBIAAhAIKDAAIAABAgAvYEBIAAhAIKEAAIAABAgAHCCRQBHgoAqgcQAvgfAagWQAdgYAMgQQANgTAFgRIkDAHIgChBIEJgEIAAhtIj0AAIAAhAIE/AAIAADDQAAAkgMAiQgKAggfAhQggAjg3AnQhBAshQAsgAj4AZIAvgZQAXgKASgMIBIgrQAVgMARgPQAOgMAKgPQAIgMADgPQADgOAAgQIAAguIjIAAIAAhBIHjAAIAABBIjJAAIAAAuQAAAQADAOQADAOAHAMQAIANAQANQAQAOAXAOIB0BCIArAXIgjA7IiehXQgogbgRgOQgUgSgGgJQgFAJgVATQgRAPgpAaQgjAWgpAWIhQAsgAuwAZIBTguQAvgbAdgVQAYgQASgSQARgPAKgSQAKgSADgVQADgXABgZIAAhNIBLAAIAABNQAAAdAEATQADAWAJARQALAUARAPQAQAPAiAWQAmAaAhASIBRAsIglA7IhTgvQgngXgjgWQgkgXgYgUQgXgTgGgNIgBAAQgGANgWAUQgYAUgmAYIhGArIhVAwg");
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({_off:false},0).wait(1));

	// Layer_9
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6D6E71").s().p("ADBFfIAAq8IBLAAIAAK8gAh4FJIAAjwQgqACguAAIhhAAIAAhBID/gEIBngEIBggIIAGA/Qg1AGgrADIhmAFIAADygAFyEBIAAhAIKDAAIAABAgAv0EBIAAhAIKDAAIAABAgAGZAZIBUguQAwgdAcgTQAZgRARgRQASgRAIgQQAKgRADgWQAEgSAAgeIAAhNIBMAAIAABNQAAAdADATQADAVAKASQAJASATARQAPAPAiAWQAuAeAaAOIBQAsIgkA7IhTgvQgtgbgdgSQgkgWgZgVQgWgTgGgNIgBAAQgGANgXAUQgYAUglAYIhHArIhVAwgAvOAZIBUguQAwgdAcgTQAXgPAUgTQARgRAJgQQAKgRADgWQADgSAAgeIAAhNIBMAAIAABNQAAAdADATQADAVAKASQAKASASARQAQAPAiAWQAtAeAaAOIBRAsIglA7IhTgvQgugcgcgRQgkgXgYgUQgXgTgGgNIgBAAQgGANgWAUQgYAUglAYIhHArIhVAwgAihgrQghgLgYgTQgXgTgNgYQgNgYAAgcIAAgfQAAgbAMgZQANgZAXgSQAYgUAigLQAigLAqAAQApAAAkALQAhAMAXATQAXASANAZQANAaAAAaIAAAfQAAAbgNAZQgNAXgYAUQgYATggALQgjALgpAAQgoAAgkgLgAikj5QgfAUAAAjIAAAUQAAAiAfAVQAfAWAwAAQAxAAAfgWQAdgVAAgiIAAgUQAAgjgdgUQgfgWgxAAQgwAAgfAWg");
	this.shape_1.setTransform(0.025,0);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(1));

	// Layer_10
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6D6E71").s().p("AssFiIAAjGImBAAIAAg/IHMAAIAAEFgATmFbIAAq8IBLAAIAAK8gAAyD+IAAhAIEdAAIAAiLIjbAAIAAg9IBjAAIAAjcIhdAAIAAg/IHxAAIAAA/IhbAAIAADcIBiAAIAAA9IjYAAIAACLIEbAAIAABAgAEhgKIClAAIAAjcIilAAgAqBD+IAAhAIKCAAIAABAgAL5CDQAfgcAgggQAcgbAageQASgRAMgTQALgQAGgQQAHgRACgQQACgOAAgYIAAhkIiXAAIAAhBIF2AAIAABBIiTAAIAABkQAAAVADATQABAQAIAPQAFAOANASQAMARAVAUIAxA0IA8A2IgyAzIhAg+IgwgxIgdggQgMgOgFgNIgBAAQgFANgLAOQgLANgSAUQgaAcgaAbQgaAbgqAmgApaAWIBTguQArgZAigYQAZgRARgQQARgRAJgQQAKgSADgVQAEgTgBgeIAAhMIBNAAIAABMQAAAdACAUQADAVALASQAJARATASQAPAOAiAXQAtAeAaAOIBRAsIglA6IhSgvQgtgagdgSQgkgXgZgVQgWgTgGgMIgBAAQgGAMgXAUQgYAVglAXIhHArIhVAxgAspA3IAAmYIBIAAIAAGYgAusA1IAAiyIhMAAQgDAdgLAYQgMAYgUATQgUASgbALQgbAKgjAAQgkAAgegMQgdgMgUgVQgUgVgLgcQgLgbABgfIAAgfQgBgeALgcQAMgdATgUQAUgVAdgLQAdgNAlAAQAjAAAbALQAbALAUASQAUATAMAYQALAYADAdIBMAAIAAiaIBHAAIAAGMgAzSjrQgWAaAAApIAAAVQAAAnAWAbQAVAbAqAAQAqAAAVgbQAXgcgBgmIAAgVQABgmgXgcQgVgbgqAAQgqAAgVAag");

	this.timeline.addTween(cjs.Tween.get(this.shape_2).to({_off:true},1).wait(2));

	// Layer_11
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCB").s().p("A68JTQhSAAg7g6Qg6g6AAhSIAAsZQAAhSA6g6QA7g6BSAAMA15AAAQBSAAA7A6QA6A6AABSIAAMZQAABSg6A6Qg7A6hSAAg");
	this.shape_3.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-192.4,-59.5,384.8,119.1);


(lib.cho_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("A2QnsMAshAAAQDIAAAADIIAAJJQAADIjIAAMgshAAAQjIAAAAjIIAApJQAAjIDIAAg");
	this.shape.setTransform(0.025,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#273864").s().p("A2QHsQjIABAAjIIAApJQAAjIDIABMAshAAAQDIgBAADIIAAJJQAADIjIgBg");
	this.shape_1.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-163.5,-50.2,327.1,100.5);


(lib.box_bg_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#373971","#353669","#2E2D55","#2B294B"],[0,0.247,0.761,1],-81.1,0,81.2,0).s().p("ApiMsQjJAAAAjJIAAzFQAAjJDJAAITFAAQDJAAAADJIAATFQAADJjJAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C4262D").s().p("ApiMsQjJAAAAjJIAAzFQAAjJDJAAITFAAQDJAAAADJIAATFQAADJjJAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81.1,-81.1,162.3,162.3);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(14.7,-33.35,1,1,0,0,0,390.4,315.7);

	this.instance_1 = new lib.ClipGroup_1_1();
	this.instance_1.setTransform(14.7,-33.35,1,1,0,0,0,390.4,315.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-375.7,-349,781,631.4);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(14.7,-33.35,1,1,0,0,0,390.4,315.7);

	this.instance_1 = new lib.ClipGroup_1_1();
	this.instance_1.setTransform(14.7,-33.35,1,1,0,0,0,390.4,315.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-375.7,-349,781,631.4);


(lib.step_wrong = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#493728").s().p("AlaANIAAgvIKuhTIAHDrgAhggHIF4AoIAEhKg");
	this.shape.setTransform(199.675,-185.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ai9gDIF7giIgDBLg");
	this.shape_1.setTransform(209,-186.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#493728").s().p("Ak8CiIHkltICVDiIpiC1gAipBwIGEiCIhBhyg");
	this.shape_2.setTransform(186.2,-243.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ACBh5IBBByImECBg");
	this.shape_3.setTransform(188.65,-244.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#493728").s().p("AkTEoIF+ptICpCGIoDIEgAhuCCIE5k5IhLgwg");
	this.shape_4.setTransform(145.95,-283.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ABSi0IBLAwIk5E5g");
	this.shape_5.setTransform(150.55,-288.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},23).wait(37));

	// Layer_3
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#7BC0DF").s().p("AxyNcQClh4E1khIATgSQB9gcD8icQCfhhB8hcQAogchLgTQg6gNh0gGIBChDQHJgXD/ilQBihAAmhEQAjg/gegkQhBhQhPjoIBihoIADASQAVBhBBCMQBACLBiCaICIDFQArA4AfAkQn9CxsNFhQneDYnfDqg");
	this.shape_6.setTransform(-1.1,-152.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#97D7ED").s().p("ABujYIADgDQB1AGA6AOQBMASgoAdQh9BbifBhQj8Cch9AcQDFi5D6j7g");
	this.shape_7.setTransform(-31.9633,-131.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#97D7ED").s().p("AiAA3IAAAAIGUmkQBPDpBBBPQAeAlgjA+QgmBEhiA/Qj/CmnJAXg");
	this.shape_8.setTransform(29.4423,-196.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#74B8D3").s().p("Ay8HSQHfjrHdjXQMOlhH8iyIAoAuIADADQASAUAWAWQA4A3AoAcQoOCrnnCmQntColgCDQmBCPiXBOg");
	this.shape_9.setTransform(9.425,-108.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#65A2CF").s().p("AE4H/QgfgOgrgkQhFg8hUhpQhXhthUiEQhGhug3htQg0hngfhWQgdhRgEgzQgCgTADgMIAPAGQAeANArAlQBFA8BVBpQBXBuBTCDQBHBvA3BsQA0BoAeBVQAeBQAEA1QABATgDALQgFgBgJgFg");
	this.shape_10.setTransform(108.31,-199.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#EBC574").s().p("AgRBaQgYgWgWgkQgYgkgKgjIAjAlIBwhbIAwBMIiABAIARAvg");
	this.shape_11.setTransform(-125.775,-51.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#493728").s().p("A1GSEQg4gfgyhQQgzhRgEg/QgEg/AsgcQAwgeA8AmIA6glQADgHAJgGIAQgJQEjjGMttbQGWmvFmmQQAGgHAGgEIAJgEIAPgLQBuhGDuD2QCjCoBpCmQB3C9BPDBQCDE9huBFIgOAHQgFAGgEACQgHAFgIACQomCjpKC6QyQF0j2CIIgNAJQgHAFgGAAIg7ApQAJBHgwAeQgVAOgYAAQgaAAgdgQgA0nQbIgRgvICChBIgwhMIhxBbIgkglQALAjAXAlQAXAkAXAWIAEAEgAB2myIAAABIl2F8Qj8D7jEC5IgTASQk0EhimB4IA/BjQCWhNGCiQQFgiDHtioQHninIOiqQgpgdg4g2QgWgWgSgUIgCgDIgogtQgfgkgrg4IiIjFQhhiahBiLQhBiMgUhhIgEgSgALEvoQADAzAeBSQAeBVA1BoQA3BtBGBuQBTCEBZBuQBUBoBFA8QAqAlAfAOQAJADAGABQADgKgCgTQgEg0gdhRQgehVg1hoQg2hshHhvQhUiEhYhuQhUhphFg7QgsgmgegNIgOgFQgDALACATg");
	this.shape_12.setTransform(4.7601,-147.6716);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]},23).wait(37));

	// Layer_4
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#EFB372").s().p("AjQB+IBhkxIFAA3IhhExg");
	this.shape_13.setTransform(309.1,139);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#EFB372").s().p("Ak+IfIE+xqIE/A3Il2Rhg");
	this.shape_14.setTransform(335.825,56.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#EFB372").s().p("AkSI1IDjyBIFCAeIkcR7g");
	this.shape_15.setTransform(282.025,45.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#EFB372").s().p("AjGCNIBJk3IFEAeIhJE3g");
	this.shape_16.setTransform(261.9,129.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#493728").s().p("A+MS2QgkgbgEgrIgCgLQgnAEgggXQgjgbgFgsQgEgggKhDIghAJQiMAljTAnIlzBHQjCAmiUAiIgMACQgkAEgfgUQglgZgHgrIgDgQQgjAEgfgUQgkgYgIgsIgsj6QgIgsAbgjQAbgkAsgEIAAAAIA8gIIA7gJIBQgOQgjgegagiQhHgqgug/QgyhEgOhTQgQhdAhhdIgTgJQgngZgIgrIgCgRQgjADgdgSQgmgXgIgtIgqjwQgIgsAbgkQAcgiArgFIACAAIAYgCQAhgEAdgFIBOgOIgjjIQgIgsAbgkQAbgiArgFIADAAIAbgDIAwgGIG4hOQApgHAtgMQAIgCAIgBQAjgEAeAUQAmAXAIAtIADAQQAigDAeATQAnAZAHArIAPBUQAvgKAXgHIANgCIgQhRQgShXgMgwQgKgrAYgmQAYgkArgIIEng0QAogEAgAYQAkAbAEArIACALQAogEAfAXQAjAbAFArQAHBAAKBCIBGGRIA/gQQAjgDAeASQARALAMARQADiNAch2QAoihBMhzQBRh2BzhCQBhg3BxgMIApgDQCNgFB5A8QBiAxBRBaQBPA2A+BQQBJBiAwCMIgKkgQgCg7gFhVQgEg7gHhQQgFgsAdghQAbgeAngEIEqgLQAtgCAfAfQAdAdABAqIAHAAQAsgCAgAfQAfAggBArQgCBMADA6IANGEIAqnPQAGg2AAg3QABgsAhgeQAZgWAhgEIAUAAIN0BQQAsAEA3ABQAuABAdAhQAZAbABAnIAMABQAXAAAUAKIACgyQABgsAhgeQAYgVAhgEQAKgBAKABIEjAaQAsAEAbAjQAUAaABAhIAUACQAsAEAcAjQAbAigHAsQgKBHgGA+IhMNKQgHBLgCBEQgCAtghAdQgYAVggAEIgVAAIgwgFQBJBEAoBOQANAZAKAfIAhiNQALguApgVQgEgTAEgUIDjyAQAGghAZgXQAZgWAhgEQAKgBAKABIFDAdQAvAEAbAnQAbAlgLAuIgCAIIAlAEQAPABARAIQALgeAZgTQAagTAfgBIAVACIE/A2QAWAEATANQASANALATQAYAmgOArIAtAIQAuAIAZAoQAYApgPAsIl3RhQgFAQgIAKIACAEQALASADAXQADAWgHAVIhiEyQgKAfgaATQgaAUggABIgUgCIlCg3QgugIgYgoIgDgHQgTAJgQABQgJACgLgBIlFgeQgvgEgbgmQgNgSgEgWQgEgVAFgWIACgJIglgEQgdgCgagUQgUA2gjAvQhCBah0A9QhxA3iYAYIgxAGQiDAOibgOQi4gRiMgwQiSgyhghJQg3gognguIgTgOQhphNgzhoQg1hrALhyQAKh3BJheQAwg/BMgyIhmgJQgngDgagdQgbgcgBgmIgUgCQgTgCgTgJIAcMGQADBMAGBCQAEAsgdAiQgbAegnAEIklALQgtABgfgfQgdgdgBgqIgHABQgtABgfgfQgfgfABgsQAChAgDhPIgSnsQgrCbhKBrQhTB5hxBAQhgA2hsAMIgmADQiMAFh6g9QhigwhMhYQhRg3g/hTQg8hNgrhqIgDAAIiMASIB4KrQANBMAQBAQAKAqgYAmQgYAkgsAIIkgAyIgNABQggAAgbgUgA/VNsQAPBUAGBAIEagyQgRhGgNhMIiKsPIBIgMQAygJAngGQAwgHAqgDIgtkCQgpALgvAKIhaARIhHAMIhsptQgKhAgIhGIkgAyQASBIANBEIAcCQIC4QXQhQAuh+AkQiCAliyAjIgXh/QCig8BQhpQBPhogUh0QgMhEgug3Qgtg2hJgjQhLghhigJQhhgLh1AVQhxAUhZArQhZAqg5A4Qg7A4gZBEQgZBEAMBEQAKA6AkAyQAkAyA5AgQA4AjBMASQBLARBZgCIAWB/Im5BNIhAAHIAsD6QCpgmCxgjIFzhHQDUgnCFgjQCGgiBdgzgAOXBzQiGAUhhAwQhgAxg3BHQg3BIgHBYQgIBWAnBRQAoBQBXBBQBVA/CAAsQCDAtCpAPQCvAQCIgVQCIgVBhgwQBegxA1hIQA0hHAIhUQAIhZgphQQgphQhUhBQhWg/iCgtQiCgsisgQQhIgGhCAAQhYAAhMALgEAo0AMjIFCA3IBhkyIlBg3gAjTxZQAFAyAHBcIA9aCQADBFgCBQIEfgKQgHhDgDhSIg76FQgDhMACg/gEAhnALYIFFAdIBJk4IlFgegAvXvkQhuAEhfA1QheA1hDBjQhDBjgiCQQgiCNAGC4QAHCzArCJQArCLBKBfQBHBgBiAxQBiAxBzgFQBlgDBeg0QBdg1BFhkQBEhkAmiNQAniOgHi5QgGiygsiLQgriJhIhhQhKhghhgwQhcgthqAAIgPAAgEArSAGIIEHAtIF3xhIlAg3gEAjkAEyIEJAYIEdx7IlDgegAaptwIgLCTIg/K2QgIBZgKA6IEfAaQACg8AHhYIBNtMQAGhHALhDIkjgbQgDBNgEBCgAHFu5IhPNnQCKANCZALQCJALCqAIQChAHCGAAQCNAAB3gPIAWjxQghAEg9ADQgvADheACQhNAEhTgBQhZgBhDgEIlFgZIALiDIKyA/IAWjyIqyg+IAMh9IJbA3IA2AGIA2AGIAWj7QgyAAg5gFIt1hQQAAA6gGA6gEgjpgBnIgCgJIgJACIALAHgEgmdgIeIvPCsQg4AJgoADIAqDvQAlgLAugIIPmiwQAqgHArgDIgqjvQgxANguAIgEgrigMWIm4BNQgkAHgxAEIAqDqQAqgMAogHIHEhPQAqgHArgDIgpjrQguANgxAIg");
	this.shape_17.setTransform(26.9483,71.2571);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#EFB372").s().p("AgnGgQipgPiDgtQiAgshVg/QhXhBgohQQgnhRAIhVQAHhYA3hIQA3hHBggxQBhgwCGgUQCGgUCnAPQCsAQCCAsQCCAtBWA/QBUBBApBQQApBQgIBYQgIBUg0BHQg1BIheAxQhhAwiIAVQhNALhaAAQhEAAhLgGgAiXi4QhOAFg5ARQg7ATgiAeQgjAggDArQgEAtAbAkQAcAlA3AeQA3AbBKATQBJATBdAIQBZAJBOgGQBPgFA5gRQA6gUAigfQAjgfAEgtQAEgpgdgkQgeglg0gdQg2gbhKgTQhKgThdgIQg+gGg5AAIgwABg");
	this.shape_18.setTransform(145.5162,123.8995);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#EFB372").s().p("AjCIpQAKg6AIhaIA/q1IALiTQAEhCADhNIEiAbQgLBDgGBHIhNNLQgHBZgCA8g");
	this.shape_19.setTransform(207.725,26.775);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#EFB372").s().p("AAKIAQipgJiIgKQiZgLiKgNIBPtnQAFg6ABg6INzBRQA6AFAyAAIgXD7Ig2gGQgbgEgbgCIpag3IgLB8IKxA/IgWDwIqxg+IgMCDIFEAZQBEAEBYABQBUABBNgEQBegDAvgDQA8gDAhgEIgWDyQh3AOiNAAIgSABQh+AAiXgHg");
	this.shape_20.setTransform(123.075,16.1017);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#493728").s().p("AgQC2QhdgJhJgTQhKgSg3gcQg3gegcglQgbgkAEgsQADgsAjgfQAigeA7gUQA5gRBOgEQBNgEBaAIQBdAJBKATQBKASA2AcQA0AcAeAlQAdAlgEApQgEAtgjAeQgiAgg6ATQg5ARhPAGQgfACggAAQgyAAg2gFgAghAQIgjADQguAFgeAJQgVAHgQAJIAYAGQA/ARBYAIQBSAHBEgEIAfgDQAxgFAggKQATgHAPgIIgUgFQhGgShQgHQg2gFgyAAIgxABg");
	this.shape_21.setTransform(145.5239,124.0048);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#EFB372").s().p("AhrNDIg96CQgHhcgFgyIEjgKQgCA/ADBMIA7aFQADBSAHBDIkfAKQAChQgDhFg");
	this.shape_22.setTransform(23.825,57.275);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#EFB372").s().p("Ai5LKQhigxhHhfQhKhfgriLQgriKgHizQgGi4AiiMQAiiQBDhkQBDhiBeg1QBfg2BugEQBygDBiAwQBhAxBKBfQBIBhArCKQAsCLAGCyQAHC4gnCOQgmCOhEBjQhFBlhdA0QheA1hlADIgTAAQhnAAhagtgAgPn9Qg6ADgrAtQgrAtgdBGQgeBHgNBeQgMBdADBfQADBgAUBfQATBcAjBEQAiBGAuApQAvAoA4gCQA6gBArgsQArgsAehJQAbhGANhdQANhdgEhjQgEhjgThaQgThbghhHQgihEgugpQgtgng2AAIgEAAg");
	this.shape_23.setTransform(-68.7917,47.4321);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#493728").s().p("AhUHWQgugpgihGQgjhEgThcQgUhfgDhgQgDhfAMhdQANheAehHQAdhGArgtQArgtA6gDQA4gBAvAoQAuApAiBEQAhBHATBbQATBaAEBjQAEBjgNBdQgNBdgbBGQgeBJgrAsQgrAsg6ABIgFABQg1AAgtgngABFkiQgeAfgXA2QgWA4gMBTQgLBUADBWQAEBcARBTQAOBHAYA0QAIgFAGgGQAdgeAWg1QAXg6AKhQQAMhWgDhZQgDhagShSQgOhEgXg3QgHAEgGAGg");
	this.shape_24.setTransform(-68.6662,47.302);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#EFB372").s().p("ApbgQQAogDA4gJIPOisQAugIAxgNIAqDuQgrADgqAHIvlCwQguAIglALg");
	this.shape_25.setTransform(-265.975,37.075);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#EFB372").s().p("AHsNKIgmjXQhdAziGAjQiFAijSAnIl0BIQiwAiiqAmIgsj6IB/gRIF6hDIgWh/QhYAChMgRQhLgSg5gjQg4ggglgyQgjgxgLg7QgMhDAZhFQAZhEA7g4QA5g3BagrQBYgrBxgUQB1gVBhALQBiAJBKAhQBKAjAsA3QAuA3AMBDQAVB1hQBnQhQBpihA8IAXB/QCxgjCDglQB9gjBQgvIi4wWIgciRQgNhEgRhIIEfgyQAIBGAKBAIBtJuIBHgNIBZgRQAwgJAogMIAtEDQgqADgwAHQgmAGgzAJIhHALICJMPQAOBMAQBGIkaAyQgGg/gPhVgAlZASQhvATg2AnQg1ApAIAsQAHArBBAWQBBAWBvgUQBygVAzgpQA0gqgHgsQgIgrg/gUQgfgKgsAAQgsAAg6ALg");
	this.shape_26.setTransform(-222.9,74.65);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#EFB372").s().p("AlJg+QAxgEAkgGIG2hNQAxgJAugNIApDqQgqADgqAHInEBQQgnAHgrAMg");
	this.shape_27.setTransform(-271.225,7.225);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#493728").s().p("AicBoQhAgWgIgsQgIgqA2goQA1goBwgUQBwgUA/AUQA/ATAIAsQAHArg0AqQgzAphyAVQg0AJgqAAQguAAgjgLg");
	this.shape_28.setTransform(-255.6298,86.8824);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13}]},19).wait(41));

	// Layer_5
	this.instance = new lib.star_blost();
	this.instance.setTransform(4.7,-51.45);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).wait(46));

	// Layer_6
	this.instance_1 = new lib.Tween4("synched",0);
	this.instance_1.setTransform(-14.9,33.45,0.5419,0.5419,0,0,0,-0.2,0.2);
	this.instance_1.alpha = 0;

	this.instance_2 = new lib.Tween5("synched",0);
	this.instance_2.setTransform(-14.8,33.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},14).wait(46));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true,regX:0,regY:0,scaleX:1,scaleY:1,x:-14.8,y:33.35,alpha:1},14).wait(46));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-390.5,-315.7,781,631.4);


(lib.star = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_14 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(14).call(this.frame_14).wait(1));

	// Layer_7
	this.instance = new lib.star2();
	this.instance.setTransform(313.4,120.2,1,1,0,0,0,33.5,34.5);
	this.instance.alpha = 0;

	this.s5 = new lib.star2();
	this.s5.setTransform(313.4,120.2,1,1,0,0,0,33.5,34.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},8).to({state:[{t:this.s5}]},6).wait(1));

	// Layer_6
	this.instance_1 = new lib.star2();
	this.instance_1.setTransform(251.45,54.75,1,1,0,0,0,33.5,34.5);
	this.instance_1.alpha = 0;

	this.s4 = new lib.star2();
	this.s4.setTransform(251.45,54.75,1,1,0,0,0,33.5,34.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},6).to({state:[{t:this.s4}]},6).wait(3));

	// Layer_5
	this.instance_2 = new lib.star1();
	this.instance_2.setTransform(174.45,34.2,1,1,0,0,0,33.5,34.2);
	this.instance_2.alpha = 0;

	this.s3 = new lib.star1();
	this.s3.setTransform(174.45,34.2,1,1,0,0,0,33.5,34.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},4).to({state:[{t:this.s3}]},6).wait(5));

	// Layer_4
	this.instance_3 = new lib.star1();
	this.instance_3.setTransform(95.45,54.45,1,1,0,0,0,33.5,34.2);
	this.instance_3.alpha = 0;

	this.s2 = new lib.star1();
	this.s2.setTransform(95.45,54.45,1,1,0,0,0,33.5,34.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.s2}]},6).wait(7));

	// Layer_2
	this.instance_4 = new lib.star1();
	this.instance_4.setTransform(33.5,120.25,1,1,0,0,0,33.5,34.2);
	this.instance_4.alpha = 0;

	this.s1 = new lib.star1();
	this.s1.setTransform(33.5,120.25,1,1,0,0,0,33.5,34.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).to({state:[{t:this.s1}]},6).wait(9));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,347,154.6);


(lib.Group_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1_2();
	this.instance.setTransform(295.5,48,1,1,0,0,0,295.5,48);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(0,0,591,96), null);


(lib.ClipGroup_0_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("EgvNAPeIAA+7MBebAAAIAAe7g");
	mask_2.setTransform(302.175,98.95);

	// Layer_3
	this.instance_1 = new lib.Group_2();
	this.instance_1.setTransform(295.5,147.2,1,1,0,0,0,295.5,48);
	this.instance_1.alpha = 0.2891;

	this.instance_2 = new lib.Group_1_1();
	this.instance_2.setTransform(0.55,0.25);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0_2, new cjs.Rectangle(0,0.3,591,194.89999999999998), null);


(lib.ClipGroup_161 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("EgvNAPeIAA+7MBebAAAIAAe7g");
	mask_2.setTransform(302.175,98.95);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgyD+IAAmnIiPAAIAAhUIGDAAIAABUIiPAAIAAGng");
	this.shape_1.setTransform(381.05,99.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABSD+IhojAIhHAAIAADAIhlAAIAAn7ICxAAQC+AAAACaQAABrhhAmIB3DQgAhdgRIBCAAQBkAAAAhSQAAgogZgSQgZgQgyAAIhCAAg");
	this.shape_2.setTransform(339.675,99.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AB1D+IgkiCIikAAIgkCCIhnAAICjn7IB3AAICjH7gAA7AtIgQg3QgPg1gchxIgDAAQgTBSgYBUIgPA3IB4AAg");
	this.shape_3.setTransform(291.925,99.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgzD+IAAmnIiPAAIAAhUIGFAAIAABUIiQAAIAAGng");
	this.shape_4.setTransform(251.5,99.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ai5C+IA6hGQA9A4BEAAQBRAAAAg7QAAgZgWgQQgMgJgrgSIhCgdQhogpAAhfQAAg+AygqQAygrBLAAQBgAAA/BBIgzBAQgzgpg5AAQghAAgTAOQgVAOABAZQAAAYAXAQQAOAKApARIBDAcQBmApAABgQAABBgxArQg0AuhVAAQhsAAhNhKg");
	this.shape_5.setTransform(210.15,99.625);

	this.instance_1 = new lib.ClipGroup_0_2();
	this.instance_1.setTransform(302.2,99,1,1,0,0,0,302.2,99);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_161, new cjs.Rectangle(0,0,604.4,197.9), null);


(lib.ClipGroup_163 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("EhT5BTIMAAAimQMCnzAAAMAAACmQg");
	mask_3.setTransform(537.025,532.05);

	// Layer_3
	this.instance_2 = new lib.ClipGroup_0_1();
	this.instance_2.setTransform(537,532,1,1,0,0,0,537,532);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_163, new cjs.Rectangle(0,0,1074,1064.1), null);


(lib.d7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_6_copy_copy
	this.instance = new lib.d7_2_3();
	this.instance.setTransform(1668.1,46.15,1,1,0,0,0,52.1,51.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.0033,skewX:-2.1923,skewY:2.4711},9).to({scaleX:1,scaleY:1.0014,skewX:1.8127,skewY:-1.2258,y:46.2},10).to({scaleY:1,skewX:0,skewY:0,y:46.15},15).wait(1));

	// Layer_6_copy
	this.instance_1 = new lib.d7_2_2();
	this.instance_1.setTransform(1800.15,170.55,1,1,0,0,0,56,51.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.0006,skewX:-1.1838,skewY:0.8615},9).to({scaleX:1,scaleY:1.002,skewX:-2.3784,skewY:1.2258,x:1800.2},10).to({scaleY:1,skewX:0,skewY:0,x:1800.15},15).wait(1));

	// Layer_6
	this.instance_2 = new lib.d7_2_1();
	this.instance_2.setTransform(1952.15,291.75,1,1,0,0,0,60.5,50.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:65.7,regY:47.9,scaleX:1.0012,skewX:-2.0016,skewY:0.8392,x:1957.3,y:289},9).to({regX:60.6,regY:50.9,scaleX:1,scaleY:1.0058,skewX:4.0148,skewY:-2.1504,x:1951.7,y:292},10).to({regX:60.5,scaleY:1,skewX:0,skewY:0,x:1952.15,y:291.75},15).wait(1));

	// line_copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BB634F").ss(1,1,1).p("EAvcAieQr6ihv1paQtYn9vKsQQsmqJrjrOQp/ptkelv");
	this.shape.setTransform(1891.925,182.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(35));

	// Layer_5
	this.instance_3 = new lib.d7_4();
	this.instance_3.setTransform(477.85,38.6,1,1,0,0,0,52.1,51.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:1.0041,skewX:2.7226,skewY:-2.4813,y:38.65},9).to({scaleX:1,scaleY:1.0052,skewX:3.0753,skewY:-2.7226},10).to({scaleY:1,skewX:0,skewY:0,y:38.6},15).wait(1));

	// Layer_4
	this.instance_4 = new lib.d7_3();
	this.instance_4.setTransform(350.65,158.7,1,1,0,0,0,56.1,51.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({scaleY:1.0027,skewX:2.7005,skewY:-1.4838,x:350.7},9).to({regY:51.4,scaleX:1.0012,scaleY:1,skewX:1.7042,skewY:-1.1021,x:350.6,y:158.95},10).to({regY:51.2,scaleX:1,skewX:0,skewY:0,x:350.65,y:158.7},15).wait(1));

	// Layer_3
	this.instance_5 = new lib.d7_2();
	this.instance_5.setTransform(212.7,269.2,1,1,0,0,0,60.2,50.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regX:60.4,scaleY:1.0005,skewX:1.1596,skewY:-0.7073,x:212.9,y:269.15},9).to({regX:60.2,scaleX:1.0002,scaleY:1,skewX:-1.0002,skewY:0.1871,x:212.7,y:269.3},10).to({scaleX:1,skewX:0,skewY:0,y:269.2},15).wait(1));

	// Layer_2
	this.instance_6 = new lib.d7_1();
	this.instance_6.setTransform(61.75,365.55,1,1,0,0,0,66.5,48.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({regX:66.4,scaleY:1.0003,skewX:0.4047,skewY:-0.1661},9).to({regX:66.5,scaleY:1.001,skewX:-2.2338,skewY:0.3165,x:61.85},10).to({scaleY:1,skewX:0,skewY:0,x:61.75},15).wait(1));

	// line
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#BB634F").ss(1,1,1).p("EgvbAieQL6ihP1paQNYn9PKsQQMmqKLjrNQJ/ptEelv");
	this.shape_1.setTransform(261.625,168.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(35));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.9,-52.9,2239.4,467.09999999999997);


(lib.d5_l2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_162();
	this.instance.setTransform(255.2,251,1.6461,1.6285,0,-8.8794,8.2686,135.8,136.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d5_l2_1, new cjs.Rectangle(-0.1,0,511.70000000000005,502.2), null);


(lib.d5_l2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_99 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(99).call(this.frame_99).wait(1));

	// Layer_1
	this.instance = new lib.d5_l2_1();
	this.instance.setTransform(255.65,250.9,1,1,0,0,0,255.7,251.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:195.7,regY:307.1,x:2600.15,y:-1785.6},99).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-2092.7,2916.1,2594.7);


(lib.D5_l1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_162();
	this.instance.setTransform(136.1,136.1,1,1,0,0,0,136.1,136.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.D5_l1_1, new cjs.Rectangle(0,0,272.1,272.1), null);


(lib.D5_L1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_99 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(99).call(this.frame_99).wait(1));

	// Layer_1
	this.instance = new lib.D5_l1_1();
	this.instance.setTransform(2340.6,-1352.3,1,1,0,0,0,136.1,136.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-336,y:592.2},99).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-472.1,-1488.4,2948.7,2216.6000000000004);


(lib.d5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(9).call(this.frame_9).wait(5));

	// Layer_2_copy_copy
	this.instance = new lib.d5_l2();
	this.instance.setTransform(-480,1468.35,1,1,0,0,0,255.7,250.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(5));

	// Layer_2_copy_copy
	this.instance_1 = new lib.D5_L1();
	this.instance_1.setTransform(-534.5,860.65,1,1,0,0,0,136.1,136.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({_off:false},0).wait(3));

	// Layer_2_copy
	this.instance_2 = new lib.D5_L1();
	this.instance_2.setTransform(-514.5,1180.7,1,1,0,0,0,136.1,136.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(7).to({_off:false},0).wait(7));

	// Layer_2_copy
	this.instance_3 = new lib.d5_l2();
	this.instance_3.setTransform(-431.2,1689.55,1,1,0,0,0,255.8,250.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(14));

	// Layer_2_copy
	this.instance_4 = new lib.D5_L1();
	this.instance_4.setTransform(48.9,1284.75,1,1,0,0,0,136.1,136.1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(2).to({_off:false},0).wait(12));

	// Layer_2
	this.instance_5 = new lib.D5_L1();
	this.instance_5.setTransform(292.85,1244.7,1,1,0,0,0,136.1,136.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(14));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-735.8,-763.8,3369.2,2704.5);


(lib.d4_sub_d = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#BB634F").ss(1,1,1).p("At0zRIbpAAMAAAAmjI7pAAg");
	this.shape.setTransform(-595.675,127.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EAE9BC").s().p("At0TRMAAAgmiIbpAAMAAAAmig");
	this.shape_1.setTransform(-595.675,127.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(30));

	// Layer_14
	this.instance = new lib.d4_d1();
	this.instance.setTransform(807.2,-28.1,1,1,0,0,0,36.1,36);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(15).to({_off:false},0).to({x:743.1,y:36,alpha:1},9).wait(6));

	// Layer_13
	this.instance_1 = new lib.d4_d1();
	this.instance_1.setTransform(749.1,30.05,1,1,0,0,0,36.1,36);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({_off:false},0).to({x:685,y:94.15,alpha:1},10).wait(9));

	// Layer_12
	this.instance_2 = new lib.d4_d1();
	this.instance_2.setTransform(691.05,88.2,1,1,0,0,0,36.1,36);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(5).to({_off:false},0).to({x:626.95,y:152.3,alpha:1},10).wait(15));

	// Layer_11
	this.instance_3 = new lib.d4_d1();
	this.instance_3.setTransform(632.5,146.4,1,1,0,0,0,36.1,36);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:568.4,y:210.5,alpha:1},9).wait(21));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-685.2,-64.1,1528.4,316.4);


(lib.d4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.d4_sub_d();
	this.instance.setTransform(5.65,-4.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(61));

	// Layer_10
	this.instance_1 = new lib.d4_sp1();
	this.instance_1.setTransform(1942.4,541,1,1,0,0,0,121.6,124.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(18).to({_off:false},0).to({x:1969.65,y:500.95,alpha:1},24).to({alpha:0},6).to({_off:true},12).wait(1));

	// Layer_6_copy_copy_copy
	this.instance_2 = new lib.d4_l1();
	this.instance_2.setTransform(-39.55,894,1.028,1.028,0,0,0,38.4,38.4);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(13).to({_off:false},0).to({x:39.45,y:816.5,alpha:1},24).to({_off:true},23).wait(1));

	// Layer_6_copy_copy
	this.instance_3 = new lib.d4_l1();
	this.instance_3.setTransform(-39.5,859.5,1.028,1.028,0,0,0,38.5,38.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(10).to({_off:false},0).to({x:39.5,y:782,alpha:1},24).to({_off:true},26).wait(1));

	// Layer_6_copy
	this.instance_4 = new lib.d4_l1();
	this.instance_4.setTransform(-39.55,824.55,1.028,1.028,0,0,0,38.5,38.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(6).to({_off:false},0).to({x:39.45,y:747.05,alpha:1},24).to({_off:true},30).wait(1));

	// Layer_6
	this.instance_5 = new lib.d4_l1();
	this.instance_5.setTransform(-79.1,750,1.028,1.028);
	this.instance_5.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regX:38.5,regY:38.5,x:39.5,y:712.1,alpha:1},24).to({_off:true},36).wait(1));

	// l4
	this.instance_6 = new lib.d4_l1();
	this.instance_6.setTransform(2051.6,697.45,1,1,0,0,0,38.4,38.4);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(13).to({_off:false},0).to({x:1975.6,y:769.95,alpha:1},20).to({_off:true},27).wait(1));

	// l3
	this.instance_7 = new lib.d4_l1();
	this.instance_7.setTransform(2050.75,663.3,1,1,0,0,0,38.4,38.4);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(10).to({_off:false},0).to({x:1974.75,y:735.8,alpha:1},20).to({_off:true},30).wait(1));

	// l2
	this.instance_8 = new lib.d4_l1();
	this.instance_8.setTransform(2051.6,628.65,1,1,0,0,0,38.4,38.4);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(6).to({_off:false},0).to({x:1975.6,y:701.15,alpha:1},20).to({_off:true},34).wait(1));

	// l1
	this.instance_9 = new lib.d4_l1();
	this.instance_9.setTransform(2051.6,592.6,1,1,0,0,0,38.4,38.4);
	this.instance_9.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({x:1975.6,y:667.6,alpha:1},20).to({_off:true},40).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-679,-0.5,2770.3,934.1);


(lib.d3_sub_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_0();
	this.instance.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_1 = new lib.ClipGroup_1();
	this.instance_1.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_2 = new lib.ClipGroup_2();
	this.instance_2.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_3 = new lib.ClipGroup_3();
	this.instance_3.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_4 = new lib.ClipGroup_4();
	this.instance_4.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_5 = new lib.ClipGroup_5();
	this.instance_5.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_6 = new lib.ClipGroup_6();
	this.instance_6.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_7 = new lib.ClipGroup_7();
	this.instance_7.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_8 = new lib.ClipGroup_8();
	this.instance_8.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_9 = new lib.ClipGroup_9();
	this.instance_9.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_10 = new lib.ClipGroup_10();
	this.instance_10.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_11 = new lib.ClipGroup_11();
	this.instance_11.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_12 = new lib.ClipGroup_12();
	this.instance_12.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_13 = new lib.ClipGroup_13();
	this.instance_13.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_14 = new lib.ClipGroup_14();
	this.instance_14.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_15 = new lib.ClipGroup_15();
	this.instance_15.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_16 = new lib.ClipGroup_16();
	this.instance_16.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_17 = new lib.ClipGroup_17();
	this.instance_17.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_18 = new lib.ClipGroup_18();
	this.instance_18.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_19 = new lib.ClipGroup_19();
	this.instance_19.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_20 = new lib.ClipGroup_20();
	this.instance_20.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_21 = new lib.ClipGroup_21();
	this.instance_21.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_22 = new lib.ClipGroup_22();
	this.instance_22.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_23 = new lib.ClipGroup_23();
	this.instance_23.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_24 = new lib.ClipGroup_24();
	this.instance_24.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_25 = new lib.ClipGroup_25();
	this.instance_25.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_26 = new lib.ClipGroup_26();
	this.instance_26.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_27 = new lib.ClipGroup_27();
	this.instance_27.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_28 = new lib.ClipGroup_28();
	this.instance_28.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_29 = new lib.ClipGroup_29();
	this.instance_29.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_30 = new lib.ClipGroup_30();
	this.instance_30.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_31 = new lib.ClipGroup_31();
	this.instance_31.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_32 = new lib.ClipGroup_32();
	this.instance_32.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_33 = new lib.ClipGroup_33();
	this.instance_33.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_34 = new lib.ClipGroup_34();
	this.instance_34.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_35 = new lib.ClipGroup_35();
	this.instance_35.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_36 = new lib.ClipGroup_36();
	this.instance_36.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_37 = new lib.ClipGroup_37();
	this.instance_37.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_38 = new lib.ClipGroup_38();
	this.instance_38.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_39 = new lib.ClipGroup_39();
	this.instance_39.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_40 = new lib.ClipGroup_40();
	this.instance_40.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_41 = new lib.ClipGroup_41();
	this.instance_41.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_42 = new lib.ClipGroup_42();
	this.instance_42.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_43 = new lib.ClipGroup_43();
	this.instance_43.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_44 = new lib.ClipGroup_44();
	this.instance_44.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_45 = new lib.ClipGroup_45();
	this.instance_45.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_46 = new lib.ClipGroup_46();
	this.instance_46.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_47 = new lib.ClipGroup_47();
	this.instance_47.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_48 = new lib.ClipGroup_48();
	this.instance_48.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_49 = new lib.ClipGroup_49();
	this.instance_49.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_50 = new lib.ClipGroup_50();
	this.instance_50.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_51 = new lib.ClipGroup_51();
	this.instance_51.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_52 = new lib.ClipGroup_52();
	this.instance_52.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_53 = new lib.ClipGroup_53();
	this.instance_53.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_54 = new lib.ClipGroup_54();
	this.instance_54.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_55 = new lib.ClipGroup_55();
	this.instance_55.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_56 = new lib.ClipGroup_56();
	this.instance_56.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_57 = new lib.ClipGroup_57();
	this.instance_57.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_58 = new lib.ClipGroup_58();
	this.instance_58.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_59 = new lib.ClipGroup_59();
	this.instance_59.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_60 = new lib.ClipGroup_60();
	this.instance_60.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_61 = new lib.ClipGroup_61();
	this.instance_61.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_62 = new lib.ClipGroup_62();
	this.instance_62.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_63 = new lib.ClipGroup_63();
	this.instance_63.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_64 = new lib.ClipGroup_64();
	this.instance_64.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_65 = new lib.ClipGroup_65();
	this.instance_65.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_66 = new lib.ClipGroup_66();
	this.instance_66.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_67 = new lib.ClipGroup_67();
	this.instance_67.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_68 = new lib.ClipGroup_68();
	this.instance_68.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_69 = new lib.ClipGroup_69();
	this.instance_69.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_70 = new lib.ClipGroup_70();
	this.instance_70.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_71 = new lib.ClipGroup_71();
	this.instance_71.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_72 = new lib.ClipGroup_72();
	this.instance_72.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_73 = new lib.ClipGroup_73();
	this.instance_73.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_74 = new lib.ClipGroup_74();
	this.instance_74.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_75 = new lib.ClipGroup_75();
	this.instance_75.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_76 = new lib.ClipGroup_76();
	this.instance_76.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_77 = new lib.ClipGroup_77();
	this.instance_77.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_78 = new lib.ClipGroup_78();
	this.instance_78.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_79 = new lib.ClipGroup_79();
	this.instance_79.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_80 = new lib.ClipGroup_80();
	this.instance_80.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_81 = new lib.ClipGroup_81();
	this.instance_81.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_82 = new lib.ClipGroup_82();
	this.instance_82.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_83 = new lib.ClipGroup_83();
	this.instance_83.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_84 = new lib.ClipGroup_84();
	this.instance_84.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_85 = new lib.ClipGroup_85();
	this.instance_85.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_86 = new lib.ClipGroup_86();
	this.instance_86.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_87 = new lib.ClipGroup_87();
	this.instance_87.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_88 = new lib.ClipGroup_88();
	this.instance_88.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_89 = new lib.ClipGroup_89();
	this.instance_89.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_90 = new lib.ClipGroup_90();
	this.instance_90.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_91 = new lib.ClipGroup_91();
	this.instance_91.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_92 = new lib.ClipGroup_92();
	this.instance_92.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_93 = new lib.ClipGroup_93();
	this.instance_93.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_94 = new lib.ClipGroup_94();
	this.instance_94.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_95 = new lib.ClipGroup_95();
	this.instance_95.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_96 = new lib.ClipGroup_96();
	this.instance_96.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_97 = new lib.ClipGroup_97();
	this.instance_97.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_98 = new lib.ClipGroup_98();
	this.instance_98.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_99 = new lib.ClipGroup_99();
	this.instance_99.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_100 = new lib.ClipGroup_100();
	this.instance_100.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_101 = new lib.ClipGroup_101();
	this.instance_101.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_102 = new lib.ClipGroup_102();
	this.instance_102.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_103 = new lib.ClipGroup_103();
	this.instance_103.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_104 = new lib.ClipGroup_104();
	this.instance_104.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_105 = new lib.ClipGroup_105();
	this.instance_105.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_106 = new lib.ClipGroup_106();
	this.instance_106.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_107 = new lib.ClipGroup_107();
	this.instance_107.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_108 = new lib.ClipGroup_108();
	this.instance_108.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_109 = new lib.ClipGroup_109();
	this.instance_109.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_110 = new lib.ClipGroup_110();
	this.instance_110.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_111 = new lib.ClipGroup_111();
	this.instance_111.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_112 = new lib.ClipGroup_112();
	this.instance_112.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_113 = new lib.ClipGroup_113();
	this.instance_113.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_114 = new lib.ClipGroup_114();
	this.instance_114.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_115 = new lib.ClipGroup_115();
	this.instance_115.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_116 = new lib.ClipGroup_116();
	this.instance_116.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_117 = new lib.ClipGroup_117();
	this.instance_117.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_118 = new lib.ClipGroup_118();
	this.instance_118.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_119 = new lib.ClipGroup_119();
	this.instance_119.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_120 = new lib.ClipGroup_120();
	this.instance_120.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_121 = new lib.ClipGroup_121();
	this.instance_121.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_122 = new lib.ClipGroup_122();
	this.instance_122.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_123 = new lib.ClipGroup_123();
	this.instance_123.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_124 = new lib.ClipGroup_124();
	this.instance_124.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_125 = new lib.ClipGroup_125();
	this.instance_125.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_126 = new lib.ClipGroup_126();
	this.instance_126.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_127 = new lib.ClipGroup_127();
	this.instance_127.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_128 = new lib.ClipGroup_128();
	this.instance_128.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_129 = new lib.ClipGroup_129();
	this.instance_129.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_130 = new lib.ClipGroup_130();
	this.instance_130.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_131 = new lib.ClipGroup_131();
	this.instance_131.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_132 = new lib.ClipGroup_132();
	this.instance_132.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_133 = new lib.ClipGroup_133();
	this.instance_133.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_134 = new lib.ClipGroup_134();
	this.instance_134.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_135 = new lib.ClipGroup_135();
	this.instance_135.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_136 = new lib.ClipGroup_136();
	this.instance_136.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_137 = new lib.ClipGroup_137();
	this.instance_137.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_138 = new lib.ClipGroup_138();
	this.instance_138.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_139 = new lib.ClipGroup_139();
	this.instance_139.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_140 = new lib.ClipGroup_140();
	this.instance_140.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_141 = new lib.ClipGroup_141();
	this.instance_141.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_142 = new lib.ClipGroup_142();
	this.instance_142.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_143 = new lib.ClipGroup_143();
	this.instance_143.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_144 = new lib.ClipGroup_144();
	this.instance_144.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_145 = new lib.ClipGroup_145();
	this.instance_145.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_146 = new lib.ClipGroup_146();
	this.instance_146.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_147 = new lib.ClipGroup_147();
	this.instance_147.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_148 = new lib.ClipGroup_148();
	this.instance_148.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.instance_149 = new lib.ClipGroup_149();
	this.instance_149.setTransform(65.95,63.2,1,1,0,0,0,66.2,66.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_149},{t:this.instance_148},{t:this.instance_147},{t:this.instance_146},{t:this.instance_145},{t:this.instance_144},{t:this.instance_143},{t:this.instance_142},{t:this.instance_141},{t:this.instance_140},{t:this.instance_139},{t:this.instance_138},{t:this.instance_137},{t:this.instance_136},{t:this.instance_135},{t:this.instance_134},{t:this.instance_133},{t:this.instance_132},{t:this.instance_131},{t:this.instance_130},{t:this.instance_129},{t:this.instance_128},{t:this.instance_127},{t:this.instance_126},{t:this.instance_125},{t:this.instance_124},{t:this.instance_123},{t:this.instance_122},{t:this.instance_121},{t:this.instance_120},{t:this.instance_119},{t:this.instance_118},{t:this.instance_117},{t:this.instance_116},{t:this.instance_115},{t:this.instance_114},{t:this.instance_113},{t:this.instance_112},{t:this.instance_111},{t:this.instance_110},{t:this.instance_109},{t:this.instance_108},{t:this.instance_107},{t:this.instance_106},{t:this.instance_105},{t:this.instance_104},{t:this.instance_103},{t:this.instance_102},{t:this.instance_101},{t:this.instance_100},{t:this.instance_99},{t:this.instance_98},{t:this.instance_97},{t:this.instance_96},{t:this.instance_95},{t:this.instance_94},{t:this.instance_93},{t:this.instance_92},{t:this.instance_91},{t:this.instance_90},{t:this.instance_89},{t:this.instance_88},{t:this.instance_87},{t:this.instance_86},{t:this.instance_85},{t:this.instance_84},{t:this.instance_83},{t:this.instance_82},{t:this.instance_81},{t:this.instance_80},{t:this.instance_79},{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d3_sub_1, new cjs.Rectangle(-0.2,-3,132.39999999999998,132.4), null);


(lib.d3_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.d3_sub_1();
	this.instance.setTransform(45,562.2,1,1,0,0,0,66,63.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:27.1},49).to({regY:63.3,scaleY:0.8272,x:26,y:437.3},25).to({scaleY:1,x:18,y:266.2},20).to({y:563.25},10).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.2,-39,159.4,668.3);


(lib.d3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_159();
	this.instance.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_1 = new lib.ClipGroup_1_0();
	this.instance_1.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_2 = new lib.ClipGroup_2_0();
	this.instance_2.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_3 = new lib.ClipGroup_3_0();
	this.instance_3.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_4 = new lib.ClipGroup_4_0();
	this.instance_4.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_5 = new lib.ClipGroup_5_0();
	this.instance_5.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_6 = new lib.ClipGroup_6_0();
	this.instance_6.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_7 = new lib.ClipGroup_7_0();
	this.instance_7.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_8 = new lib.ClipGroup_8_0();
	this.instance_8.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_9 = new lib.ClipGroup_9_0();
	this.instance_9.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_10 = new lib.ClipGroup_10_0();
	this.instance_10.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_11 = new lib.ClipGroup_11_0();
	this.instance_11.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_12 = new lib.ClipGroup_12_0();
	this.instance_12.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_13 = new lib.ClipGroup_13_0();
	this.instance_13.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_14 = new lib.ClipGroup_14_0();
	this.instance_14.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_15 = new lib.ClipGroup_15_0();
	this.instance_15.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_16 = new lib.ClipGroup_16_0();
	this.instance_16.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_17 = new lib.ClipGroup_17_0();
	this.instance_17.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_18 = new lib.ClipGroup_18_0();
	this.instance_18.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_19 = new lib.ClipGroup_19_0();
	this.instance_19.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_20 = new lib.ClipGroup_20_0();
	this.instance_20.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_21 = new lib.ClipGroup_21_0();
	this.instance_21.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_22 = new lib.ClipGroup_22_0();
	this.instance_22.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_23 = new lib.ClipGroup_23_0();
	this.instance_23.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_24 = new lib.ClipGroup_24_0();
	this.instance_24.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_25 = new lib.ClipGroup_25_0();
	this.instance_25.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_26 = new lib.ClipGroup_26_0();
	this.instance_26.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_27 = new lib.ClipGroup_27_0();
	this.instance_27.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_28 = new lib.ClipGroup_28_0();
	this.instance_28.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_29 = new lib.ClipGroup_29_0();
	this.instance_29.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_30 = new lib.ClipGroup_30_0();
	this.instance_30.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_31 = new lib.ClipGroup_31_0();
	this.instance_31.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_32 = new lib.ClipGroup_32_0();
	this.instance_32.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_33 = new lib.ClipGroup_33_0();
	this.instance_33.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_34 = new lib.ClipGroup_34_0();
	this.instance_34.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_35 = new lib.ClipGroup_35_0();
	this.instance_35.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_36 = new lib.ClipGroup_36_0();
	this.instance_36.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_37 = new lib.ClipGroup_37_0();
	this.instance_37.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_38 = new lib.ClipGroup_38_0();
	this.instance_38.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_39 = new lib.ClipGroup_39_0();
	this.instance_39.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_40 = new lib.ClipGroup_40_0();
	this.instance_40.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_41 = new lib.ClipGroup_41_0();
	this.instance_41.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_42 = new lib.ClipGroup_42_0();
	this.instance_42.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_43 = new lib.ClipGroup_43_0();
	this.instance_43.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_44 = new lib.ClipGroup_44_0();
	this.instance_44.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_45 = new lib.ClipGroup_45_0();
	this.instance_45.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_46 = new lib.ClipGroup_46_0();
	this.instance_46.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_47 = new lib.ClipGroup_47_0();
	this.instance_47.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_48 = new lib.ClipGroup_48_0();
	this.instance_48.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_49 = new lib.ClipGroup_49_0();
	this.instance_49.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_50 = new lib.ClipGroup_50_0();
	this.instance_50.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_51 = new lib.ClipGroup_51_0();
	this.instance_51.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_52 = new lib.ClipGroup_52_0();
	this.instance_52.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_53 = new lib.ClipGroup_53_0();
	this.instance_53.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_54 = new lib.ClipGroup_54_0();
	this.instance_54.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_55 = new lib.ClipGroup_55_0();
	this.instance_55.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_56 = new lib.ClipGroup_56_0();
	this.instance_56.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_57 = new lib.ClipGroup_57_0();
	this.instance_57.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_58 = new lib.ClipGroup_58_0();
	this.instance_58.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_59 = new lib.ClipGroup_59_0();
	this.instance_59.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_60 = new lib.ClipGroup_60_0();
	this.instance_60.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_61 = new lib.ClipGroup_61_0();
	this.instance_61.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_62 = new lib.ClipGroup_62_0();
	this.instance_62.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_63 = new lib.ClipGroup_63_0();
	this.instance_63.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_64 = new lib.ClipGroup_64_0();
	this.instance_64.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_65 = new lib.ClipGroup_65_0();
	this.instance_65.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_66 = new lib.ClipGroup_66_0();
	this.instance_66.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_67 = new lib.ClipGroup_67_0();
	this.instance_67.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_68 = new lib.ClipGroup_68_0();
	this.instance_68.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_69 = new lib.ClipGroup_69_0();
	this.instance_69.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_70 = new lib.ClipGroup_70_0();
	this.instance_70.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_71 = new lib.ClipGroup_71_0();
	this.instance_71.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_72 = new lib.ClipGroup_72_0();
	this.instance_72.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_73 = new lib.ClipGroup_73_0();
	this.instance_73.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_74 = new lib.ClipGroup_74_0();
	this.instance_74.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_75 = new lib.ClipGroup_75_0();
	this.instance_75.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_76 = new lib.ClipGroup_76_0();
	this.instance_76.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_77 = new lib.ClipGroup_77_0();
	this.instance_77.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_78 = new lib.ClipGroup_78_0();
	this.instance_78.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_79 = new lib.ClipGroup_79_0();
	this.instance_79.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_80 = new lib.ClipGroup_80_0();
	this.instance_80.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_81 = new lib.ClipGroup_81_0();
	this.instance_81.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_82 = new lib.ClipGroup_82_0();
	this.instance_82.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_83 = new lib.ClipGroup_83_0();
	this.instance_83.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_84 = new lib.ClipGroup_84_0();
	this.instance_84.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_85 = new lib.ClipGroup_85_0();
	this.instance_85.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_86 = new lib.ClipGroup_86_0();
	this.instance_86.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_87 = new lib.ClipGroup_87_0();
	this.instance_87.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_88 = new lib.ClipGroup_88_0();
	this.instance_88.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_89 = new lib.ClipGroup_89_0();
	this.instance_89.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_90 = new lib.ClipGroup_90_0();
	this.instance_90.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_91 = new lib.ClipGroup_91_0();
	this.instance_91.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_92 = new lib.ClipGroup_92_0();
	this.instance_92.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_93 = new lib.ClipGroup_93_0();
	this.instance_93.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_94 = new lib.ClipGroup_94_0();
	this.instance_94.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_95 = new lib.ClipGroup_95_0();
	this.instance_95.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_96 = new lib.ClipGroup_96_0();
	this.instance_96.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_97 = new lib.ClipGroup_97_0();
	this.instance_97.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_98 = new lib.ClipGroup_98_0();
	this.instance_98.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_99 = new lib.ClipGroup_99_0();
	this.instance_99.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_100 = new lib.ClipGroup_100_0();
	this.instance_100.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_101 = new lib.ClipGroup_101_0();
	this.instance_101.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_102 = new lib.ClipGroup_102_0();
	this.instance_102.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_103 = new lib.ClipGroup_103_0();
	this.instance_103.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_104 = new lib.ClipGroup_104_0();
	this.instance_104.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_105 = new lib.ClipGroup_105_0();
	this.instance_105.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_106 = new lib.ClipGroup_106_0();
	this.instance_106.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_107 = new lib.ClipGroup_107_0();
	this.instance_107.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_108 = new lib.ClipGroup_108_0();
	this.instance_108.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_109 = new lib.ClipGroup_109_0();
	this.instance_109.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_110 = new lib.ClipGroup_110_0();
	this.instance_110.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_111 = new lib.ClipGroup_111_0();
	this.instance_111.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_112 = new lib.ClipGroup_112_0();
	this.instance_112.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_113 = new lib.ClipGroup_113_0();
	this.instance_113.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_114 = new lib.ClipGroup_114_0();
	this.instance_114.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_115 = new lib.ClipGroup_115_0();
	this.instance_115.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_116 = new lib.ClipGroup_116_0();
	this.instance_116.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_117 = new lib.ClipGroup_117_0();
	this.instance_117.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_118 = new lib.ClipGroup_118_0();
	this.instance_118.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_119 = new lib.ClipGroup_119_0();
	this.instance_119.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_120 = new lib.ClipGroup_120_0();
	this.instance_120.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_121 = new lib.ClipGroup_121_0();
	this.instance_121.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_122 = new lib.ClipGroup_122_0();
	this.instance_122.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_123 = new lib.ClipGroup_123_0();
	this.instance_123.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_124 = new lib.ClipGroup_124_0();
	this.instance_124.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_125 = new lib.ClipGroup_125_0();
	this.instance_125.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_126 = new lib.ClipGroup_126_0();
	this.instance_126.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_127 = new lib.ClipGroup_127_0();
	this.instance_127.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_128 = new lib.ClipGroup_128_0();
	this.instance_128.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_129 = new lib.ClipGroup_129_0();
	this.instance_129.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_130 = new lib.ClipGroup_130_0();
	this.instance_130.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_131 = new lib.ClipGroup_131_0();
	this.instance_131.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_132 = new lib.ClipGroup_132_0();
	this.instance_132.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_133 = new lib.ClipGroup_133_0();
	this.instance_133.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_134 = new lib.ClipGroup_134_0();
	this.instance_134.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_135 = new lib.ClipGroup_135_0();
	this.instance_135.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_136 = new lib.ClipGroup_136_0();
	this.instance_136.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_137 = new lib.ClipGroup_137_0();
	this.instance_137.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_138 = new lib.ClipGroup_138_0();
	this.instance_138.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_139 = new lib.ClipGroup_139_0();
	this.instance_139.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_140 = new lib.ClipGroup_140_0();
	this.instance_140.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_141 = new lib.ClipGroup_141_0();
	this.instance_141.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_142 = new lib.ClipGroup_142_0();
	this.instance_142.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_143 = new lib.ClipGroup_143_0();
	this.instance_143.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_144 = new lib.ClipGroup_144_0();
	this.instance_144.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_145 = new lib.ClipGroup_145_0();
	this.instance_145.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_146 = new lib.ClipGroup_146_0();
	this.instance_146.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_147 = new lib.ClipGroup_147_0();
	this.instance_147.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_148 = new lib.ClipGroup_148_0();
	this.instance_148.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_149 = new lib.ClipGroup_149_0();
	this.instance_149.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_150 = new lib.ClipGroup_150();
	this.instance_150.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_151 = new lib.ClipGroup_151();
	this.instance_151.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_152 = new lib.ClipGroup_152();
	this.instance_152.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_153 = new lib.ClipGroup_153();
	this.instance_153.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_154 = new lib.ClipGroup_154();
	this.instance_154.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_155 = new lib.ClipGroup_155();
	this.instance_155.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_156 = new lib.ClipGroup_156();
	this.instance_156.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_157 = new lib.ClipGroup_157();
	this.instance_157.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.instance_158 = new lib.ClipGroup_158();
	this.instance_158.setTransform(90.75,86.9,1,1,0,0,0,90.9,90.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_158},{t:this.instance_157},{t:this.instance_156},{t:this.instance_155},{t:this.instance_154},{t:this.instance_153},{t:this.instance_152},{t:this.instance_151},{t:this.instance_150},{t:this.instance_149},{t:this.instance_148},{t:this.instance_147},{t:this.instance_146},{t:this.instance_145},{t:this.instance_144},{t:this.instance_143},{t:this.instance_142},{t:this.instance_141},{t:this.instance_140},{t:this.instance_139},{t:this.instance_138},{t:this.instance_137},{t:this.instance_136},{t:this.instance_135},{t:this.instance_134},{t:this.instance_133},{t:this.instance_132},{t:this.instance_131},{t:this.instance_130},{t:this.instance_129},{t:this.instance_128},{t:this.instance_127},{t:this.instance_126},{t:this.instance_125},{t:this.instance_124},{t:this.instance_123},{t:this.instance_122},{t:this.instance_121},{t:this.instance_120},{t:this.instance_119},{t:this.instance_118},{t:this.instance_117},{t:this.instance_116},{t:this.instance_115},{t:this.instance_114},{t:this.instance_113},{t:this.instance_112},{t:this.instance_111},{t:this.instance_110},{t:this.instance_109},{t:this.instance_108},{t:this.instance_107},{t:this.instance_106},{t:this.instance_105},{t:this.instance_104},{t:this.instance_103},{t:this.instance_102},{t:this.instance_101},{t:this.instance_100},{t:this.instance_99},{t:this.instance_98},{t:this.instance_97},{t:this.instance_96},{t:this.instance_95},{t:this.instance_94},{t:this.instance_93},{t:this.instance_92},{t:this.instance_91},{t:this.instance_90},{t:this.instance_89},{t:this.instance_88},{t:this.instance_87},{t:this.instance_86},{t:this.instance_85},{t:this.instance_84},{t:this.instance_83},{t:this.instance_82},{t:this.instance_81},{t:this.instance_80},{t:this.instance_79},{t:this.instance_78},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.d3_1, new cjs.Rectangle(-0.1,-4,181.79999999999998,181.9), null);


(lib.d3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.d3_1();
	this.instance.setTransform(1698.95,-237.15,1,1,0,0,0,90.8,86.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:90.7,rotation:-167.5309,x:732.65,y:699},49).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(624.2,-328,1165.6,1135.4);


(lib.d2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.d2_s1();
	this.instance.setTransform(125.65,125.1,0.0611,0.0611,91.0731,0,0,124.3,125.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.6742,scaleY:0.6742,rotation:14.624,x:125.35,y:125.55},32).to({regX:125.2,regY:125.8,scaleX:1,scaleY:1,rotation:-25.9883,x:125.2,y:125.85,alpha:0},17).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,0.2,250.10000000000002,261);


(lib.d1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance = new lib.d1_l1();
	this.instance.setTransform(-269.8,-287.35,1,1,0,0,0,309.6,309.6);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(54).to({_off:false},0).to({x:10.2,y:2.65},10).wait(3));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_1 = new lib.d1_l1();
	this.instance_1.setTransform(-258.7,-276.65,1,1,0,0,0,309.6,309.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(52).to({_off:false},0).to({x:21.3,y:13.35},10).wait(5));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_2 = new lib.d1_l1();
	this.instance_2.setTransform(-249.3,-263.15,1,1,0,0,0,309.6,309.6);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({x:30.7,y:26.85},10).wait(7));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_3 = new lib.d1_l1();
	this.instance_3.setTransform(-237.8,-251.65,1,1,0,0,0,309.6,309.6);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(48).to({_off:false},0).to({x:42.2,y:38.35},10).wait(9));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_4 = new lib.d1_l1();
	this.instance_4.setTransform(-227.1,-240.95,1,1,0,0,0,309.6,309.6);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(46).to({_off:false},0).to({x:52.9,y:49.05},10).wait(11));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_5 = new lib.d1_l1();
	this.instance_5.setTransform(-217.7,-227.45,1,1,0,0,0,309.6,309.6);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(44).to({_off:false},0).to({x:62.3,y:62.55},10).wait(13));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_6 = new lib.d1_l1();
	this.instance_6.setTransform(-208.3,-213.95,1,1,0,0,0,309.6,309.6);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(42).to({_off:false},0).to({x:71.7,y:76.05},10).wait(15));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_7 = new lib.d1_l1();
	this.instance_7.setTransform(-198.8,-200.75,1,1,0,0,0,309.6,309.6);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(40).to({_off:false},0).to({x:81.2,y:89.25},10).wait(17));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_8 = new lib.d1_l1();
	this.instance_8.setTransform(-187.7,-189.65,1,1,0,0,0,309.6,309.6);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(38).to({_off:false},0).to({x:92.3,y:100.35},10).wait(19));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_9 = new lib.d1_l1();
	this.instance_9.setTransform(-176.6,-178.55,1,1,0,0,0,309.6,309.6);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(36).to({_off:false},0).to({x:103.4,y:111.45},10).wait(21));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_10 = new lib.d1_l1();
	this.instance_10.setTransform(-165.1,-167.45,1,1,0,0,0,309.6,309.6);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(34).to({_off:false},0).to({x:114.9,y:122.55},10).wait(23));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_11 = new lib.d1_l1();
	this.instance_11.setTransform(-153.6,-156.35,1,1,0,0,0,309.6,309.6);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(32).to({_off:false},0).to({x:126.4,y:133.65},10).wait(25));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_12 = new lib.d1_l1();
	this.instance_12.setTransform(-142.1,-145.25,1,1,0,0,0,309.6,309.6);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(29).to({_off:false},0).to({x:137.9,y:144.75},10).wait(28));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_13 = new lib.d1_l1();
	this.instance_13.setTransform(-128.5,-136.55,1,1,0,0,0,309.6,309.6);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(27).to({_off:false},0).to({x:151.5,y:153.45},10).wait(30));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_14 = new lib.d1_l1();
	this.instance_14.setTransform(-117,-125.45,1,1,0,0,0,309.6,309.6);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(25).to({_off:false},0).to({x:163,y:164.55},10).wait(32));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_15 = new lib.d1_l1();
	this.instance_15.setTransform(-105.9,-114.35,1,1,0,0,0,309.6,309.6);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(23).to({_off:false},0).to({x:174.1,y:175.65},10).wait(34));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_16 = new lib.d1_l1();
	this.instance_16.setTransform(-92.8,-104.95,1,1,0,0,0,309.6,309.6);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(21).to({_off:false},0).to({x:187.2,y:185.05},10).wait(36));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_17 = new lib.d1_l1();
	this.instance_17.setTransform(-79.7,-95.95,1,1,0,0,0,309.6,309.6);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(19).to({_off:false},0).to({x:200.3,y:194.05},10).wait(38));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_18 = new lib.d1_l1();
	this.instance_18.setTransform(-68.2,-85.25,1,1,0,0,0,309.6,309.6);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(17).to({_off:false},0).to({x:211.8,y:204.75},10).wait(40));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy_copy
	this.instance_19 = new lib.d1_l1();
	this.instance_19.setTransform(-54.7,-76.25,1,1,0,0,0,309.6,309.6);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(15).to({_off:false},0).to({x:225.3,y:213.75},10).wait(42));

	// Layer_2_copy_copy_copy_copy_copy_copy_copy
	this.instance_20 = new lib.d1_l1();
	this.instance_20.setTransform(-42.4,-65.95,1,1,0,0,0,309.6,309.6);
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(13).to({_off:false},0).to({x:237.6,y:224.05},10).wait(44));

	// Layer_2_copy_copy_copy_copy_copy_copy
	this.instance_21 = new lib.d1_l1();
	this.instance_21.setTransform(-29.3,-56.55,1,1,0,0,0,309.6,309.6);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(11).to({_off:false},0).to({x:250.7,y:233.45},10).wait(46));

	// Layer_2_copy_copy_copy_copy_copy
	this.instance_22 = new lib.d1_l1();
	this.instance_22.setTransform(-20.3,-43.05,1,1,0,0,0,309.6,309.6);
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(9).to({_off:false},0).to({x:259.7,y:246.95},10).wait(48));

	// Layer_2_copy_copy_copy_copy
	this.instance_23 = new lib.d1_l1();
	this.instance_23.setTransform(-8.8,-31.55,1,1,0,0,0,309.6,309.6);
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(7).to({_off:false},0).to({x:271.2,y:258.45},10).wait(50));

	// Layer_2_copy_copy_copy
	this.instance_24 = new lib.d1_l1();
	this.instance_24.setTransform(2.4,-21.35,1,1,0,0,0,309.6,309.6);
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(5).to({_off:false},0).to({x:282.4,y:268.65},10).wait(52));

	// Layer_2_copy_copy
	this.instance_25 = new lib.d1_l1();
	this.instance_25.setTransform(291.8,282.55,1,1,0,0,0,309.6,309.6);
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(3).to({_off:false},0).wait(64));

	// Layer_2_copy
	this.instance_26 = new lib.d1_l1();
	this.instance_26.setTransform(-19.2,-13.95,1,1,0,0,0,309.6,309.6);
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(2).to({_off:false},0).to({x:300.8,y:296.05},10).wait(55));

	// Layer_2
	this.instance_27 = new lib.d1_l1();
	this.instance_27.setTransform(-10.4,-10.4,1,1,0,0,0,309.6,309.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_27).to({x:309.6,y:309.6},10).wait(57));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-579.4,-596.9,2627.4,2132.9);


(lib.cursorGif = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_160();
	this.instance.setTransform(0,0.05,1,1,0,0,0,119.1,123.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cursorGif, new cjs.Rectangle(-119.1,-123.3,238.2,246.7), null);


(lib.correct_pop_msg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}
	this.frame_1 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.play();
	}
	this.frame_59 = function() {
		ths.moveNextQuestion();
		ths.pop_mc.gotoAndStop(0);
		
		this.gotoAndStop(0);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(58).call(this.frame_59).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#281800").s().p("EggbAHeQg3gOgmgZQgmgZgTghQgVgiAAgkIAAgqQAAglAVgiQATghAmgZQAmgYA3gPQA1gOBGAAQBFAAA2AOQA2APAnAYQAlAZAUAhQAVAiAAAlIAAAqQAAAlgVAhQgUAhglAZQgnAZg2AOQg2AOhFAAQhGAAg1gOgA/wC0QgkAJgZAPQgZAQgNASQgNASAAATIAAAdQAAAUANASQANASAZAPQAZAPAkAJQAkAJAsAAQAtAAAkgJQAjgJAZgPQAagPANgSQANgTAAgTIAAgdQAAgSgNgTQgNgSgagQQgZgPgjgJQgkgJgtAAQgsAAgkAJgAerHRIAAu8IBmAAIAAFaICVAAIAABZIiVAAIAAIJgAQrHRIAAu8IBmAAIAAO8gAl4HRIAAmiIBlAAIAAB3IGJAAIAAh3IBmAAIAAGigAkTF6IGJAAIAAh9ImJAAgA1BHRIAAmlIBmAAIAAB5IF8AAIAAh5IBlAAIAAGlgAzbF6IF8AAIAAh+Il8AAgEAkUAGFIAAh3IB3AAIAAB3gAVUDVIAApqIG3AAIAABZIlRAAIAAG4IA3AAQBiAABcgHQBcgHBWgNIANBWQheARhgAGQheAHh3AAgAHBmcIBnAAIAAISIBdAAQBcAABKgFQBVgHBMgOIALBaQgvAIgnAFIhUAJQgwADgrABIkRABgEAkkACjIgPpcIB1AAIgOJcgA7kBKIAAjyIixAAIAAhXICxAAIAAjsIBlAAIAAI1gEgmKgAGQAygjArgiQAqggAegdQAQgQAQgUQANgSAJgTQAHgVADgVQAEgYAAgaIAAgrIjJAAIAAhXIHuAAIAABXIi9AAIAAAnQAAAXACAVQACARAGAUQAHASAJANQALAPARAQQApAlAkAbQAqAgAtAdIg6BJQgjgYgpgeIhJg6QgVgRgRgSQgPgPgFgLIgBAAQgGANgTAYQgVAYgYAUQgnAhgjAbQggAZg1AmgAB2ABIAAnsIBmAAIAAHsgAtfgBIAAnqIBlAAIAADGICIAAIAABaIiIAAIAADKgAmNgjQgugTgcgbQgdgdgPgkQgQgjAAglIAAgnQAAglAQgkQAPgkAdgcQAcgbAugTQAtgSA7AAQA6AAAuASQAvATAbAbQAeAcAOAkQAQAkAAAlIAAAnQAAAkgQAkQgOAkgeAdQgcAbguATQgsARg8AAQg8AAgsgRgAlglmQgZAKgTAQQgRARgKAUQgJAVAAAWIAAAdQAAAWAJAVQAKAVARARQASAQAaALQAZAKAiAAQAhAAAagKQAagLASgQQASgRAJgVQAJgVAAgWIAAgdQAAgWgJgVQgKgUgRgRQgSgQgagKQgagLghAAQgiAAgZALgA3BmyIG9AAIAABXIlWAAIAADhQBPAAA4gCQA3AAAugDIBYgFIBhgKIAKBUQhBAIgmADQgjAEhHADQhLADg8ABIi+ABg");
	this.shape.setTransform(-10.95,203.025);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(38).to({_off:false},0).wait(22));

	// Layer_4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EDE0DA").s().p("AgYBsQgOhMgDguQgEhAANgeQA8BMAPB9IgHAGQgTAKgiAAg");
	this.shape_1.setTransform(281.8671,-415.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EDE0DA").s().p("AiRC4IgDAAIAAAAQgWgKgRgQQgUgVgJgfQgHgYAAggIABgeIABgBIAAgFQAtgPBEgpQBKguBjhKIAdgWQBDANAmBHQAlBFgQBHIgBABIgBAAQhHAphNAkQhDAfgxARQgcAJgYAFQgWAFgQAAg");
	this.shape_2.setTransform(396.0438,-302.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EDE0DA").s().p("Ai7CmQgFgDgEgFQgJgLgEgRQgFgYABgYQgBggAJgwIAGgYIABgGIATgDQA2gMBBgbQBigoBug9QBTA9gUBGQgRA7hZA9QgXAQg4AZIhtAuQgRgFgOAEQgYAGgUAAQgSAAgLgGg");
	this.shape_3.setTransform(406.8929,-269.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EDE0DA").s().p("AhaDyQgEAAgFgDQgNgJgLgWQgNgZAAggQAAglATgeQAXgmAwgYQAXgMAHgXQAIgYgLgWQgMgXgYgIQgYgIgWAMQhPAogqBCQgbAugHA1IgOgfQgHgTgJgdQAygqCKh8QB8hnA5gJQC2gbAWDcIgDACIgEAEQhcBVhWBHQhGA4g0AjQgeASgTAIIgPAHIgFABg");
	this.shape_4.setTransform(353.95,-360.3229);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EDE0DA").s().p("As2LIIE1jDQgFiABmi6IBSiVQAuhVAUg/QAwieAgj0QAjkQgXiGIgHgnQA6AAAdgXQAUgQACgRIABgDIgBgDQgMh2gzhTIgUgcQArAHBNBIQBKBGAxDWIAnCtQAZBhAcA7IAHAXQANAxARApQATAzAVAdQAEAIAGANQAKAbAHApQAIAxgBA0QABCjhKCRQheC7jLB7QgNAIgEAPQgEAPAJANQAHANAPAEQAOADANgIQDeiFBojPQBRigAAi1QAAgigDggQAPAPAOAJQAfAUAlABQABA4AJAqQAKAnAQAcQAYAsAqAXQAgAQAlADIAAAPQAAAeAEAbIgqgCQhSAAhoAWQggAHgeAIIgZAHQgOAFgHANQgHAOAFAOQAEAPAOAHQANAHAPgFIAAAAQArgNAugJQBbgSBGAAQAnAAAcAFQAQAhAaAaQAZAbAmATIgGAWQgKA5AAAuQAAAlAGAeQAGAbALAYQAUApAjAYIhiBxQg/BHgrAgQifB4jmApQjEAji5gcIlYDWg");
	this.shape_5.setTransform(298.6,-306.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EDE0DA").s().p("AjCDPQgEgCgHgGQgLgLgIgdQgKglAAg6IAAgYQAwgcA6grQBnhPBqhlQBIAKApA2QAkAwAFBKIgBABIgCACQhgBJgwAiQg/AsgrAaQgzAggfAKQgrAPgbAAQgNAAgLgFg");
	this.shape_6.setTransform(379.95,-332.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#493728").s().p("AyQJ2IE4iyQAKhbAthoQAbg9BAhxQAohFASgkQAdg4ANgsQAnh+AhjvQAlkRgUh2IgHgqQgciXAAhFQAAhgAsg0QAVgZAegOQAdgOAiAAQAuAAAwAaQAxAaA9A6QBFBAAoBmQAXA8AbB4QAuDVALAhQCGh5BEgxQBehEBEgKQAcgFAbAAQB1AABJBNQBPBRALCkQBeAcA2BNQAiAvAPA+QAOA9gFBEQBSAsApBfQAXAzAEA0QAFA1gNAyQBTBGAOBdQALBMgeA1QggA1hlBNQg8Ash9A4IhYAmQg4AYgLAMIhwB/QhEBLgoAeQh8BdilAxQidAvinAAIhcABQg8AAgkgFIjbBzIiaBggAlzywQAzBUAMB1IABADIgBADQgCASgUAQQgdAXg6AAIAHAnQAXCGgjEPQgfD1gxCeQgTA/guBUIhTCWQhlC6AFB/Ik2DEIFIIIIFZjWQC5AcDEgjQDlgpCfh3QAsghA+hHIBihxQgjgYgUgoQgLgZgGgbQgGgeAAgkQAAgvALg4IAFgXQgmgTgZgaQgagagQghQgcgGgnAAQhFAAhcATQgtAJgrAMIgBABQgPAEgNgHQgOgHgEgOQgFgPAHgNQAHgOAPgEIAZgHQAdgIAhgHQBngWBSAAIArACQgFgbAAgfIAAgPQglgCgfgRQgrgWgYgtQgQgbgJgoQgKgpgBg4QgkgCgggUQgOgJgPgOQADAfAAAiQAAC2hRCgQhnDPjeCFQgNAIgPgEQgOgEgIgNQgIgNAEgPQADgOANgIQDNh7Bei7QBIiSAAijQAAg0gIgwQgHgpgKgcQgFgNgFgIQgUgdgTgzQgQgpgOgxIgGgXQgdg6gYhhIgoitQgxjWhLhHQhMhIgsgGgAMUEwQhBAag2AMIgTADIgBAGIgGAaQgJAvABAhQgBAXAFAYQAEARAJALQAEAGAFACQALAGASAAQAUAAAYgGQAOgEARAFIBuguQA4gZAXgPQBZg+ARg8QAUhFhTg+QhuA9hjApgAMmh4QhkBLhKAtQhEApgtAQIgBAEIAAABIAAABIgCAdQAAAgAIAZQAIAfAUAVQARAQAWAJIABAAIACABIAKABQAQAAAWgFQAYgGAcgJQAygQBDggQBMgjBIgpIAAgBIABAAQAQhJgkhEQgmhHhDgNgAHCkfQg5AsgwAcIAAAYQAAA6AKAlQAIAdALALQAGAGAFACQAKAFAOAAQAbAAAqgPQAggKAzggQAsgaA+gsQAxgiBfhKIADgCIABgBQgFhKgkgwQgpg2hIgKQhrBlhoBPgAEIp0QAYAIALAXQAMAWgIAYQgIAYgWAMQgwAYgXAmQgTAeAAAlQAAAgANAZQAKAWAOAJQAFADADAAIACAAIAEgBIAQgHQATgIAegSQA1gjBGg4QBWhHBchWIADgEIAEgCQgWjci2AbQg5AJh9BnQiKB8gyArQAJAdAHATIAOAfQAGg1AcguQAqhDBOgoQAOgHANAAQAKAAAKADgAm6xUQADAuAOBNIAHAAQAjAAATgKIAHgFQgPiAg9hKQgNAdAEBBg");
	this.shape_7.setTransform(321.9574,-306.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},30).wait(30));

	// Layer_3
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F9DB56").s().p("Ak2MuICq5cIHDAAIj7Zcg");
	this.shape_8.setTransform(195.725,-287.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F9DB56").s().p("AkBDdIA+m6IHFAAIg+G6g");
	this.shape_9.setTransform(178.4,-167.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#493728").s().p("AtdXOIg/AMIgLhYQgLhUgVhxIgUhtQhUAhhcAZQi/A0krA8IiiAeQj6A0i+ApQjSAujJAvIhVAUIgThlIg5AOIhioFIBZgKQAxgFAjgGIIEhgIgaiMQhmBTh3BFIgvAbIm2lFIAZgMIhmhLIB7g9QCHhCBehKQBbhJA2hMQAbglARgfIiUAbQg5ALg9ARIhXAZIgUhnIg5ARIhioIIBcgIQA4gEAxgKIBsgUIhXnLIBYgLQApgFApgIIKVh9QAlgHArgLIBWgWIAUBnIA5gPIBEFoIAygJQAygJA1gQIBYgbIAUBpIA5gRIBiIIIhbAIQg7AGg9ALIj1AuQCbBvEYAcIBQAIIidtBQgShggWhkQgXhmgWhVIgWhWII5hsIAMBkIBAgMIALBYQANBlAQBSIFBakIgHhiIBWgDQD7gJEBgTID6gTIgnoKQgFhQgLhjQgJhdgMhOIgMhZIJHgrIABBeIBXgGIAABZQABBYAEBLIAsJqILXg1QBGgFA/gIIACAAIACAAQBNgGA4gFIBBgHIAXikIAoAAIC776IJvAAIgRBuIByAAIkTb6IAvAAIhVJhImMAAIADApIhYACQhrABhzAJMggJACXQhtAHhxAPIhXALIgHhiIggAEIAZCGQAVBtAWBXIAVBVIoyBqgAt1StQASBhAOBqIGEhKQgYhggThoMgGqgjOQgShfgMheImKBLQAXBbAWBkQAYBsAQBZIEJV3QhvBHi3A1QivAzkdA9Ig8k9QgMg9gDgyImHBKQAQAyAMA5IA+FBIoDBhIhWAPQgvAIgoAEIBAFXQDhg1C8gpQDVguDlgvIChgeQErg8C6gyQC7gzB+hNgAGFmEQALBMAKBiQALBkAFBSIAtJdIlNAZQkHATj3AJIAZFfQBpgOB5gJMAgJgCXQAogDAogBIAxlcIguAEQguAFhZAHQhKAJg/AEIt7BBIg5scQgEhJgBhegEAg+ALYIHHAAIA+m7InHAAgA6AIYIAZCFQC6gqCAgmQCEgmBcgwIg0kVIi3FCIg3gGQiQgQiLg0IAKA+gEglXgA1QgcBVg9BSQg+BWhjBQQhjBOiRBIIEcDTQC6hrCEiGQCEiFA8jNQB+CHClBOQClBOCxATICskvQn4gziVk5IF8hIQA/gMBBgGIhAlUQg3ARg5ALIy9DlQg0AKg9AFIBAFUQBBgTA8gLIF/hJQgDBOgbBVgEAi3AB/IFzAAID65cInDAAgAyeBMIgDgRIgIAPIALACgA+wxIIqVB9QgpAIguAFIA+FFINBieIg9lEQglAJgxAKg");
	this.shape_10.setTransform(-58.425,-218.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F9DB56").s().p("AzCFbQD3gJEIgTIFNgYIgtpeQgFhSgKhkQgLhhgLhNIGVgeQABBeAFBJIA3McIN7hBQA/gEBKgJQBZgGAugGIAugEIgxFcQgoABgoADMggJACXQh5AKhpANg");
	this.shape_11.setTransform(26.15,-190.65);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F9DB56").s().p("AI3JMQANinAKiuQAGisAFjIQADi4gEiYI03BiQh0AJhuAOIgalfQD/gJEBgTIWyhrQAECKABDCQgBDfgDDWQgGDigPDrQgNDggYCrIl+AcQAMhXALiYg");
	this.shape_12.setTransform(15.45,-277.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#493728").s().p("AH7NiIhkAHIAOhlQAKhLANigQAMifAKizQAIjRADihIABiXIyIBVQhtAJhxAOIhXALIgHhiIhQAKIgnoMIBWgDQD8gKEBgSIYKhyIACBeIBVgGIACBXQADBqABDlQABDRgEDlQgHDvgODhQgODpgXCpIgJBCIopApgAIwipQgEDIgHCsQgJCugNCmQgMCYgMBYIF/gcQAXisAOjfQAOjsAGjhQAEjWAAjfQgBjCgDiKI2zBrQkBASj+AKIAZFeQBugNB0gJIU3hiQAECYgDC4g");
	this.shape_13.setTransform(19.51,-273);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F9DB56").s().p("AL4SEIg+lKQh/BNi7AzQi5AykqA8IihAeQjmAvjUAuQi9ApjgA1IhBlXQApgEAugIIBXgPIIChhIgojSQgIgugOhBQgOhAgOgrIGIhKQADAyAMA9IA7E9QEdg9CugzQC4g1BuhHIkI13QgRhZgXhsQgWhkgXhbIGKhLQALBeASBfMAGqAjOQAUBoAYBgImEBKQgOhqgThhg");
	this.shape_14.setTransform(-223.075,-214.425);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F9DB56").s().p("Am/hTQAugFAqgHIKTh9QAygLAkgJIA+FEIiRAYIqwCFg");
	this.shape_15.setTransform(-285.35,-306.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F9DB56").s().p("AsHHZQCShIBihPQBkhPA9hWQA9hTAchUQAbhVADhOIl+BIQg9AMhBASIhAlTQA+gGA0gKIS8jlQA4gLA3gQIBAFUQhAAFhAAMIl7BIQCUE5H5AzIitEwQiwgUilhOQimhOh+iGQg7DMiECGQiECFi6Brg");
	this.shape_16.setTransform(-269.475,-222.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]},23).wait(37));

	// Layer_5
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgCgLAGgKQAHgLAMgCQALgDALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_17.setTransform(198.0362,-102.5732);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_18.setTransform(178.0732,-98.4768);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgCgLAGgKQAHgLAMgCQALgCALAGQAKAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_19.setTransform(158.0862,-94.4138);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgKQAHgLAMgCQALgDAKAHQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_20.setTransform(138.125,-90.3232);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgLQAHgKAMgCQALgDALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_21.setTransform(118.1268,-86.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgDQALgCAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_22.setTransform(98.1732,-82.1406);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgCgLAGgKQAHgLAMgCQALgDALAHQAKAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_23.setTransform(78.1862,-78.0732);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgKQAHgLAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_24.setTransform(58.2232,-73.9732);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgLQAHgKAMgCQALgDALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_25.setTransform(38.2268,-69.8768);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgKQAHgLAMgCQALgCAKAGQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_26.setTransform(18.2594,-65.8138);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgKQAHgLAMgCQALgDALAHQAKAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_27.setTransform(-1.725,-61.7232);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_28.setTransform(-21.6906,-57.6268);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgDQALgCAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_29.setTransform(-41.675,-53.5406);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgKQAHgLAMgCQALgDAKAHQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_30.setTransform(-61.6406,-49.4732);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_31.setTransform(-81.625,-45.375);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgCgLAGgLQAHgKAMgCQALgDALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_32.setTransform(-101.6138,-41.2768);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgKQAHgLAMgCQALgCAKAGQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_33.setTransform(-121.5768,-37.2138);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#493728").s().p("AgRAbQgLgHgDgOQgCgMAHgLQAIgLANgDQAMgCALAHQALAIADANQACAMgHALQgHALgNADIgHAAQgIAAgJgFg");
	this.shape_34.setTransform(-141.5734,-33.1234);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_35.setTransform(-161.5268,-29.0268);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgKQAHgLAMgCQALgCAKAGQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_36.setTransform(193.9232,-122.8138);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_37.setTransform(173.925,-118.725);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#493728").s().p("AgSAeQgNgIgDgPQgDgNAIgNQAJgMAOgDQANgDAMAIQANAIADAPQADANgIANQgJAMgOADIgHABQgJAAgJgGg");
	this.shape_38.setTransform(153.95,-114.6268);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#493728").s().p("AgTAeQgMgJgDgOQgDgNAIgMQAIgNAPgDQANgDANAIQAMAIADAPQADAOgIAMQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_39.setTransform(133.975,-110.55);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#493728").s().p("AgSAeQgNgIgDgPQgDgNAIgNQAJgMAOgDQANgDAMAIQANAIADAPQADANgIANQgJAMgOADIgHABQgKAAgIgGg");
	this.shape_40.setTransform(114,-106.4732);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_41.setTransform(94.025,-102.375);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#493728").s().p("AgTAeQgMgIgDgOQgDgOAIgMQAJgNAOgDQANgDAMAIQANAJADAOQADAOgIAMQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_42.setTransform(74.05,-98.3);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAJADAOQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_43.setTransform(54.075,-94.2139);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAOgDQAOgDAMAIQANAIADAPQADANgIANQgJAMgOADIgHABQgKAAgJgGg");
	this.shape_44.setTransform(34.1,-90.125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgJAAgKgGg");
	this.shape_45.setTransform(14.125,-86.0361);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgOAIgMQAJgMAOgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_46.setTransform(-5.8639,-81.95);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_47.setTransform(-25.8361,-77.875);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_48.setTransform(-45.825,-73.7768);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#493728").s().p("AgTAeQgMgJgDgOQgDgOAIgLQAJgNAOgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgJAAgKgGg");
	this.shape_49.setTransform(-65.8,-69.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_50.setTransform(-85.775,-65.6232);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_51.setTransform(-105.75,-61.525);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgJAAgKgGg");
	this.shape_52.setTransform(-125.725,-57.4361);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgNAPgCQANgDANAIQAMAIADAPQADAOgIAMQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_53.setTransform(-145.7,-53.35);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgKQAHgLAMgCQALgDAKAHQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_54.setTransform(-165.6732,-49.2732);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_55.setTransform(189.775,-143.025);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#493728").s().p("AgTAeQgMgJgDgOQgDgOAIgMQAJgMAOgDQANgDAMAIQANAJADAOQADANgIANQgJAMgOADIgHABQgKAAgJgGg");
	this.shape_56.setTransform(169.8,-138.95);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgEgQAKgOQAKgOARgEQAQgDAOAJQAOAKAEARQAEAPgKAPQgKAPgRADIgIABQgMAAgKgHg");
	this.shape_57.setTransform(149.81,-134.85);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#493728").s().p("AgWAjQgPgJgDgRQgDgQAJgPQAJgOARgEQAQgEAPAKQAOAKAEARQADAQgJAOQgKAOgRAEIgIABQgLAAgLgHg");
	this.shape_58.setTransform(129.85,-130.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#493728").s().p("AgWAjQgPgJgDgSQgDgQAJgOQAJgOARgEQARgEAOAKQAPAKADAQQADARgJAOQgJAPgRADIgJABQgLAAgLgHg");
	this.shape_59.setTransform(109.85,-126.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#493728").s().p("AgWAjQgPgJgDgRQgEgQAKgPQAKgPAQgDQARgDAOAJQAOAJAEARQAEAQgKAPQgKAPgRADIgIABQgLAAgLgHg");
	this.shape_60.setTransform(89.9,-122.6);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#493728").s().p("AgWAjQgPgKgDgRQgDgQAJgOQAJgOARgEQARgDAOAJQAPAKADARQADAQgJAOQgJAPgSADIgIABQgLAAgLgHg");
	this.shape_61.setTransform(69.9,-118.5017);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgEgQAKgOQAKgOAQgEQARgEAOAKQAPAJADASQADAQgJAOQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_62.setTransform(49.95,-114.45);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#493728").s().p("AgWAjQgPgJgDgSQgDgPAJgPQAJgPARgDQARgDAOAJQAOAJAEARQADAQgJAPQgKAPgRADIgIABQgLAAgLgHg");
	this.shape_63.setTransform(29.95,-110.35);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgEgQAKgOQAJgPASgDQAPgDAPAJQAOAJAEASQAEAQgKAOQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_64.setTransform(10,-106.25);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#493728").s().p("AgWAjQgPgKgDgRQgEgQAKgOQAKgOAQgEQARgEAOAKQAOAKAEARQAEAQgKAOQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_65.setTransform(-10,-102.19);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgEgPAKgPQAKgPARgDQAQgDAOAJQAPAJADARQAEARgKAOQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_66.setTransform(-29.975,-98.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#493728").s().p("AgWAjQgOgKgEgQQgEgRAKgOQAKgOAQgEQARgEAOAKQAPAKADARQADAQgJAOQgJAPgSADIgIABQgLAAgLgHg");
	this.shape_67.setTransform(-49.95,-94);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgEgQAKgOQAKgOARgEQAQgDAOAJQAOAKAEARQAEAQgKAOQgJAPgSADIgIABQgLAAgLgHg");
	this.shape_68.setTransform(-69.9379,-89.9017);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgEgQAKgOQAJgOASgEQAPgEAPAKQAOAKAEAQQAEARgKAOQgJAOgSAEIgIABQgLAAgLgHg");
	this.shape_69.setTransform(-89.9,-85.85);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#493728").s().p("AgWAjQgOgKgEgQQgEgRAKgOQAKgOARgEQAQgDAOAJQAOAKAEARQAEAPgKAPQgKAPgRADIgIABQgMAAgKgHg");
	this.shape_70.setTransform(-109.89,-81.75);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#493728").s().p("AgWAjQgPgKgDgRQgEgQAKgOQAJgOASgEQAQgEAOAKQAOAKAEAQQAEARgKAOQgKAOgQAEIgJABQgMAAgKgHg");
	this.shape_71.setTransform(-129.85,-77.65);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_72.setTransform(-149.8361,-73.575);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgLQAHgKAMgDQALgCALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_73.setTransform(-169.8232,-69.4906);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgCgLAGgKQAHgLAMgCQALgDALAHQAKAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_74.setTransform(185.6362,-163.2732);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#493728").s().p("AgSAeQgNgIgDgPQgDgNAIgNQAJgMAOgDQAOgDAMAIQAMAIADAPQADANgIANQgIAMgOADIgIABQgJAAgJgGg");
	this.shape_75.setTransform(165.65,-159.1768);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#493728").s().p("AgWAjQgPgJgDgRQgEgQAKgPQAKgOAQgEQARgDAOAJQAOAKAEARQADAQgJAOQgKAPgRADIgIABQgMAAgKgHg");
	this.shape_76.setTransform(145.7,-155.1);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#493728").s().p("AgaAoQgQgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEAUQAEASgLAQQgLARgUAEIgJABQgOAAgMgIg");
	this.shape_77.setTransform(125.7096,-151.0232);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_78.setTransform(105.725,-146.925);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#493728").s().p("AgaAoQgQgLgEgUQgEgSALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgNgIg");
	this.shape_79.setTransform(85.75,-142.8404);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgRQALgQATgEQATgEAQALQARALAEATQAEASgLARQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_80.setTransform(65.7732,-138.7404);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#493728").s().p("AgaAoQgQgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgNgIg");
	this.shape_81.setTransform(45.8,-134.675);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgMgIg");
	this.shape_82.setTransform(25.8232,-130.5768);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#493728").s().p("AgaAoQgQgLgEgTQgEgTALgQQALgRATgEQASgEARALQARALAEAUQAEASgLARQgLAQgUAEIgJABQgNAAgNgIg");
	this.shape_83.setTransform(5.8596,-126.5);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgMgIg");
	this.shape_84.setTransform(-14.1268,-122.4232);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRAUgEQASgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_85.setTransform(-34.1232,-118.3268);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgRQALgQATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgMgIg");
	this.shape_86.setTransform(-54.0904,-114.2404);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgRQALgQAUgEQASgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_87.setTransform(-74.0732,-110.15);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#493728").s().p("AgaAoQgQgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgNgIg");
	this.shape_88.setTransform(-94.05,-106.075);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_89.setTransform(-114.025,-101.9768);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgEgQAKgOQAJgOASgEQAQgEAOAKQAOAKAEAQQAEARgKAOQgJAPgSADIgIABQgLAAgLgHg");
	this.shape_90.setTransform(-134,-97.9);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_91.setTransform(-153.975,-93.825);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_92.setTransform(-173.9406,-89.725);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgLQAHgKAMgDQALgCAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_93.setTransform(181.5094,-183.4906);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_94.setTransform(161.525,-179.4232);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#493728").s().p("AgWAjQgPgJgDgSQgEgQAKgOQAJgOARgEQAQgEAPAKQAOAKAEARQADAQgJAOQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_95.setTransform(141.55,-175.3379);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgMgIg");
	this.shape_96.setTransform(121.5732,-171.2404);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASANAFAVQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_97.setTransform(101.5768,-167.1636);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_98.setTransform(81.6232,-163.075);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_99.setTransform(61.625,-158.975);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgSQAMgTAWgFQAVgEATAMQASAMAFAWQAEAVgMASQgMATgWAFIgLABQgPAAgOgJg");
	this.shape_100.setTransform(41.6636,-154.9);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_101.setTransform(21.675,-150.825);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAWgEASAMQASANAEAVQAFAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_102.setTransform(1.7,-146.725);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#493728").s().p("AgdAtQgSgNgFgVQgEgVAMgSQAMgTAWgFQAVgEATAMQASAMAFAWQAEAWgMASQgMASgWAEIgLACQgPAAgOgJg");
	this.shape_103.setTransform(-18.275,-142.65);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#493728").s().p("AgdAtQgSgMgEgWQgFgVAMgTQAMgSAWgFQAVgEATAMQATANADAVQAFAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_104.setTransform(-38.25,-138.5636);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_105.setTransform(-58.225,-134.475);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQANgSAVgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_106.setTransform(-78.2136,-130.3768);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#493728").s().p("AgdAtQgSgMgFgXQgEgUAMgTQANgSAVgFQAVgEATAMQASANAFAVQAEAVgMASQgMATgWAFIgLABQgPAAgOgJg");
	this.shape_107.setTransform(-98.175,-126.3);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#493728").s().p("AgaAoQgQgLgEgTQgEgTALgQQALgRATgEQASgEARALQARALAEATQAEATgLAQQgLARgUAEIgJABQgOAAgMgIg");
	this.shape_108.setTransform(-118.1404,-122.2232);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgEgQAKgOQAKgOARgEQAQgEAPAKQANAKAEARQADAQgJAOQgJAOgSAEIgIABQgLAAgLgHg");
	this.shape_109.setTransform(-138.15,-118.15);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#493728").s().p("AgTAeQgMgJgDgOQgDgNAIgMQAJgNAOgDQANgDANAIQAMAJADAOQADANgIAMQgJANgOADIgHABQgKAAgJgGg");
	this.shape_110.setTransform(-158.1,-114.05);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgKQAHgLAMgCQALgCAKAGQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_111.setTransform(-178.0768,-109.9638);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_112.setTransform(177.3732,-203.725);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#493728").s().p("AgTAeQgMgJgDgOQgDgNAIgMQAIgNAPgDQANgDANAIQAMAIADAPQADAOgIALQgIANgPADIgHABQgKAAgJgGg");
	this.shape_113.setTransform(157.375,-199.65);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#493728").s().p("AgWAjQgPgJgDgSQgDgQAJgOQAJgOARgEQARgEAOAKQAPAKADAQQADARgJAOQgJAOgSAEIgIABQgLAAgLgHg");
	this.shape_114.setTransform(137.4,-195.55);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_115.setTransform(117.4268,-191.475);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#493728").s().p("AgcAtQgUgMgEgWQgEgVAMgTQANgSAVgFQAVgEASAMQATAMAEAWQAFAVgMATQgNASgVAFIgLABQgPAAgNgJg");
	this.shape_116.setTransform(97.45,-187.3768);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#493728").s().p("AggAyQgVgNgFgZQgFgXAOgVQAOgVAYgFQAXgEAVANQAUANAGAZQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_117.setTransform(77.475,-183.3);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgGgXAOgVQAOgUAYgGQAYgFAUAOQAUAOAGAYQAEAXgNAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_118.setTransform(57.5,-179.225);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgXAOgVQAOgVAYgFQAXgFAVAOQAUAOAGAYQAFAXgOAVQgOAUgYAFQgHACgGAAQgQAAgPgKg");
	this.shape_119.setTransform(37.525,-175.1382);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgYANgUQANgVAZgFQAXgFAVAOQAVAOAFAYQAEAXgNAVQgOAUgYAFIgMACQgRAAgPgKg");
	this.shape_120.setTransform(17.55,-171.0482);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgUAYgFQAXgFAVANQAUAOAFAYQAGAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_121.setTransform(-2.4382,-166.9518);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgVAYgFQAYgFAUAOQAVAOAFAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_122.setTransform(-22.4018,-162.875);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgVAYgFQAXgFAVAOQAUAOAFAYQAGAXgOAVQgOAUgYAFQgHACgFAAQgRAAgPgKg");
	this.shape_123.setTransform(-42.3882,-158.7882);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgUAYgFQAXgGAVAOQAVAOAFAYQAFAYgOAUQgOAUgYAGIgMABQgRAAgPgKg");
	this.shape_124.setTransform(-62.3518,-154.7);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQANgUAZgGQAXgFAVAOQAVAOAFAYQAEAXgNAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_125.setTransform(-82.35,-150.625);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_126.setTransform(-102.325,-146.5268);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgRQALgQATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgMgIg");
	this.shape_127.setTransform(-122.2904,-142.4404);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgEgQAKgOQAKgPARgDQAPgDAPAJQAPAJADARQADAQgJAPQgKAPgRADIgIABQgMAAgKgHg");
	this.shape_128.setTransform(-142.25,-138.35);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgJAAgKgGg");
	this.shape_129.setTransform(-162.25,-134.2768);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_130.setTransform(-182.2232,-130.1768);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgKQAHgLAMgCQALgCAKAGQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_131.setTransform(173.225,-223.9638);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAJgMAOgDQANgDAMAIQANAIADAPQADANgIANQgJAMgOADIgHABQgKAAgJgGg");
	this.shape_132.setTransform(153.25,-219.875);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgDgQAJgOQAKgOARgEQAQgEAPAKQAOAKADAQQADARgJAOQgJAOgRAEIgJABQgLAAgLgHg");
	this.shape_133.setTransform(133.25,-215.8);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#493728").s().p("AgaAoQgQgLgEgUQgEgSALgQQALgRATgEQASgEARALQARALAEAUQAEASgLARQgLAQgUAEIgJABQgNAAgNgIg");
	this.shape_134.setTransform(113.3096,-211.7);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_135.setTransform(93.3232,-207.625);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgVAYgFQAYgFAUAOQAVAOAFAYQAFAXgOAVQgOAUgYAFQgHACgFAAQgRAAgPgKg");
	this.shape_136.setTransform(73.3482,-203.5382);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#493728").s().p("AggAyQgVgNgFgZQgFgYAOgUQAOgVAYgEQAXgGAVAOQAUANAFAZQAGAYgOAUQgOAUgYAGIgMABQgRAAgPgKg");
	this.shape_137.setTransform(53.3618,-199.45);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgUAYgFQAXgFAVANQAVAOAFAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_138.setTransform(33.3982,-195.3518);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgGgXAOgVQAOgUAYgGQAYgFAUAOQAUAOAGAYQAEAXgNAVQgOAUgYAFQgHACgGAAQgQAAgPgKg");
	this.shape_139.setTransform(13.4,-191.2882);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#493728").s().p("AggAyQgUgNgGgZQgFgXAOgVQAOgVAYgEQAXgGAVAOQAVANAFAZQAFAYgOAUQgOAUgYAGIgMABQgRAAgPgKg");
	this.shape_140.setTransform(-6.575,-187.2);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgGgXAOgVQANgUAZgFQAXgFAVANQAVAOAFAYQAEAYgNAUQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_141.setTransform(-26.55,-183.1018);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgXAOgVQAOgUAYgGQAXgFAVAOQAVAOAFAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_142.setTransform(-46.525,-179.025);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgEgYANgUQANgVAZgFQAXgFAVAOQAVAOAFAYQAEAXgNAVQgNAUgZAFQgHACgFAAQgRAAgPgKg");
	this.shape_143.setTransform(-66.5,-174.9382);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgYAOgUQAOgUAYgGQAXgEAVANQAVANAFAZQAFAXgOAVQgOAVgYAEIgMACQgRAAgPgKg");
	this.shape_144.setTransform(-86.475,-170.85);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQANgSAVgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_145.setTransform(-106.4636,-166.775);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_146.setTransform(-126.4268,-162.6768);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#493728").s().p("AgWAjQgOgJgEgRQgEgQAKgPQAKgPARgDQAQgDAOAJQAPAJADARQAEARgKAOQgKAPgQADIgJABQgLAAgLgHg");
	this.shape_147.setTransform(-146.4,-158.6);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_148.setTransform(-166.3768,-154.5232);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgCgLAGgKQAHgLAMgCQALgDALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_149.setTransform(-186.3638,-150.425);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgLQAHgKAMgCQALgDALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_150.setTransform(169.0768,-244.1768);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#493728").s().p("AgSAeQgNgIgDgPQgDgNAIgNQAJgNAOgCQAOgDAMAIQAMAIADAPQADAOgIAMQgIAMgOADIgIABQgJAAgJgGg");
	this.shape_151.setTransform(149.1,-240.1);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgEgQAKgOQAKgOAQgEQARgDAOAJQAOAKAEARQADAQgJAOQgKAOgRAEIgJABQgLAAgKgHg");
	this.shape_152.setTransform(129.15,-236.0129);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#493728").s().p("AgaAoQgQgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgNgIg");
	this.shape_153.setTransform(109.15,-231.9268);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgEQAVgFATAMQASAMAFAWQAEAVgMATQgMASgWAEIgLACQgPAAgOgJg");
	this.shape_154.setTransform(89.175,-227.85);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgGgXAOgVQAOgUAYgFQAYgFAUANQAUAOAGAYQAEAXgNAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_155.setTransform(69.2,-223.7518);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgXAOgVQAOgVAYgFQAXgFAVAOQAVAOAFAYQAFAXgOAVQgOAUgYAFQgHACgGAAQgQAAgPgKg");
	this.shape_156.setTransform(49.225,-219.6882);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#493728").s().p("AggAyQgUgNgFgZQgFgXANgVQANgVAZgFQAXgEAVANQAUAOAGAYQAEAXgNAVQgOAUgYAFIgMACQgRAAgPgKg");
	this.shape_157.setTransform(29.25,-215.6);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgUAYgFQAXgFAVANQAUAOAGAYQAFAYgOAUQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_158.setTransform(9.275,-211.5018);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgUAYgGQAYgFAUAOQAVAOAFAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_159.setTransform(-10.7018,-207.425);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgVAYgFQAXgFAVAOQAUAOAFAYQAGAXgOAVQgOAUgYAFQgHACgFAAQgRAAgPgKg");
	this.shape_160.setTransform(-30.6882,-203.3382);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgUAYgFQAYgGAUAOQAVAOAFAYQAFAYgOAUQgOAUgYAGIgMABQgRAAgPgKg");
	this.shape_161.setTransform(-50.6518,-199.25);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgUAYgGQAXgFAVAOQAUAOAFAYQAGAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_162.setTransform(-70.6382,-195.175);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgVAYgFQAXgFAVAOQAVAOAFAYQAFAXgOAVQgOAUgYAFQgHACgFAAQgRAAgPgKg");
	this.shape_163.setTransform(-90.6018,-191.0882);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgEQAVgFATAMQASANAFAVQAEAWgMASQgMATgWADIgLACQgPAAgOgJg");
	this.shape_164.setTransform(-110.5768,-187);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEAUQAEASgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_165.setTransform(-130.5732,-182.9232);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#493728").s().p("AgWAjQgPgKgDgRQgDgQAJgOQAJgOASgEQAQgEAOAKQAOAKAEARQAEAQgKAOQgKAOgQAEIgJABQgMAAgKgHg");
	this.shape_166.setTransform(-150.55,-178.8379);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_167.setTransform(-170.525,-174.75);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgKQAHgLAMgCQALgDAKAHQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_168.setTransform(-190.4906,-170.6732);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgKQAHgLAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_169.setTransform(164.9594,-264.4232);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgJAAgKgGg");
	this.shape_170.setTransform(144.975,-260.3361);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#493728").s().p("AgWAjQgPgJgDgRQgEgQAKgPQAKgPAQgDQARgDAOAJQAOAJAEASQAEAPgKAPQgKAPgRADIgIABQgLAAgLgHg");
	this.shape_171.setTransform(125,-256.25);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgMgIg");
	this.shape_172.setTransform(105.0232,-252.1732);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_173.setTransform(85.0268,-248.075);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#493728").s().p("AggAyQgVgNgFgZQgFgYAOgUQAOgVAYgEQAXgGAVAOQAUANAFAZQAGAYgOAUQgOAUgYAGIgMABQgRAAgPgKg");
	this.shape_174.setTransform(65.0618,-244);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgUAYgFQAXgFAVANQAVAOAFAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_175.setTransform(45.0982,-239.9018);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgGgXAOgVQAOgUAYgGQAYgFAUAOQAUAOAGAYQAEAXgNAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_176.setTransform(25.1,-235.825);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgYANgUQAOgVAYgFQAXgFAVAOQAVAOAFAYQAFAXgOAVQgOAUgYAFQgHACgFAAQgRAAgPgKg");
	this.shape_177.setTransform(5.1482,-231.7382);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgYANgUQANgUAZgGQAXgEAVANQAVAOAFAYQAEAXgNAVQgOAUgYAFIgMACQgRAAgPgKg");
	this.shape_178.setTransform(-14.85,-227.65);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgXAOgVQAOgUAYgGQAXgFAVAOQAVAOAFAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_179.setTransform(-34.825,-223.575);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgEgXANgVQAOgVAYgFQAXgFAVAOQAVAOAEAYQAFAXgNAVQgNAUgZAFQgHACgFAAQgRAAgPgKg");
	this.shape_180.setTransform(-54.8,-219.4882);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgYAOgUQAOgUAYgGQAXgEAVANQAVANAFAZQAFAXgOAVQgOAVgYAEIgMACQgRAAgPgKg");
	this.shape_181.setTransform(-74.775,-215.4);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgEgXANgVQAOgUAYgFQAXgFAVANQAUAOAFAYQAFAXgNAVQgNAVgZAFIgMABQgRAAgPgKg");
	this.shape_182.setTransform(-94.75,-211.3018);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_183.setTransform(-114.725,-207.225);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#493728").s().p("AgaAoQgQgLgEgUQgEgSALgRQALgQATgEQASgEARALQARALAEAUQAEASgLARQgLAQgUAEIgJABQgNAAgNgIg");
	this.shape_184.setTransform(-134.6904,-203.15);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgEgQAKgOQAKgOARgEQAQgEAOAKQAOAJAEASQAEAPgKAPQgKAOgRAEIgIABQgLAAgLgHg");
	this.shape_185.setTransform(-154.69,-199.05);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAOgDQAOgDAMAIQANAIADAPQADANgIANQgJAMgOADIgHABQgKAAgJgGg");
	this.shape_186.setTransform(-174.65,-194.975);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_187.setTransform(-194.6268,-190.8768);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgKQAHgLAMgCQALgCAKAGQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_188.setTransform(160.8232,-284.6638);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_189.setTransform(140.825,-280.575);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#493728").s().p("AgWAjQgPgKgDgRQgDgQAJgOQAJgOARgEQARgEAOAKQAOAKAEARQADAQgJAOQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_190.setTransform(120.85,-276.49);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_191.setTransform(100.875,-272.4);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#493728").s().p("AgcAtQgTgMgFgWQgEgVAMgTQANgSAVgFQAVgEATAMQASAMAEAWQAFAVgMATQgMASgWAFIgLABQgPAAgNgJg");
	this.shape_192.setTransform(80.9,-268.325);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgXAOgVQAOgUAYgGQAXgFAVAOQAUAOAGAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_193.setTransform(60.925,-264.225);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#493728").s().p("AggAyQgUgNgFgZQgGgXAOgVQANgVAZgFQAXgEAVANQAVAOAFAYQAEAYgNAUQgOAUgYAFIgMACQgRAAgPgKg");
	this.shape_194.setTransform(40.95,-260.15);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgUAYgFQAXgFAVANQAUAOAGAYQAFAYgOAUQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_195.setTransform(20.975,-256.0518);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgUAYgGQAYgFAUAOQAVAOAFAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_196.setTransform(0.9982,-251.975);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgYAOgUQAOgVAYgFQAXgFAVAOQAUAOAFAYQAGAXgOAVQgOAUgYAFQgHACgFAAQgRAAgPgKg");
	this.shape_197.setTransform(-18.9882,-247.8882);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgUAYgFQAYgGAUAOQAVAOAFAYQAFAYgOAUQgOAUgYAGIgMABQgRAAgPgKg");
	this.shape_198.setTransform(-38.9518,-243.8);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgUAYgFQAXgFAVANQAUAOAFAYQAGAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_199.setTransform(-58.9382,-239.7018);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgVAYgFQAXgFAVAOQAVAOAFAYQAFAXgOAVQgOAUgYAGIgMABQgRAAgPgKg");
	this.shape_200.setTransform(-78.9018,-235.625);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgUAYgFQAXgFAVANQAUANAFAZQAGAXgOAVQgOAUgYAGIgMABQgRAAgPgKg");
	this.shape_201.setTransform(-98.8882,-231.55);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_202.setTransform(-118.875,-227.4732);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRAUgEQASgEARALQAQALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_203.setTransform(-138.85,-223.375);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#493728").s().p("AgWAjQgPgJgDgSQgDgPAJgPQAJgOARgEQAQgEAPAKQAPAJADASQADAQgJAOQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_204.setTransform(-158.8,-219.3);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#493728").s().p("AgSAeQgNgJgDgOQgDgOAIgMQAJgMAOgDQAOgDAMAIQAMAJADAOQADANgIAMQgJANgOADIgHABQgKAAgIgGg");
	this.shape_205.setTransform(-178.8,-215.2);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgKQAHgLAMgCQALgDAKAHQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_206.setTransform(-198.7732,-211.1232);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_207.setTransform(156.675,-304.8768);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#493728").s().p("AgTAeQgMgJgDgOQgDgNAIgMQAJgNAOgDQAOgDALAIQANAJADAOQADANgIAMQgJANgOADIgHABQgKAAgJgGg");
	this.shape_208.setTransform(136.7,-300.8);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgDgQAJgOQAKgOARgEQAQgEAPAKQAOAJADASQADAPgJAPQgJAOgRAEIgJABQgLAAgLgHg");
	this.shape_209.setTransform(116.7,-296.7);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#493728").s().p("AgaAoQgQgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgNgIg");
	this.shape_210.setTransform(96.75,-292.6268);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#493728").s().p("AgdAtQgSgNgFgVQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_211.setTransform(76.775,-288.5364);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgUAYgFQAYgFAUANQAVAOAFAYQAFAYgOAUQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_212.setTransform(56.7982,-284.4518);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgUAYgGQAXgFAVAOQAUAOAFAYQAGAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_213.setTransform(36.8118,-280.375);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgYANgUQAOgVAYgFQAXgFAVAOQAVAOAFAYQAFAXgOAVQgOAUgYAFQgHACgFAAQgRAAgPgKg");
	this.shape_214.setTransform(16.8482,-276.2882);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgGgYAOgUQANgUAZgGQAXgEAVANQAVAOAFAYQAEAXgNAVQgOAUgYAFIgMACQgRAAgPgKg");
	this.shape_215.setTransform(-3.15,-272.2);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgXAOgVQAOgUAYgFQAXgFAVANQAVAOAFAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_216.setTransform(-23.125,-268.1018);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgEgXANgVQAOgVAYgFQAXgFAVAOQAVAOAEAYQAFAXgNAVQgNAUgZAFQgHACgFAAQgRAAgPgKg");
	this.shape_217.setTransform(-43.1,-264.0382);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgYAOgUQAOgUAYgGQAXgEAVANQAVANAFAZQAFAXgOAVQgOAUgYAFIgMACQgRAAgPgKg");
	this.shape_218.setTransform(-63.075,-259.95);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgEgXANgVQAOgUAYgFQAXgFAVANQAUAOAFAYQAFAYgNAUQgNAVgZAFIgMABQgRAAgPgKg");
	this.shape_219.setTransform(-83.05,-255.8518);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgXAOgVQAOgUAYgGQAXgFAVAOQAVAOAFAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_220.setTransform(-103.025,-251.775);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQANgSAVgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_221.setTransform(-123.0136,-247.6768);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgRQALgQATgEQATgEAQALQARALAEATQAEASgLARQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_222.setTransform(-142.9768,-243.5904);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgDgQAJgOQAKgPARgDQAPgDAPAJQAPAJADARQADAQgJAPQgJAPgRADIgJABQgMAAgKgHg");
	this.shape_223.setTransform(-162.95,-239.5);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgJAAgKgGg");
	this.shape_224.setTransform(-182.925,-235.4361);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgLQAHgKAMgDQALgCALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_225.setTransform(-202.9232,-231.3406);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgKQAHgLAMgCQALgDALAHQAKAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_226.setTransform(152.5268,-325.1232);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAJgMAOgDQANgDANAIQAMAIADAPQADANgIANQgJAMgOADIgHABQgKAAgJgGg");
	this.shape_227.setTransform(132.55,-321.025);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgEgQAKgOQAJgOASgEQAPgEAPAKQAOAJAEASQAEAQgKAOQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_228.setTransform(112.6,-316.95);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#493728").s().p("AgaAoQgQgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEAUQAEASgLAQQgLARgUAEIgJABQgOAAgMgIg");
	this.shape_229.setTransform(92.6096,-312.8732);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_230.setTransform(72.625,-308.775);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgYANgUQANgVAZgFQAXgFAVAOQAVAOAFAYQAEAXgNAVQgOAUgYAFIgMACQgRAAgPgKg");
	this.shape_231.setTransform(52.65,-304.6982);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgXAOgVQAOgUAYgFQAXgFAVANQAVAOAFAYQAFAYgOAUQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_232.setTransform(32.675,-300.6018);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgEgXANgVQANgUAZgGQAXgFAVAOQAVAOAEAYQAFAXgNAVQgNAVgZAFIgMABQgRAAgPgKg");
	this.shape_233.setTransform(12.7,-296.525);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgVAYgFQAXgFAVAOQAUAOAFAYQAGAXgOAVQgOAUgYAFQgHACgFAAQgRAAgPgKg");
	this.shape_234.setTransform(-7.2882,-292.4382);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgEgXANgVQAOgUAYgFQAXgGAVAOQAUAOAFAYQAFAYgNAUQgNAUgZAGIgMABQgRAAgPgKg");
	this.shape_235.setTransform(-27.25,-288.35);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgUAYgFQAXgFAVANQAUAOAFAYQAGAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_236.setTransform(-47.2382,-284.2518);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgUAYgGQAYgFAUAOQAVAOAFAYQAFAXgOAVQgOAUgYAFQgHACgFAAQgRAAgPgKg");
	this.shape_237.setTransform(-67.2018,-280.1882);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgYAOgUQAOgVAYgFQAXgFAVAOQAUAOAFAYQAGAXgOAVQgOAUgYAFIgMACQgRAAgPgKg");
	this.shape_238.setTransform(-87.1882,-276.0982);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgUAYgFQAXgFAVANQAVAOAFAYQAFAYgOAUQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_239.setTransform(-107.1518,-272.0018);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgNASgVAFIgLABQgPAAgOgJg");
	this.shape_240.setTransform(-127.1364,-267.925);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgQQALgRAUgEQASgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_241.setTransform(-147.1232,-263.8268);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgEgPAKgPQAKgPARgDQAQgDAOAJQAPAJADARQAEAQgKAPQgKAPgQADIgJABQgLAAgLgHg");
	this.shape_242.setTransform(-167.1,-259.75);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_243.setTransform(-187.075,-255.675);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_244.setTransform(-207.0406,-251.575);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgLQAHgKAMgDQALgCAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_245.setTransform(148.4094,-345.3406);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAJADAOQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_246.setTransform(128.425,-341.2638);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgEgPAKgPQAKgOAQgEQARgEAOAKQAPAKADARQADAQgJAOQgJAOgSAEIgIABQgLAAgLgHg");
	this.shape_247.setTransform(108.45,-337.2);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_248.setTransform(88.4732,-333.0904);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASANAFAVQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_249.setTransform(68.4768,-329.0136);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgUAYgGQAXgFAVAOQAUAOAFAYQAGAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_250.setTransform(48.5118,-324.925);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgYANgUQAOgVAYgFQAXgFAVAOQAVAOAFAYQAFAXgOAVQgOAUgYAFQgHACgFAAQgRAAgPgKg");
	this.shape_251.setTransform(28.5482,-320.8382);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgYANgUQANgUAZgGQAXgEAVANQAVAOAFAYQAEAXgNAVQgOAUgYAFIgMACQgRAAgPgKg");
	this.shape_252.setTransform(8.55,-316.75);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#493728").s().p("AggAyQgUgOgFgYQgFgXANgVQAOgUAYgFQAXgFAVANQAVAOAFAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_253.setTransform(-11.4018,-312.6518);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgFgXAOgVQAOgVAYgFQAXgFAVAOQAUAOAFAYQAFAXgNAVQgOAUgYAFQgHACgGAAQgQAAgPgKg");
	this.shape_254.setTransform(-31.3982,-308.5882);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgYAOgUQAOgUAYgGQAXgEAVANQAVANAFAZQAFAXgOAVQgOAVgYAEIgMACQgRAAgPgKg");
	this.shape_255.setTransform(-51.375,-304.5);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#493728").s().p("AggAyQgVgOgFgYQgEgXANgVQAOgUAYgFQAYgFAUANQAUAOAFAYQAFAYgNAUQgNAVgZAFIgMABQgRAAgPgKg");
	this.shape_256.setTransform(-71.35,-300.4018);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgFgXAOgVQAOgUAYgGQAXgFAVAOQAVAOAFAYQAFAXgOAVQgOAVgYAFIgMABQgRAAgPgKg");
	this.shape_257.setTransform(-91.325,-296.325);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#493728").s().p("AggAyQgUgOgGgYQgEgYANgUQAOgVAYgFQAXgFAVAOQAUAOAFAYQAGAXgOAVQgOAUgYAFQgHACgGAAQgQAAgPgKg");
	this.shape_258.setTransform(-111.3,-292.2382);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#493728").s().p("AgdAtQgSgNgFgVQgEgVAMgTQANgTAVgDQAVgFATAMQASAMAFAWQAEAVgMATQgMASgWAEIgLACQgPAAgOgJg");
	this.shape_259.setTransform(-131.275,-288.15);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRAUgEQARgEASALQAQALAEATQAEATgLAQQgLARgTAEIgKABQgOAAgLgIg");
	this.shape_260.setTransform(-151.25,-284.0732);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgDgPAJgPQAKgOARgEQAQgDAOAJQAOAKAEARQAEAQgKAPQgKAOgQADIgJABQgLAAgLgHg");
	this.shape_261.setTransform(-171.25,-280);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#493728").s().p("AgTAeQgNgIgCgPQgDgNAIgNQAJgMANgDQAOgDAMAIQANAIADAPQADANgIANQgJAMgOADIgHABQgKAAgJgGg");
	this.shape_262.setTransform(-191.2,-275.9);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgKQAHgLAMgCQALgCAKAGQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_263.setTransform(-211.1768,-271.8138);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_264.setTransform(144.2732,-365.575);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_265.setTransform(124.275,-361.5);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#493728").s().p("AgWAjQgPgJgDgSQgEgPAKgPQAKgPAQgDQARgDAOAJQAOAJAEARQAEAQgKAPQgKAPgRADIgIABQgLAAgLgHg");
	this.shape_266.setTransform(104.3,-357.4);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_267.setTransform(84.325,-353.325);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#493728").s().p("AgdAtQgSgMgEgWQgFgVAMgTQAMgSAWgFQAVgEATAMQATAMADAWQAFAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_268.setTransform(64.35,-349.2268);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#493728").s().p("AgdAtQgSgMgFgXQgEgUAMgTQANgSAVgFQAVgEATAMQASANAFAVQAEAVgMASQgMATgWAFIgLABQgPAAgOgJg");
	this.shape_269.setTransform(44.375,-345.15);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#493728").s().p("AgdAtQgTgMgDgWQgFgVAMgTQAMgSAWgFQAVgEATAMQASAMAEAWQAFAVgMATQgNASgVAFIgLABQgPAAgOgJg");
	this.shape_270.setTransform(24.4,-341.075);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_271.setTransform(4.425,-336.975);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgSQANgTAVgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAEIgLACQgPAAgOgJg");
	this.shape_272.setTransform(-15.5636,-332.9);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_273.setTransform(-35.525,-328.8232);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_274.setTransform(-55.5232,-324.725);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#493728").s().p("AgdAtQgSgNgFgVQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_275.setTransform(-75.4768,-320.6364);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASANAFAVQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_276.setTransform(-95.4732,-316.5636);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_277.setTransform(-115.4268,-312.475);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#493728").s().p("AgdAtQgSgMgFgWQgEgVAMgTQAMgSAWgFQAVgEATAMQASAMAFAWQAEAVgMATQgMASgWAFIgLABQgPAAgOgJg");
	this.shape_278.setTransform(-135.425,-308.375);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgRQALgQATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgMgIg");
	this.shape_279.setTransform(-155.3904,-304.2904);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#493728").s().p("AgWAjQgPgKgDgRQgDgQAJgOQAJgPARgDQAQgDAPAJQAOAJAEASQADAQgJAOQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_280.setTransform(-175.35,-300.2);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#493728").s().p("AgSAeQgNgIgDgPQgDgNAIgNQAIgMAPgDQAOgDAMAIQAMAIADAPQADANgIANQgJAMgOADIgHABQgKAAgIgGg");
	this.shape_281.setTransform(-195.35,-296.125);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_282.setTransform(-215.3232,-292.0268);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgKQAHgLAMgCQALgCAKAGQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_283.setTransform(140.125,-385.8138);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_284.setTransform(120.15,-381.725);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgDgPAJgPQAKgPARgDQAQgDAPAJQAOAJADARQADAQgJAPQgKAPgRADIgIABQgLAAgLgHg");
	this.shape_285.setTransform(100.15,-377.65);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#493728").s().p("AgaAoQgQgLgEgTQgEgTALgQQALgRATgEQASgEARALQARALAEAUQAEARgLASQgLAQgUAEIgJABQgNAAgNgIg");
	this.shape_286.setTransform(80.2096,-373.55);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgMgIg");
	this.shape_287.setTransform(60.2232,-369.4732);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgQQALgRAUgEQASgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_288.setTransform(40.2268,-365.3768);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgRQALgQATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgNAAgMgIg");
	this.shape_289.setTransform(20.2732,-361.2904);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEAUQAEASgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_290.setTransform(0.2768,-357.2232);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_291.setTransform(-19.7,-353.1268);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEAUQAEASgLARQgLAQgTAEIgKABQgNAAgMgIg");
	this.shape_292.setTransform(-39.675,-349.05);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#493728").s().p("AgaAoQgQgLgEgTQgEgTALgQQALgRATgEQATgDAQAKQARALAEAUQAEASgLAQQgLARgUAEIgJABQgOAAgMgIg");
	this.shape_293.setTransform(-59.6404,-344.9636);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_294.setTransform(-79.625,-340.875);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgQQALgRAUgEQASgEARALQAQALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_295.setTransform(-99.6,-336.7768);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#493728").s().p("AgZAoQgRgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_296.setTransform(-119.575,-332.7);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#493728").s().p("AgaAoQgQgLgEgTQgEgTALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgUAEIgJABQgOAAgMgIg");
	this.shape_297.setTransform(-139.5404,-328.6232);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#493728").s().p("AgZAoQgRgLgEgUQgEgSALgQQALgRATgEQATgEAQALQARALAEATQAEATgLAQQgLARgTAEIgKABQgNAAgMgIg");
	this.shape_298.setTransform(-159.5268,-324.5268);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#493728").s().p("AgWAjQgPgKgDgQQgDgRAJgOQAJgPASgDQAPgDAPAJQAPAJADASQADAQgJAOQgJAOgRAEIgJABQgLAAgLgHg");
	this.shape_299.setTransform(-179.5,-320.45);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgOAIgMQAIgMAPgDQANgDANAIQAMAIADAOQADAOgIAMQgIANgPADIgHABQgKAAgJgGg");
	this.shape_300.setTransform(-199.475,-316.35);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgCgLAGgKQAHgLAMgCQALgDALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_301.setTransform(-219.4638,-312.2732);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgLQAHgKAMgCQALgDALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_302.setTransform(135.9768,-406.0268);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#493728").s().p("AgTAeQgMgJgDgOQgDgOAIgMQAJgMAOgDQANgDANAIQAMAIADAOQADAOgIAMQgIANgPADIgHABQgJAAgKgGg");
	this.shape_303.setTransform(116,-401.95);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#493728").s().p("AgWAjQgPgKgDgRQgEgQAKgOQAJgPASgDQAQgDAOAJQAOAJAEASQAEAQgKAOQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_304.setTransform(96.05,-397.85);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgEgQAKgOQAKgOAQgEQARgEAOAKQAPAJADARQADARgJAOQgJAOgSAEIgIABQgMAAgKgHg");
	this.shape_305.setTransform(76.05,-393.79);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgDgPAJgPQAKgPARgDQAQgDAOAJQAOAJAEARQAEAQgKAPQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_306.setTransform(56.0871,-389.7);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgEgQAKgOQAJgOASgEQAPgEAPAKQAOAKAEARQAEAQgKAOQgJAPgSADIgIABQgLAAgLgHg");
	this.shape_307.setTransform(36.1,-385.6);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#493728").s().p("AgWAjQgOgKgEgQQgEgRAKgOQAKgOARgEQAQgEAOAKQAOAKAEARQAEAQgKAOQgKAPgRADIgIABQgMAAgKgHg");
	this.shape_308.setTransform(16.1121,-381.55);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#493728").s().p("AgWAjQgPgKgDgRQgEgQAKgOQAJgPASgDQAQgEAOAKQAOAKAEAQQAEARgKAOQgKAOgQAEIgJABQgLAAgLgHg");
	this.shape_309.setTransform(-3.85,-377.45);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#493728").s().p("AgWAjQgOgJgEgRQgEgRAKgOQAKgOARgEQAQgDAOAJQAOAKAEARQAEAPgKAPQgKAPgRADIgIABQgMAAgKgHg");
	this.shape_310.setTransform(-23.84,-373.35);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgEgQAKgOQAKgOARgEQAQgEAOAKQAPAKADAQQAEARgKAOQgKAPgQADIgJABQgMAAgKgHg");
	this.shape_311.setTransform(-43.8,-369.25);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgEgQAKgOQAKgOARgEQAQgEAOAKQAOAKAEAQQAEARgKAOQgJAPgSADIgIABQgLAAgLgHg");
	this.shape_312.setTransform(-63.8,-365.2);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#493728").s().p("AgWAjQgOgJgEgRQgEgQAKgPQAKgPARgDQAPgDAPAJQAPAJADARQADAQgJAPQgJAPgRADIgJABQgLAAgLgHg");
	this.shape_313.setTransform(-83.75,-361.1);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#493728").s().p("AgWAjQgPgKgDgRQgDgQAJgOQAJgOASgEQAQgEAOAKQAOAJAEASQAEAPgKAPQgKAOgQAEIgJABQgLAAgLgHg");
	this.shape_314.setTransform(-103.75,-357);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#493728").s().p("AgWAjQgPgJgDgSQgDgPAJgPQAJgOASgEQAPgEAPAKQAPAKADARQADAQgJAOQgJAOgRAEIgJABQgLAAgLgHg");
	this.shape_315.setTransform(-123.7,-352.95);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#493728").s().p("AgWAjQgOgJgEgSQgEgPAKgPQAKgPARgDQAQgDAOAJQAPAJADARQAEARgKAOQgKAPgQADIgJABQgLAAgLgHg");
	this.shape_316.setTransform(-143.7,-348.85);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#493728").s().p("AgWAjQgPgKgDgRQgDgQAJgOQAJgPARgDQAQgDAPAJQAOAJAEASQADAQgJAOQgKAOgRAEIgIABQgMAAgKgHg");
	this.shape_317.setTransform(-163.65,-344.75);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#493728").s().p("AgWAjQgOgKgEgRQgDgQAJgOQAKgOARgEQAQgEAOAKQAPAKADARQADAQgJAOQgJAOgRAEIgJABQgMAAgKgHg");
	this.shape_318.setTransform(-183.65,-340.69);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#493728").s().p("AgTAeQgMgIgDgOQgDgOAIgNQAIgMAPgDQANgDANAIQAMAJADAOQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_319.setTransform(-203.625,-336.6);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgKQAHgLAMgCQALgCAKAGQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_320.setTransform(-223.5906,-332.5138);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgKQAHgLAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_321.setTransform(131.8594,-426.2732);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgJAAgKgGg");
	this.shape_322.setTransform(111.875,-422.1861);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_323.setTransform(91.9,-418.1);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_324.setTransform(71.925,-414.025);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_325.setTransform(51.9268,-409.925);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#493728").s().p("AgTAeQgMgJgDgOQgDgOAIgLQAIgNAPgDQANgDANAIQAMAJADAOQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_326.setTransform(31.9601,-405.85);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAJgMAOgDQANgDANAIQAMAJADAOQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_327.setTransform(11.9861,-401.7638);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgJAAgKgGg");
	this.shape_328.setTransform(-8,-397.675);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#493728").s().p("AgTAeQgMgJgDgOQgDgNAIgMQAIgNAPgDQANgDANAIQAMAIADAPQADAOgIAMQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_329.setTransform(-27.975,-393.6);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_330.setTransform(-47.95,-389.5);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_331.setTransform(-67.925,-385.425);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#493728").s().p("AgSAeQgNgJgDgOQgDgNAIgNQAJgMAOgDQAOgDAMAIQAMAIADAPQADANgIANQgJAMgOADIgHABQgJAAgJgGg");
	this.shape_332.setTransform(-87.9,-381.3361);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_333.setTransform(-107.875,-377.25);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#493728").s().p("AgSAeQgNgIgDgPQgDgNAIgNQAIgMAPgDQAOgDALAIQANAIADAPQADANgIANQgJAMgOADIgHABQgKAAgIgGg");
	this.shape_334.setTransform(-127.85,-373.175);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAPgDQANgDANAIQAMAIADAPQADANgIANQgIAMgPADIgHABQgKAAgJgGg");
	this.shape_335.setTransform(-147.825,-369.075);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgOAIgMQAJgMAOgDQANgDAMAIQANAIADAPQADANgIANQgJAMgOADIgHABQgKAAgJgGg");
	this.shape_336.setTransform(-167.8,-365);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgOAIgMQAIgMAPgDQANgDANAIQAMAIADAOQADAOgIAMQgIANgPADIgHABQgKAAgJgGg");
	this.shape_337.setTransform(-187.775,-360.9);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#493728").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAIgMAOgDQAOgDAMAIQANAIADAPQADANgIANQgJAMgOADIgHABQgKAAgJgGg");
	this.shape_338.setTransform(-207.75,-356.825);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_339.setTransform(-227.7268,-352.7268);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgKQAHgLAMgCQALgCAKAGQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_340.setTransform(127.7232,-446.5138);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgKQAHgLAMgCQALgDALAHQAKAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_341.setTransform(107.7268,-442.4232);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_342.setTransform(87.7732,-438.3268);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgLQAHgKAMgDQALgCALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_343.setTransform(67.7768,-434.2406);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgKQAHgLAMgCQALgDAKAHQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_344.setTransform(47.8094,-430.1732);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_345.setTransform(27.825,-426.075);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#493728").s().p("AgQAZQgKgHgDgMQgCgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_346.setTransform(7.8594,-421.9768);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgKQAHgLAMgCQALgCAKAGQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_347.setTransform(-12.125,-417.9138);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgCgLAGgKQAHgLAMgCQALgDALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_348.setTransform(-32.1138,-413.8232);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_349.setTransform(-52.075,-409.7268);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgKQAHgLAMgCQALgCALAGQAKAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_350.setTransform(-72.0732,-405.6638);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgKQAHgLAMgCQALgDAKAHQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgIgFg");
	this.shape_351.setTransform(-92.0268,-401.5732);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgLQAHgKAMgCQALgDALAHQAKAHACAMQADALgHAKQgHALgMACIgGABQgIAAgHgFg");
	this.shape_352.setTransform(-112.0232,-397.475);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgDQALgCAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_353.setTransform(-131.9768,-393.3906);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgKQAHgLAMgCQALgDALAHQAKAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_354.setTransform(-151.9732,-389.3232);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#493728").s().p("AgQAZQgKgHgCgMQgDgLAHgLQAHgKAMgCQALgDAKAHQALAHACAMQADALgHAKQgHALgMACIgGABQgIAAgIgFg");
	this.shape_355.setTransform(-171.9268,-385.225);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#493728").s().p("AgRAcQgMgIgDgNQgCgNAHgMQAIgLANgDQANgDALAIQAMAIADANQADANgIALQgIAMgNADIgHAAQgJAAgIgFg");
	this.shape_356.setTransform(-191.9134,-381.1347);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#493728").s().p("AgRAbQgLgHgDgNQgCgMAHgLQAHgMANgCQANgDALAHQALAIACANQADAMgHALQgHALgNADIgHAAQgIAAgJgFg");
	this.shape_357.setTransform(-211.9,-377.06);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#493728").s().p("AgPAZQgLgHgCgMQgDgLAHgKQAHgLAMgCQALgDAKAHQALAHACAMQADALgHALQgHAKgMACIgGABQgIAAgHgFg");
	this.shape_358.setTransform(-231.8732,-372.9732);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17}]},17).wait(43));

	// Layer_6
	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#FFFFFF").s().p("ACjANQkdhXkQBEIBJgqQBdgtBggPQExgvDeEPQhYg6iQgtg");
	this.shape_359.setTransform(66.9,-391.6781);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#FFFFFF").s().p("Ak7icQCliRDugoQCqgdC9AaQBfANA8ATQoAgfmNFaQh8BthiCFQgwBDgZAtQBRlODOizg");
	this.shape_360.setTransform(-86.5,-396.4395);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#DC7B78").s().p("EAcqAgsQqgg4mylQQhUhEhihgIhShRQBMCDBPBzQhZCUiaBWQifBZi4AAQi6AAifhaQibhZhaiVQh8ByifA/QilBAizAAQi5AAiohEQijhCh9h4Qh+h4hFibQhHihAAixQAAg7AJg9QlSh7jRkcQjVkjAAljQAAjmBcjRQBajLCjicQCjicDUhWQDbhYDwAAQA9AAA3AFQABiyBNijQBKidCFh5QCGh5CthDQC0hEDEAAQEIAADiB5QDbB2CADJQCBgxCOAAQCqAACWBGQCRBDBiB3QBgg8BtggQBxghB3AAQChAACUA7QCOA6BtBpQBuBoA8CIQA+CNAACaIgBAbQDoBQCQDBQCTDFAADyQAAEOizDRQiwDOkPA3QARBVAABYQAAEcioDpQilDjkMBmQCtCoCzBkQDZB6DZAQQg+AJhoAHQhVAEhVAAQh9AAh8gKgAsk7+QjvAoilCRQjOC0hRFOQAYgtAxhDQBiiFB8htQGOlbIAAfQg8gThfgNQhagMhVAAQhfAAhZAPgAQM0FQjekQkyAwQhgAOhdAtIhJAqQEQhEEeBZQCPAsBZA6IAAAAg");
	this.shape_361.setTransform(2.825,-251.5059);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#493728").s().p("EAUtAhfQlihlkLjBQhwCeiwBbQi0BdjLAAQikAAishpQiPhWiDiSQiVBmifBBQi9BNiXAAQjTAAi8hOQi0hLiIiKQiIiIhKi0QhLi4AAjMIAAghQiZhGiChpQiChphjiHQh1ihg9i4Qg9i5AAjEQAAj9BwjiQBrjXDCikQC/ihD1hYQD6haEMgCQAhmkEjkDQEej+GkAAQD7AADpCFQDPB3ClDRQAkgIBngfQBggbAtAAQCnAACVBPQCSBMBqCMQBahECBguQCEgwBqAAQFeAADaECQDJDtAbFvQESBlChDJQCkDOAAD/QAAEPjDDfQi1DQkdBjQAIAbALA4QAKA3AAATQAAEXiKDlQiHDfjqCBQC3CPDbBpQC/BcBYAHIgvAeQieAhjdARQh7AJhyAAQknAAjsg9gAIiYhQBiBfBUBFQGyFPKgA5QDSARDRgMQBogGA+gKQjZgQjZh6QizhkitioQEMhlCljkQCojpAAkcQAAhXgRhVQEPg3CwjPQCzjRAAkNQAAjziTjFQiQjAjohQIABgbQAAiag+iNQg8iIhuhpQhthpiOg5QiUg8ihAAQh3AAhxAhQhtAghgA9Qhih3iRhEQiWhFiqAAQiOAAiBAxQiAjJjbh2Qjih6kIAAQjEAAi0BFQitBCiGB5QiFB6hKCdQhNCigBCyQg3gFg9AAQjwAAjbBZQjUBWijCcQijCchaDKQhcDSAADlQAAFkDVEiQDREdFSB7QgJA8AAA8QAACwBHChQBFCcB+B4QB9B4CjBCQCoBEC5AAQCzAAClhBQCfg+B8hzQBaCWCbBYQCfBbC6AAQC4AACfhZQCahXBZiTQhPhzhMiEg");
	this.shape_362.setTransform(2.825,-254.7967);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359}]},11).wait(49));

	// Layer_7
	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#493728").s().p("AjViEIBFhGIFmGVg");
	this.shape_363.setTransform(235.9,-460.825);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#493728").s().p("AgwkOIBiAEIhVIZg");
	this.shape_364.setTransform(295.55,-479.925);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#493728").s().p("AiTjaICShEICVI9g");
	this.shape_365.setTransform(255.45,-481.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_365},{t:this.shape_364},{t:this.shape_363}]},44).wait(16));

	// _Clip_Group_
	this.instance = new lib.ClipGroup_163();
	this.instance.setTransform(0.6,-2.35,0.3769,0.3769,0,0,0,537,532);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,y:-2.45},11).wait(49));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-536.4,-534.4,1074.1,1064.1);


(lib.chos_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{step_1:0,step_2:1,step_3:2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.index_txt_0_0.visible=false;
		this.index_txt_0_1.visible=false;
		 
		this.txt_0_0.text="";
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// Layer_4
	this.txt_0_0 = new cjs.Text("엑", "100px 'Noto Sans CJK KR Thin'", "#FFFFFF");
	this.txt_0_0.name = "txt_0_0";
	this.txt_0_0.textAlign = "center";
	this.txt_0_0.lineHeight = 150;
	this.txt_0_0.lineWidth = 131;
	this.txt_0_0.parent = this;
	this.txt_0_0.setTransform(-1.8,-55.1);

	this.index_txt_0_1 = new cjs.Text("8", "bold 50px 'Times'");
	this.index_txt_0_1.name = "index_txt_0_1";
	this.index_txt_0_1.textAlign = "center";
	this.index_txt_0_1.lineHeight = 52;
	this.index_txt_0_1.lineWidth = 34;
	this.index_txt_0_1.parent = this;
	this.index_txt_0_1.setTransform(-53.3,-134.4);

	this.index_txt_0_0 = new cjs.Text("8", "bold 50px 'Times'");
	this.index_txt_0_0.name = "index_txt_0_0";
	this.index_txt_0_0.textAlign = "center";
	this.index_txt_0_0.lineHeight = 52;
	this.index_txt_0_0.lineWidth = 33;
	this.index_txt_0_0.parent = this;
	this.index_txt_0_0.setTransform(-99.9,-89.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.index_txt_0_0},{t:this.index_txt_0_1},{t:this.txt_0_0}]}).wait(3));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F3BB4C").ss(8.1,0,0,4).p("Aqzs3Qg2AAgnAnQgnAnAAA3IAAVlQAAA3AnAnQAnAnA2AAIVmAAQA3AAAngnQAngnAAg3IAA1lQAAg3gngnQgngng3AAg");
	this.shape.setTransform(0,-0.025);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({_off:false},0).wait(1));

	// Layer_1
	this.bg_mc = new lib.box_bg_mc();
	this.bg_mc._off = true;

	this.timeline.addTween(cjs.Tween.get(this.bg_mc).wait(1).to({_off:false},0).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-118.2,-136.4,204.60000000000002,231.3);


(lib.bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_64 = function() {
		/* Stop a Movie Clip
		Stops the specified movie clip on stage.
		
		Instructions:
		1. Use this code for movie clips that are currently playing.
		*/
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(64).call(this.frame_64).wait(1));

	// start_btn
	this.instance = new lib.ClipGroup_161();
	this.instance.setTransform(1032,1243,0.0928,0.0928,0,0,0,302.2,99.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).to({regY:99,scaleX:1.2907,scaleY:1.2907,x:1032.05,y:1243.05},5).to({scaleX:1,scaleY:1,x:1032,y:1243},3).wait(4));

	// star
	this.db10 = new lib.star();
	this.db10.setTransform(850.2,212.5);
	this.db10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.db10).wait(40).to({_off:false},0).wait(25));

	// confitti
	this.instance_1 = new lib.d6();
	this.instance_1.setTransform(1021.85,1108.55,0.3068,0.3065,0,0,0,837.3,267.4);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.db9 = new lib.d6();
	this.db9.setTransform(1020.65,776.1,1,1,0,0,0,836,266.4);
	this.db9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(16).to({_off:false},0).to({regX:837.4,scaleX:0.5668,scaleY:0.5666,x:1021.45,y:983.9,alpha:0.3789},12).to({scaleX:0.8917,scaleY:0.8916,x:1020.8,y:828,alpha:0.8398},15).to({_off:true,regX:836,regY:266.4,scaleX:1,scaleY:1,x:1020.65,y:776.1,alpha:1},5).wait(17));
	this.timeline.addTween(cjs.Tween.get(this.db9).wait(43).to({_off:false},5).wait(17));

	// txt2
	this.instance_2 = new lib.t2();
	this.instance_2.setTransform(1289.05,851.3,1,1,0,0,0,772.1,223.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.db8 = new lib.t2();
	this.db8.setTransform(1289.05,851.3,1,1,0,0,0,772.1,223.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},36).to({state:[{t:this.db8}]},7).wait(22));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(36).to({_off:false},0).to({_off:true,alpha:1},7).wait(22));

	// txt1
	this.db7 = new lib.t1();
	this.db7.setTransform(1011.05,435,1,1,0,0,0,591.8,239.7);
	this.db7.alpha = 0;
	this.db7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.db7).wait(30).to({_off:false},0).to({alpha:1},7).wait(28));

	// d7
	this.db6 = new lib.d7();
	this.db6.setTransform(1024,209.2,1,1,0,0,0,1024,209.2);
	this.db6.alpha = 0;
	this.db6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.db6).wait(32).to({_off:false},0).to({alpha:1},11).wait(22));

	// d5
	this.db5 = new lib.d5();
	this.db5.setTransform(1024,768.1,1,1,0,0,0,1023.8,768.1);
	this.db5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.db5).wait(24).to({_off:false},0).wait(41));

	// d4
	this.db4 = new lib.d4();
	this.db4.setTransform(-26,2.05);
	this.db4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.db4).wait(28).to({_off:false},0).wait(37));

	// d3_sub
	this.instance_3 = new lib.d3_sub();
	this.instance_3.setTransform(646.15,1109.9,1,1,0,0,0,66,63.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(22).to({_off:false},0).wait(43));

	// d3
	this.db3 = new lib.d3();
	this.db3.setTransform(1158.3,1133.7,1,1,0,0,0,710.7,188);
	this.db3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.db3).wait(22).to({_off:false},0).wait(43));

	// d2_copy
	this.db2 = new lib.d2();
	this.db2.setTransform(338.55,874.4,1,1,0,0,0,-4,20);
	this.db2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.db2).wait(17).to({_off:false},0).wait(48));

	// d2
	this.db2_1 = new lib.d2();
	this.db2_1.setTransform(1422.55,94.4);
	this.db2_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.db2_1).wait(17).to({_off:false},0).wait(48));

	// d1_copy
	this.db1 = new lib.d1();
	this.db1.setTransform(1747.5,1234.95,1,1,179.7622,0,0,299.8,301.8);

	this.timeline.addTween(cjs.Tween.get(this.db1).wait(65));

	// d1
	this.db1_1 = new lib.d1();
	this.db1_1.setTransform(1024,768.2,1,1,0,0,0,1024,768);

	this.timeline.addTween(cjs.Tween.get(this.db1_1).wait(65));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCB17").s().p("Eif/B4AMAAAjv/ME//AAAMAAADv/g");
	this.shape.setTransform(1024,768);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(65));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-705,-379.8,3338.6,2320.5);


(lib.wrong_ans_pop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.play();
	}
	this.frame_74 = function() {
		ths.wrongAnswer();
		
		ths.pop_mc.gotoAndStop(0);
		this.gotoAndStop(0);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(73).call(this.frame_74).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#281800").s().p("Az5HiIAAj4IIOAAIAAhRIoTAAIAAhUIJ3AAIAAD3IoNAAIAABSIIqAAIAABUgEAh2AHcIAAu9IBnAAIAAO9gANsHcIAAlIImDAAIAAhYINvAAIAABYImEAAIAAFIgADBHcIAAu9IBmAAIAAFdICUAAIAABbIiUAAIAAIFgA95HcIAAu9IBlAAIAAO9gEgtWAHcIAAu9IBlAAIAAFaICVAAIAABZIiVAAIAAIKgAe3GtIAAn/IiYAAIAAhZICYAAIAAkiIBnAAIAAN6gEA04AGQIAAh3IB2AAIAAB3gEAlLAFcIAAhXIDbAAIAAjoQgugdgdgsQgbgsAAg5IAAgyQAAg2AagrQAZgrAsgfQAsgeA6gRQA8gQBBAAQBAAAA8AQQA6ARAtAeQArAfAaArQAaArAAA2IAAAyQAAA5gcAsQgdAsgtAdIAADoIDbAAIAABXgEAqMAEFIDsAAIAAi9Qg4AOg+AAQg/AAg3gOgEAqugFJQgnAKgfAUQggATgRAcQgSAcAAAjIAAAnQAAAiASAdQASAcAfATQAfAUAnAKQAoAKAtAAQAsAAAngKQAngKAggUQAegTASgcQASgdAAgiIAAgnQAAgjgSgcQgRgcgfgTQgggUgngKQgngKgsAAQgtAAgoAKgEgooACuQBbhRBJhQQAXgaAQgXQAPgWAKgXQAIgWAEgYQAEgWAAgdIAAjqIBoAAIAADqQAAAhAEAWQAFAYAIAXQAJAXARAVQAOAVAaAbQAmApAfAeQAgAeA0AuIhDBHQgwgsgrgrQgggfgigmQgRgRgXgcQgQgUgHgPIgBAAQgIASgOAQQgNASgZAbQgWAYg0A0QgpAqg2AwgAmSDyIAAl4IFGAAIAAi1IlJAAIAAhYIGuAAIAAFkIlFAAIAADKIBXAAIBegBQAfgBAygDIBKgGQAcgDAxgHIAMBXIhKAJQghAEgtACQgsADgzACQg0ABhAAAgAV+CmQAwgtAqguQApgrAkgtQAQgWAJgTQALgUAEgWQAFgVACgaQABgYABgcIAAjQIBjAAIAADQQABAcABAXQABAYAGAUQAEAUAKAVQAKAVAQATQAiAsAoAqQAkAoAyAxIhHBDIhMhOQgogqgaggQgPgTgMgRQgLgQgFgRIgBAAQgGARgLAQQgNASgPATQgkArgiAkIhRBVgEg2tADfIAAppIG3AAIAABZIlRAAIAAG3IA2AAQBjAABcgHQBdgHBUgNIANBWQheARhfAHQhdAGh4AAgA14gLIAAhXIFOAAIAAijIBpAAIAACjIG4AAIAABXgAIwhhQA3gVA7gbQA5gaAwgaQAggQATgSQATgQAKgTQAKgQAFgTQADgSAAgTIkTAAIAAhYIKOAAIAABYIkUAAQAAATAEASQADASAKARQAJARAUASQATARAfARQA1AcA1AYQA8AbA3AVIgoBTQg6gWg8gcIheguQg3gbgZgTQgagTgKgSIgBAAQgIARgbAVQgcAUg0AaIhfAuQg5Abg9AXgAsGiYQANg7ACgqQADguAAggIAAgjIoQAAIAAhYIJ4AAIgBCRIgDAyIgHA7QgEAfgGAcg");
	this.shape.setTransform(-9.75,301.075);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(29).to({_off:false},0).wait(46));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#281800").s().p("EgxMAHeQg3gOgmgZQglgYgUgiQgVgiAAgkIAAgqQAAglAVgiQAUgiAlgYQAmgZA3gOQA4gOBDAAQBCAAA5AOQA2AOAnAZQAlAZAUAhQAVAhAAAmIAAAqQAAAlgVAhQgUAhglAZQgnAZg2AOQg2AOhFAAQhGAAg1gOgEgwhAC0QgkAJgZAPQgZAPgNATQgNATAAASIAAAdQAAATANASQANASAZAQQAXAOAmAKQAkAJAsAAQAtAAAkgJQAlgKAXgOQAZgOAOgUQANgSAAgTIAAgdQAAgSgNgTQgOgUgZgOQgZgPgjgJQgkgJgtAAQgsAAgkAJgEAvgAHRIAAu8IBlAAIAAFaICVAAIAABZIiVAAIAAIJgEAhfAHRIAAu8IBmAAIAAO8gAK7HRIAAmmIBmAAIAAB6IGKAAIAAh6IBlAAIAAGmgAMhF6IGKAAIAAh+ImKAAgADNHRIAAu8IBlAAIAAFaICVAAIAABZIiVAAIAAIJgAu7HRIAAu8IBmAAIAAO8gEglyAHRIAAmmIBmAAIAAB6IF8AAIAAh6IBlAAIAAGmgEgkMAF6IF8AAIAAh+Il8AAgEA1GAGFIAAh3IB2AAIAAB3gA2sDaQgtgSgggiQghgkgRgzQgTg0ABhDIAAhsQgBhFATg1QARgzAhgkQAggjAtgRQArgSA1AAQA1AAAsASQAtARAgAkQAgAkASAzQASA1AABEIAABsQAABBgSA2QgSAzggAkQggAigtASQgsARg1AAQg0AAgsgRgA2ClDQgYAKgWAYQgSAXgNAnQgMAnAAA2IAABPQAAA3AMAlQAMAmATAXQAVAZAZAKQAaAKAcAAQAbAAAbgKQAbgLATgYQAVgZALgkQALglAAg3IAAhPQAAg2gLgnQgMglgVgZQgUgYgZgKQgZgLgdAAQgcAAgaALgAkMDZQgsgSgggiQgfgjgTgzQgSg0AAhDIAAhsQAAhGASgzQATg0AfgiQAhgkArgRQAtgSA0AAQA1AAAsASQAsASAfAjQAfAhATA1QASA0AABFIAABsQAABDgSA0QgTA0gfAiQgeAhgtATQgtARg0AAQg0AAgtgRgAjhlCQgbALgSAXQgUAXgLAmQgMAnAAA2IAABPQAAA2AMAmQALAmAUAXQATAYAaAKQAbAKAbAAQAbAAAbgKQAagKATgYQAUgXAMgmQALglABg3IAAhPQgBg2gLgnQgMgmgUgXQgSgXgbgLQgagLgcAAQgcAAgaALgEAmIADVIAApqIG3AAIAABZIlRAAIAAG4IA3AAQBiAABdgIQBcgGBVgNIANBVQheAShfAGQhlAHhxAAgAX1DQIAAptIBnAAIAAITIBdAAQBWAABRgFQBMgFBUgQIALBZQgsAJgqAFQgsAGgoADQguADgsAAIhsABgEgsVABJIAAjyIixAAIAAhWICxAAIAAjsIBlAAIAAI0gEg27gAHQAygiArgiQAqggAegdQATgTANgRQAMgRAKgUQAHgUAEgWQADgZAAgZIAAgrIjJAAIAAhXIHuAAIAABXIi9AAIAAAmQAAAXACAWQACARAGATQAGARAKAQQAKANASARQAoAkAlAcQAuAiApAbIg6BJQgmgagmgcQgtgigcgYQgYgTgOgPQgPgPgFgMIgBAAQgGAMgTAZQgSAVgbAXQgsAlgeAXQgoAfgtAggASrgBIAAnqIBlAAIAAHqgA+QgBIAAnqIBlAAIAADGICJAAIAABZIiJAAIAADLgEgnygGyIG9AAIAABXIlWAAIAADgICHgBIBlgDQApgBAwgFQA5gEAngGIAKBVQgpAGg+AGIhqAGQhLADg8ABIi+AAgAI8m4IBlAAIAAExIDegEQAqgCA7gFQA0gEA4gIIAKBWQgxAGg7AGQg6AHg5ACQhEADhGABIi1ABg");
	this.shape_1.setTransform(-11.15,168.65);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(29).to({_off:false},0).wait(46));

	// Layer_4
	this.instance = new lib.step_wrong();
	this.instance.setTransform(-17.95,-285.45);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).wait(61));

	// _Clip_Group_
	this.instance_1 = new lib.ClipGroup_163();
	this.instance_1.setTransform(0.6,71.55,0.3495,0.3495,0,0,0,536.9,531.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:537,regY:532,scaleX:1,scaleY:1,y:71.5},14).wait(61));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-536.4,-460.5,1074.1,1064.1);


(lib.pop_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"step_1":0,"step_2":1,"step_3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.correct_pop_mc.gotoAndPlay(1);
	}
	this.frame_2 = function() {
		this.wrong_ans_pop.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// Layer_1
	this.correct_pop_mc = new lib.correct_pop_msg();
	this.correct_pop_mc.setTransform(15.55,54.1,1,1,0,0,0,0.6,-2.4);

	this.wrong_ans_pop = new lib.wrong_ans_pop();
	this.wrong_ans_pop.setTransform(15.55,-16.25,1,1,0,0,0,0.6,1.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.correct_pop_mc}]},1).to({state:[{t:this.wrong_ans_pop}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-186.8,-146.4,404.8,401.1);


// stage content:
(lib.crossword = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"step_1":0,"step_2":1,"step_3":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		
		/* Mouse Click Event
		Clicking on the specified symbol instance executes a function in which you can add your own custom code.
		
		Instructions:
		1. Add your custom code on a new line after the line that says "// Start your custom code" below.
		The code will execute when the symbol instance is clicked.
		*/
		
		this.start_btn.addEventListener("click", fl_MouseClickHandler.bind(this));
		
		function fl_MouseClickHandler()
		{
			this.gotoAndStop(1);
		}
	}
	this.frame_1 = function() {
		total_ques = 3;
		ques_no = 0;
		ths = this;
		corr_arr = [0, 1, 2];
		arr = ["엑스포지", "즈위즈", "스즈키"];
		sel_arr = [
			["0_3_0", "0_4_0", "0_5_1", "0_6_0"],
			["0_4_0", "1_4_1", "2_4_0"],
			["2_4_0", "2_5_0", "2_6_1"]
		];
		/*
			<link rel="icon" type="image/gif" href="cursor.gif">
			<style>
		 
				
				body {
		   
		  
		  &, * {
		    cursor: url(cursor.gif);
		  }
		}
			</style>
		*/
		ch_arr = ["0_3_0", "0_4_1", "2_4_0"];
		for (var ai = 0; ai < 8; ai++) {
			this["ch_0_" + ai].visible = false;
			this["ch_1_" + ai].visible = false;
			this["ch_2_" + ai].visible = false;
		}
		
		function chos_show_ans(sel_q)
		{
			var bi = sel_q;
			for (var ci = 0; ci < sel_arr[bi].length; ci++) {
				var vx = sel_arr[bi][ci].split("_")[0];
				var vy = sel_arr[bi][ci].split("_")[1];
				if(sel_arr[bi][ci].split("_")[2]==1)
				{
				ths["ch_" + bi + "_" + vy].txt_0_0.visible=true;	
				}
			}
		}
		for (var bi = 0; bi < sel_arr.length; bi++) {
			for (var ci = 0; ci < sel_arr[bi].length; ci++) {
				var vy = sel_arr[bi][ci].split("_")[1];
				this["ch_" + bi + "_" + vy].visible = true;
				this["ch_" + bi + "_" + vy].gotoAndStop(1);
				this["ch_" + bi + "_" + vy].index_txt_0_0.visible = false;
				this["ch_" + bi + "_" + vy].index_txt_0_1.visible = false;
				this["ch_" + bi + "_" + vy].txt_0_0.font = "bold 96px Noto Sans CJK KR";
				this["ch_" + bi + "_" + vy].txt_0_0.visible=false;
				
				
				if (ci == 0) {
					sup_arr = ch_arr[bi].split("_");
					if (sup_arr[2] == 0) {
						this["ch_" + sup_arr[0] + "_" + sup_arr[1]].index_txt_0_0.visible = true;
		
						this["ch_" + sup_arr[0] + "_" + sup_arr[1]].index_txt_0_0.text = (bi + 1);
		
					} else {
						this["ch_" + sup_arr[0] + "_" + sup_arr[1]].index_txt_0_1.visible = true;
						this["ch_" + sup_arr[0] + "_" + sup_arr[1]].index_txt_0_1.text = (bi + 1);
					}
				}
				this["ch_" + bi + "_" + vy].txt_0_0.text = arr[bi].split("")[ci];
				
				this["chos_btn_" + bi].gotoAndStop(bi);
				this["btn_" + bi].name = "btn_" + bi;
				this["btn_" + bi].addEventListener("click", clkfun.bind(this["btn_" + bi]));
			}
			chos_show_ans(bi);
		}
		
		function closeAll() {
			for (var bi = 0; bi < sel_arr.length; bi++) {
				for (var ci = 0; ci < sel_arr[bi].length; ci++) {
					var vy = sel_arr[bi][ci].split("_")[1];
					ths["ch_" + bi + "_" + vy].visible = false;
				}
			}
		}
		function select_quiz(sel_q) {
			var bi = sel_q;
			for (var ci = 0; ci < sel_arr[bi].length; ci++) {
				var vx = sel_arr[bi][ci].split("_")[0];
				var vy = sel_arr[bi][ci].split("_")[1];
				ths["ch_" + vx + "_" + vy].visible = true;
				ths["ch_" + vx + "_" + vy].gotoAndStop(2);
				ths["ch_" + vx + "_" + vy].txt_0_0.visible = false;
				if(sel_arr[bi][ci].split("_")[2]==1)
				{
							ths["ch_" + vx + "_" + vy].txt_0_0.visible = true;
					}
			}
		}
		select_quiz(ques_no);
		
		ths.wrongAnswer = function () {
			//ths.check_ans_timer_mc.gotoAndPlay(1);
		
		
		}
		ths.moveNextQuestion = function () {
			if (ques_no < total_ques - 1) {
		
		
		
		
				var bi = ques_no;
				for (var ci = 0; ci < sel_arr[bi].length; ci++) {
					var vx = sel_arr[bi][ci].split("_")[0];
					var vy = sel_arr[bi][ci].split("_")[1];
		
					ths["ch_" + vx + "_" + vy].gotoAndStop(1);
					ths["ch_" + vx + "_" + vy].txt_0_0.visible = true;
				}
		
		
				ques_no++;
				select_quiz(ques_no);
			} else {
		
				closeAll();
				ths.gotoAndStop("step_3");
			}
		}
		function show_timer_wrong() {
		
			var bi = ques_no;
			for (var ci = 0; ci < sel_arr[bi].length; ci++) {
				var vx = sel_arr[bi][ci].split("_")[0];
				var vy = sel_arr[bi][ci].split("_")[1];
		
				ths["ch_" + vx + "_" + vy].bg_mc.gotoAndStop(1);
				ths["ch_" + vx + "_" + vy].txt_0_0.visible = true;
			}
			ths.check_ans_timer_mc.gotoAndPlay(1);
		}
		ths.show_wrong_pop = function () {
		
			var bi = ques_no;
			for (var ci = 0; ci < sel_arr[bi].length; ci++) {
				var vx = sel_arr[bi][ci].split("_")[0];
				var vy = sel_arr[bi][ci].split("_")[1];
		
				ths["ch_" + vx + "_" + vy].bg_mc.gotoAndStop(0);
				ths["ch_" + vx + "_" + vy].txt_0_0.visible = false;
				if(sel_arr[bi][ci].split("_")[2]==1)
				{
							ths["ch_" + vx + "_" + vy].txt_0_0.visible = true;
					}
			}
		
		
			ths.pop_mc.gotoAndStop("step_3");
		}
		function clkfun(evn) {
		
			if (evn.currentTarget.name.toString().split("_")[1] == corr_arr[ques_no]) {
				ths.pop_mc.gotoAndStop("step_2");
		
			} else {
				show_timer_wrong();
			}
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(2));

	// Isolation_Mode
	this.instance = new lib.Artboard3();
	this.instance.setTransform(2421,-187);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({_off:true},1).wait(1));

	// Layer_1
	this.pop_mc = new lib.pop_mc();
	this.pop_mc.setTransform(1024,768.5);
	this.pop_mc._off = true;

	this.timeline.addTween(cjs.Tween.get(this.pop_mc).wait(1).to({_off:false},0).to({_off:true},1).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4C4D4E").s().p("ABIC9QgWgGgOgKQgOgIgJgOQgIgNAAgPIAAgRQAAgPAIgMQAIgOAPgKQAQgKAUgFQAXgGAaABQAagBAWAGQAUAFARAKQAPAKAIAOQAIAMAAAPIAAARQAAAPgIANQgJAOgOAIQgPAKgWAGQgWAGgaAAQgaAAgXgGgABZBHQgPAEgJAGQgJAFgGAIQgFAIAAAHIAAALQAAAHAFAIQAFAGAKAHQALAHANACQAOAEASAAQASAAAOgEQANgCALgHQAKgHAFgGQAFgIAAgHIAAgLQAAgHgFgIQgFgIgKgFQgJgGgPgEQgRgEgPAAQgPAAgRAEgAb7C8IAAhgIjQAAIAAgjID4AAIAACDgASnC6IAAhhIDPAAIAAggIjRAAIAAghID5AAIAABhIjPAAIAAAgIDaAAIAAAhgALLC6IAAhfIDQAAIAAgbIjSAAIAAgiID6AAIAABeIjQAAIAAAdIDbAAIAAAhgAtwCaQAggNARgJIAhgQQAVgLAGgLQAHgJAAgOIAAgCIhlAAIAAgjIDxAAIAAAjIhkAAIAAACQAAAHACAGQABAGAEAGQAEAFAHAFQAGAFALAGIAQAHIASAJIAwAVIgPAgQghgOgNgHIghgPQgSgJgLgJQgJgIgEgGQgDAHgKAIQgKAHgVALIggAPIguAUgAzTC6IAAhnIDBAAIAAglIjDAAIAAgiIDqAAIAABoIjAAAIAAAlIDLAAIAAAhgEAtrAC3IAAl5IAoAAIAAF5gEAltAC3IAAiBIiZAAIAAgjIFbAAIAAAjIiZAAIAACBgEAiEAC3IAAjJIgoAAIAAC3IgoAAIAAlfIAoAAIAACFIAoAAIAAiNIAoAAIAAF5gAFpC3IAAimIAoAAIAAAwICWAAIAAgwIAoAAIAACmgAGRCVICWAAIAAgyIiWAAgA3PC3IAAl5IAoAAIAAF5gA9EC3IAAl5IAoAAIAAF5gEgwsAC3IAAl5IAoAAIAACJIA7AAIAAAjIg7AAIAADNgEguFAC3IAAiCID4AAIAACCgEgtdACVICoAAIAAg9IioAAgAn5C0IAAhxIApAAIAABNIDVAAIAAAkgEgmpAC0IAAhwIApAAIAABMIDVAAIAAAkgEAsfAClIAAjJIg8AAIAAgjIA8AAIAAhzIApAAIAAFfgA4aClIAAi5IgnAAIAAAEQAAA2gVAaQgVAbgpAAQgpAAgWgbQgVgaAAg2IAAgoQAAg3AVgbQAWgbApAAQApAAAVAbQAVAbAAA3IAAABIAnAAIAAiDIAoAAIAAFfgA62hvQgLASAAApIAAAfQAAAoALATQAKARAYAAQAXAAAKgRQALgSAAgpIAAgfQAAgqgLgRQgLgSgWAAQgYAAgKASgA+QClIAAjIIg5AAIAAgjIA5AAIAAh0IAoAAIAAFfgEAu/ACFIAAgiIBWAAIAAhbQgTgMgKgRQgLgRAAgXIAAgTQAAgWAKgRQAJgQASgNQARgLAYgIQAZgGAYAAQAYAAAZAGQAYAIAQALQATANAJAQQAKAQAAAXIAAATQAAAXgLARQgLARgSAMIAABbIBWAAIAAAigEAw9ABjIBeAAIAAhLQgXAGgYAAQgZAAgWgGgEAxLgCFQgSAEgKAHQgNAJgGAKQgHAMAAAMIAAARQAAAMAHAMQAGAKANAJQAMAHAQAEQARAEAQAAQAQAAARgEQAQgEAMgHQANgJAGgKQAHgMAAgMIAAgRQAAgMgHgMQgGgKgNgJQgKgHgSgEQgRgEgQAAQgQAAgRAEgEgk9ABmIAAhJIieAAIAAgiIFbAAIAAAiIiUAAIAABJgEghuABAIAjgjQANgOAQgTQAMgPAEgQQAEgSAAgQIAAg2IhBAAIAAgjIClAAIAAAjIg9AAIAAA2QAAAQAFARQAFAPAMAQQAMAPAPAQQARATAQAOIgcAbIg3g7IgLgPQgFgHgBgFIgBAAQgDAHgEAFIhFBPgEAo/AA+IAjgkQAUgWAKgNQAIgKACgGIAGgRQADgKAAgIIABhmIAnAAIABBlQAAAJACAJIAGAQQADAHAHAJQALAOASATIAiAjIgcAbIgegfIgagdIgKgPQgGgIgBgDIAAAAIgHAMIgLAOIgcAfIggAigAefBSQgPgFgLgLQgMgMgFgLQgGgNAAgPIAAgTQAAgOAGgOQAGgMALgLQALgKAPgGQAQgGATAAQATAAAPAGQAOAFAMALQALAKAGANQAGAOAAAOIAAATQAAAPgGANQgGANgLAKQgMALgOAFQgPAHgTAAQgTAAgQgHgAetgoQgJAFgFAFQgGAHgDAHQgEAIAAAHIAAAOQAAAGAEAJQADAHAGAHQAHAGAHAEQAKADALAAQALAAAJgDQAIgEAHgGQAGgHADgHQADgIAAgHIAAgOQAAgIgDgHQgDgHgGgHQgFgFgKgFQgIgDgMAAQgMAAgJADgEg0YABUIAAj0ICtAAIAAAkIiFAAIAACtIAVAAQApAAAjgDQAcgCAqgGIAFAiQgiAHgpACQgrADgpAAgAb7AlIAAjnIAoAAIAADngAorAjIAAgjIFbAAIAAAjgADDAdIAAhfIhGAAIAAgiIBGAAIAAheIAoAAIAADfgAhIgCIAlgbQATgPAJgJIAMgPQAGgGADgIQADgHABgJQACgKAAgKIAAgRIhPAAIAAgjIDCAAIAAAjIhKAAIAAAgQABAIACAHIAHAMIALANQAMALASAOIAjAYIgXAdIgegWQgQgLgNgLIgPgOQgGgGgCgEIgBAAQgDAGgHAIQgHAJgKAIIgdAXQgTAQgOAJgEgu2AATIAAghIFbAAIAAAhgAqeAPIAAjRIAoAAIAABTIA2AAIAAAjIg2AAIAABbgAYDAPIAAhxICAAAIAAgsIiBAAIAAgiICpAAIAABwIiAAAIAAAuIBjgCIAhgCIAkgEIAEAhIiOAIgAKaAEIAAggIFaAAIAAAggAInAAIAAjCIAoAAIAABPIA2AAIAAAjIg2AAIAABQgAwTgFIAAi9IAoAAIAABKIA2AAIAAAjIg2AAIAABQgEAjwgAqIAtgTIAqgUQAOgIAGgGQAHgGAFgHQAEgIABgHIACgOIhtAAIAAgiIECAAIAAAiIhtAAIACAOQACAJADAGQAFAHAGAGQAFAFAPAJIBXAnIgPAhQgagKgVgKIglgSQgSgJgOgJQgKgHgEgIIAAAAQgDAHgLAIQgKAIgWALIglASQgVAJgaAKgAR1gJIAAgiID5AAIAGgnIjSAFIgBgiIDVgDIAAgiIjQAAIAAgiID5AAIgBBLIgBAUIgFAsIA4AAIAAAigAuQgJIAAijICtAAIAACjgAtogsIBdAAIAAheIhdAAgAE2irICwAAIAAAjIiIAAIAABYIBegCIAjgCIAmgDIAEAgIhTAIIiAABgAzWgWQgRgGgMgMQgLgLgHgOQgGgOAAgNIAAgQQAAgNAGgOQAHgPALgKQAMgMARgHQASgHAXgBQAYABARAHQARAHAMAMQALAKAHAPQAGAOAAANIAAAQQAAANgGAOQgHAOgLALQgMAMgRAGQgRAIgYAAQgXAAgSgIgAzEiTQgJADgJAHQgHAHgDAHQgEAIAAAIIAAANQAAAJAEAHQAEAJAGAGQAIAHAKADQAKAEANAAQANAAAKgEQAKgDAIgHQAGgGAEgJQAEgHAAgJIAAgNQAAgIgEgIQgDgHgHgHQgJgHgJgDQgIgEgPAAQgPAAgIAEgAmwggQgXgFgQgLQgPgKgJgOQgIgNAAgQIAAgNQAAgPAIgOQAJgNAPgLQAQgKAXgGQAWgGAdAAQAcAAAWAGQAXAGAQAKQAQALAIANQAIAOAAAPIAAANQAAAPgIAOQgIAOgQAKQgQALgXAFQgWAHgcAAQgdAAgWgHgAmgiYQgQAEgJAGQgLAHgFAHQgGAIAAAIIAAAJQAAAJAGAHQAFAIALAHQAJAFAQAEQAOAEAUgBQAUABAOgEQAQgEAKgFQALgHAFgIQAGgGAAgKIAAgJQAAgJgGgHQgFgHgLgHQgKgGgQgEQgOgDgUAAQgUAAgOADgEgs6gArQgWgFgRgJQgRgKgHgMQgJgMAAgQIAAgMQAAgQAJgNQAIgNAQgJQARgIAWgGQAWgEAbAAQAbAAAXAEQAXAGAPAIQAQAJAJANQAJANAAAQIAAAMQAAAPgJANQgIAMgRAKQgPAJgXAFQgXAEgbAAQgbAAgWgEgEgsqgCYQgOADgMAFQgKAFgGAGQgGAIAAAIIAAAIQAAAIAGAGQAGAHAKAGQAMAEAOADQARACAQABQAQgBARgCQAPgDALgEQAKgGAHgHQAGgGAAgIIAAgIQAAgIgGgIQgIgHgJgEQgLgFgPgDQgPgCgSAAQgSAAgPACgEgmogAoIAAiLID2AAIAACLgEgmAgBKIClAAIAAhGIilAAgAMVg4QgXgFgPgIQgQgJgJgMQgIgMAAgOIAAgKQAAgPAIgLQAJgNAQgIQAPgJAXgFQAYgEAaAAQAbAAAYAEQAWAFAQAJQAQAIAIANQAIALAAAPIAAAKQAAAOgIAMQgIAMgQAJQgQAIgWAFQgVAFgeAAQgeAAgUgFgAMLiUQgVAKAAANIAAAIQAAANAVAJQAWAKAmAAQAnAAAVgKQAVgJAAgNIAAgIQAAgNgVgKQgUgKgoAAQgnAAgVAKgAdghgIAAgiIBMAAIAAg0IAoAAIAAA0IBIAAIAAAig");
	this.shape.setTransform(726.975,198.5);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).to({_off:true},1).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AM1EXQgggGgYgNQgYgPgMgRQgOgUAAgYIAAgWQAAgYAOgTQAMgRAYgPQAagNAegHQAggHAkAAQAjAAAiAHQAeAHAZANQAYAPANARQANATAAAYIAAAWQAAAYgNAUQgNARgYAPQgXAMggAHQgeAHgnAAQgnAAgdgHgANMByQgUAEgQAIQgPAIgJAKQgKAKAAAMIAAAPQAAAMAKAKQAJAKAPAHQAQAIAUAEQAVAFAYAAQAYAAAVgFQAVgEAPgIQAPgHAKgKQAJgLAAgLIAAgPQAAgLgJgLQgJgKgQgIQgPgIgVgEQgVgFgYABQgYgBgVAFgEg1UAESIAAiWIEbAAIAAgzIkeAAIAAgxIFYAAIAACVIkaAAIAAA0IEqAAIAAAxgEAyGAEOIAAorIA7AAIAADJIBWAAIAAA0IhWAAIAAEugEAp9AEOIAAorIA7AAIAAIrgAc2EOIAAjyIA7AAIAABEIDlAAIAAhEIA7AAIAADygAdxDcIDlAAIAAhJIjlAAgAUVEOIAAjvIA7AAIAABEIDkAAIAAhEIA8AAIAADvgAVQDcIDkAAIAAhGIjkAAgAi8EOIAAorIA7AAIAAIrgAuJEOIAAorIA7AAIAAIrgEgoaAEOIAAorIA7AAIAADJIBXAAIAAA0IhXAAIAAEugA7jEIIAAixIA7AAIAAB+IEnAAIAAAzgAkrD0IAAknIhUAAIAAg0IBUAAIAAirIA7AAIAAIGgEA1WADiIAAhFIBFAAIAABFgAhBDEIAAgyIDgAAIAAh3IA8AAIAAB3IDhAAIAAAygEglsADEIAAgyIH+AAIAAAygA0VBnIDLgDIBSgEIBMgGIAGAyIhOAGIhUAFIhfACIhuABgApyBeQASgSAhghQAagcAQgVQATgZAGgWQAGgXAAgZIAAhQIhgAAIAAgzIDzAAIAAAzIhZAAIAABQQAAAaAGAWQAIAYARAWQAVAZATAVQARASAfAeIgoAoIgsgtQgWgXgQgTIgQgWQgGgJgDgJIgBAAQgDAIgHAKIgQAWQgQATgYAaQgPARggAggEguYABeQA5gzAmgrQAPgQAIgMQAIgLAGgPQAFgLACgQQADgPAAgPIAAiGIA8AAIAACGQAAARACAQQADAPAFAMQAFALAKAPIAXAbQAUAXAVASIAwAsIgnApIg1gxIg9hDQgKgMgEgIIAAAAQgFAKgIAKIhBBGIg3A0gEAsqAB8IAAlnID/AAIAAA0IjEAAIAAD/IAgAAQA4AAA3gEQAzgDAzgJIAIAzQg1AJg5AEQg8AEhAAAgEAkWgDvIA8AAIAAE0IA2AAQA1AAAsgEQAsgDAxgIIAGA0QgWAEgcAEIgwAEIg1ADIifABgA3LBwIAAmNIA7AAIAACWIBPAAIAAA1IhPAAIAADCgEgkkAA8IAAiwIExAAIAAhJIk0AAIAAgyIFvAAIAACuIkxAAIAABKIE/AAIAAAzgAgdABIBCgjQAZgMAigXQAigUAPgZQAOgYAAghIAAgPIihAAIAAg0IF/AAIAAA0IiiAAIAAAPQAAAQADAPQADANAIAMQAGALANAMQANAMARALIBcA1QASAKARAGIgeAwIh7hFQgegTgQgOQgOgMgGgJIgBAAQgEAIgRAOQgPANgfAUIg7AjQgjAUgcAOgA8tkBIEJAAIAAAzIjOAAIAABFIDEAAIAAAzIjEAAIAABHIBSgBIBAgCIBlgIIAGAvQgdAEgeACIhBAFIi8ADgAJ6AUIAAgxIDCAAIAAhtIA9AAIAABtID/AAIAAAxgAyjAJQgbgJgUgRQgSgPgLgYQgKgUAAgZIAAgbQAAgaAKgUQAKgVATgSQAVgSAagIQAbgLAiAAQAjAAAbALQAZAIAVASQAVASAJAVQAKAWAAAYIAAAbQAAAYgKAVQgKAXgUAQQgTARgbAJQgbAKgjABQgigBgbgKgAyJjAQgRAGgMAJQgMAKgHANQgHAOAAAPIAAAVQAAANAHAOQAHAOAMAJQANAKAQAHQAQAGATAAQATAAARgGQAPgGAOgLQAMgJAHgOQAHgMAAgPIAAgVQAAgQgHgNQgHgNgMgKQgNgKgQgFQgRgGgTAAQgTAAgQAGgAY0AFIAAh3IhsAAIAABkIkIAAIAAj2IA7AAIAABQICSAAIAAhQIA7AAIAABfIBsAAIAAh4IA8AAIAAEigAT7hAICSAAIAAhCIiSAAgEAhWAAAIAAkdIA7AAIAAEdgEgw6gAFIAAkYIA7AAIAABxIBPAAIAAA0IhPAAIAABzgAcqgUQgagLgRgQQgRgQgJgVQgJgWAAgUIAAgXQAAgVAJgVQAJgWARgQQARgQAagLQAbgKAhAAQAiAAAbAKQAaALARAQQARAQAJAWQAIAUAAAWIAAAXQAAAWgIAUQgKAVgQAQQgRAQgaALQgaALgjgBQgiABgagLgAdEjPQgQAGgJAJQgLAJgFAMQgGANAAAMIAAARQAAAMAGANQAFAMALAKQAKAJAPAHQAPAFATAAQAUAAAPgFQAOgGALgKQALgLAFgLQAFgNAAgMIAAgRQAAgMgFgNQgGgMgKgJQgKgKgPgFQgPgHgUAAQgTAAgPAHgEg2agAYIAAj1IA7AAIAABQICJAAIAAhQIA8AAIAAD1gEg1fgBJICJAAIAAhDIiJAAgAPihGQAIgjADgfQADgeAAgZIAAgVIkzAAIAAgyIFvAAIgBBfIgOBng");
	this.shape_1.setTransform(742.025,474.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EAwvAEZQgegIgXgPQgWgOgLgUQgMgTAAgWIAAgYQAAgVAMgUQALgTAWgOQAVgPAggIQAdgJApAAQApAAAdAJQAgAIAVAPQAWAOALATQAMAUAAAVIAAAYQAAAWgMATQgLAUgWAOQgWAPgfAIQgfAJgnAAQgnAAgfgJgEAxIABrQgWAHgMAHQgPAJgHALQgIALAAALIAAARQAAALAIALQAHALAPAIQAMAJAWAFQAVAGAYAAQAZAAAVgGQAVgFANgJQAPgIAHgLQAHgLAAgLIAAgRQAAgLgHgLQgHgLgPgJQgNgHgVgHQgVgFgZAAQgYAAgVAFgATmEZQgegIgXgPQgVgOgMgUQgMgTAAgWIAAgYQAAgVAMgUQAMgTAVgOQAVgPAggIQAegJAoAAQApAAAdAJQAgAIAVAPQAWAOALATQAMATAAAWIAAAYQAAAXgMASQgLAUgWAOQgXAPgeAIQgfAJgnAAQgmAAgggJgAT/BrQgVAHgNAHQgOAIgIAMQgHALAAALIAAARQAAALAHALQAIALAOAIQANAJAVAFQAVAGAYAAQAZAAAVgGQAVgFANgJQAOgIAIgLQAHgLAAgLIAAgRQAAgLgHgLQgIgMgOgIQgNgHgVgHQgVgFgZAAQgYAAgVAFgEgsWAEbQgfgHgYgNQgXgNgOgTQgNgTAAgYIAAgWQAAgYANgTQAOgTAXgNQAVgMAigIQAhgHAjAAQAkAAAhAHQAhAIAWAMQAYANANATQANATAAAYIAAAWQAAAYgNATQgNATgYANQgZANgeAHQghAHgkAAQgjAAghgHgEgr/AB1QgUAFgQAHQgOAHgKAMQgJAKAAAMIAAAOQAAANAJAJQAJALAPAHQAQAIAUAEQAVAFAYAAQAYAAAVgFQAVgEAQgIQAPgHAJgLQAJgJAAgNIAAgOQAAgMgJgKQgKgMgOgHQgQgHgVgFQgVgEgYAAQgYAAgVAEgEg3rAEaQgggHgVgOQgXgOgLgSQgLgTAAgVIAAgYQAAgUALgTQAMgTAWgNQAVgOAggHQAhgIAoAAQAoAAAgAIQAgAHAVAOQAWANAMATQALASAAAVIAAAYQAAAWgLASQgMATgWANQgVAOggAHQggAIgoAAQgoAAghgIgEg3RAB3QgVAFgPAHQgNAHgJALQgHAKAAAKIAAARQAAAKAHAKQAJALANAHQAPAIAVAEQAUAFAbAAQAaAAAVgFQAWgFANgHQAOgIAIgKQAIgKAAgKIAAgRQAAgLgIgJQgIgKgOgIQgNgGgWgGQgVgFgaAAQgbAAgUAFgANuEXIAAiGIkkAAIAAgzIFgAAIAAC5gEBd4AEWIAAiZIEeAAIAAg2IkhAAIAAgyIFcAAIAACYIkeAAIAAA3IEuAAIAAAygAaOEWIAAiMIEyAAIAAgpIk1AAIAAgxIFwAAIAACKIkyAAIAAArIFCAAIAAAxgAnoEWIAAiYIEoAAIAAg2IkrAAIAAgxIFlAAIAACXIkpAAIAAA2IE3AAIAAAygEhCnAEWIAAiLIExAAIAAgpIk0AAIAAgwIFvAAIAACJIkxAAIAAAqIFBAAIAAAxgEBZuAESIAAorIA7AAIAAIrgEBQ+AESIAAorIA7AAIAAIrgEAodAESIAAi/IjhAAIAAgzIH+AAIAAAzIjhAAIAAC/gAFMESIAAorIA7AAIAADeIBTAAIAAA0IhTAAIAAEZgEgkyAESIAAjwIA7AAIAABFIDlAAIAAhFIA7AAIAADwgEgj3ADfIDlAAIAAhGIjlAAgEhGHAESIAAk5IiAAAQgFAVgNAVQgLAUgbAYQgaAYgnAaQgpAbg9AjIgdgwQA1gdAhgWQAkgXAVgSQAXgTALgOQAMgQAFgQIjCAFIgBgyIDHgDIAAhXIi8AAIAAgyID3AAIAACLIB7AAIAAi9IA8AAIAAIrgEA3yAEMIAAiaIA7AAIAABmIEnAAIAAA0gA81EMIAAilIA8AAIAABxIE6AAIAAA0gEhUbADIQgggMgXgYQgYgXgNglQgNgkAAgvIAAhBQAAgvANgkQANglAYgXQAXgYAhgMQAggMAnAAQAmAAAhAMQAhAMAXAYQAYAZANAjQANAkAAAvIAABBQAAAvgNAkQgNAjgYAZQgXAYghAMQghAMgmAAQgnAAghgMgEhUCgCtQgVAIgQARQgPARgJAcQgIAaAAAnIAAA0QAAAoAIAZQAJAcAPARQARARAUAIQAWAJAZAAQAYAAAXgJQAVgIAQgRQAPgRAJgcQAIgcAAglIAAg0QAAglgIgcQgJgcgPgRQgQgRgVgIQgXgIgYAAQgYAAgXAIgEhbJADIQgggMgYgYQgXgXgNglQgNgiAAgxIAAhBQAAgxANgiQANglAXgXQAZgZAggLQAggMAnAAQAnAAAgAMQAgALAYAZQAXAXAOAlQANAkAAAvIAABBQAAAvgNAkQgOAlgXAXQgYAZggALQghAMgmAAQgnAAghgMgEhawgCtQgWAIgPARQgPARgJAcQgJAcAAAlIAAA0QAAAmAJAbQAJAcAPARQAPARAWAIQAWAJAZAAQAYAAAXgJQAVgIAPgRQAQgRAIgcQAJgbAAgmIAAg0QAAglgJgcQgIgcgQgRQgOgRgWgIQgXgIgYAAQgYAAgXAIgEhh3ADIQghgMgXgYQgYgZgMgjQgNgkAAgvIAAhBQAAgvANgkQAMgjAYgZQAXgYAhgMQAhgMAnAAQAnAAAgAMQAgAMAYAYQAXAXANAlQANAiAAAxIAABBQAAAxgNAiQgNAlgXAXQgYAYggAMQghAMgmAAQgnAAghgMgEhhegCtQgWAIgPARQgPARgJAcQgJAcAAAlIAAA0QAAAlAJAcQAJAcAPARQAPARAWAIQAWAJAZAAQAZAAAVgJQAVgIAQgRQAPgRAJgcQAJgbAAgmIAAg0QAAglgJgcQgJgcgPgRQgQgRgVgIQgWgIgYAAQgYAAgXAIgEBCEADIIAAgzIDhAAIAAhlQgigEgbgKQgfgMgTgQQgVgQgMgYQgMgYAAgcIAAgdQAAgfAOgaQAQgZAZgRQAagSAigKQAjgJAlAAQAkAAAkAJQAjAKAZASQAaARAOAZQAPAaAAAfIAAAdQAAAdgMAXQgMAXgWARQgVAQgdAMQgcAKgiAEIAABlIDhAAIAAAzgEBFTgDBQgWAFgTAMQgSAMgKAQQgKAQAAAUIAAAXQAAATAKARQAJAQATAMQATAMAWAGQAXAGAaAAQAaAAAXgGQAXgGASgMQATgMAJgQQAKgQAAgUIAAgXQAAgUgKgQQgKgQgSgMQgSgLgXgGQgXgGgaAAQgaAAgXAGgAyIDIIAAgzIDhAAIAAiDIicAAIAAj9IA8AAIAADLIE8AAIAAAyIigAAIAACDIDhAAIAAAzgAg0B6IBQAAIBDgBIAAg3QgZgDgUgJQgUgJgOgNQgOgMgHgQQgHgPAAgQIAAgXQAAgSAKgRQAIgRARgNQARgNAZgJQAZgHAgAAQAfAAAZAHQAaAJAQANQARANAKARQAJARAAASIAAAXQAAAggbAaQgZAZgyAJIAAA2QAmgBAlgDIBGgGIAFAxIhHAGQgiADgoACQgnACgzABIh5ABgABBhQQgUAQAAAUIAAAMQAAAUAUAOQAVAQAkAAQAkAAAUgQQAUgOAAgUIAAgMQAAgUgUgQQgUgPgkAAQglAAgUAPgEBTmABnIAygvQAagaARgUQAQgQAIgMQAJgOAFgMQAEgLADgPQABgOAAgQIAAhPIh3AAIAAg0IEoAAIAAA0Ih0AAIAABPQAAATACAMQABALAFAOQAGANAJAMQAKAOAQAQQAWAXASARIAvArIgnApIgzgxQgTgSgTgVIgXgaQgKgLgEgKIgBAAQgFALgHAKIhBBGQgXAYgfAcgEBLWgBQIC+AAIAAhqIjAAAIAAgzID7AAIAADQIi+AAIAAB2IBwgBIAvgCIAsgEIAtgFIAGAxIhZAKIg3ADIipAAgEA8KAB5IAAmSIA7AAIAAClIBPAAIAAA0IhPAAIAAC5gEA38ABBQgYgIgQgPQgQgOgJgTQgIgRAAgTIAAgSQAAgTAIgUQAJgTAQgNQAPgOAZgJQAXgJAiAAQAiAAAWAJQAZAJAQAOQAQAOAIATQAIASAAAUIAAASQAAAUgIAQQgIATgQAOQgSAPgXAIQgYAJggAAQggAAgZgJgEA4UgBfQgMAEgKAIQgJAIgFALQgEALAAALIAAAMQAAALAEAKQAFAJAJAJQAJAJAOAEQAPAFARAAQAQAAAQgFQAOgFAJgIQAJgJAEgJQAFgKAAgLIAAgMQAAgLgFgLQgEgLgJgIQgKgIgNgEQgNgFgTAAQgUAAgNAFgANvBBIAAlaIA7AAIAACSIBPAAIAAA0IhPAAIAACUgEg01AA6IAAlTIA7AAIAAFTgAJfAvQgZgJgPgNQgPgMgJgRQgHgRAAgRIAAgTQAAgSAHgRQAIgQAQgOQAQgOAYgIQAagIAgAAQAhAAAZAIQAYAIARAOQAPANAIARQAIATAAAQIAAATQAAAQgIASQgJASgOALQgPANgaAJQgZAJghAAQghAAgZgJgAJ5hkQgNAEgKAHQgJAIgEAIQgFAJAAAKIAAANQAAAJAFAJQAEAJAJAHQAIAGAPAEQAPAFARAAQATAAANgFQAPgDAIgHQAJgHAFgJQAEgJAAgJIAAgNQAAgKgEgJQgEgIgKgIQgJgHgNgEQgOgFgTAAQgSAAgOAFgA9+A2IAAgyIH+AAIAAAygEAzfAAuIAAlHIA7AAIAACGIBPAAIAAA0IhPAAIAACNgAWWAuIAAlHIA7AAIAACGIBQAAIAAA0IhQAAIAACNgEAtegAFQAZgSAegbQAcgYAOgOQAKgJAJgNQAIgLAEgKQAFgNACgLQACgRAAgMIAAhJIA8AAIABBgQAAAKAEALQADALAGAIQAFAHAMAMQAWAUAYAUIA1AoIgjAoQgdgUgQgOIgrgkQgOgLgJgKQgJgKgDgGIAAAAQgEAJgLAMQgIAKgSARIhcBNgAQVgFQAegWAagXQAcgYAOgOQALgLAIgLQAHgLAFgKQAEgLACgNQACgMAAgRIAAhJIA8AAIAABHIABAZQABAMADAJQACAJAHAKQAGAJALAKQAeAbARANQAZAVAbATIgjAoIhYhGQgOgLgJgKQgIgKgEgGIAAAAQgDAIgMANQgLANgPAOIhcBNgEg6jgCLIC9AAIAAhBIi/AAIAAgzID6AAIAACmIi9AAIAABCIBjAAICVgLIAFAxIgxAFIgwAEIgzACIikABgEgvRAAYIAAgyIDCAAIAAhtIA9AAIAABtIEAAAIAAAygAZFAKIAAgxIH/AAIAAAxgEggSAAIIAAh3IhtAAIAABlIkHAAIAAj3IA7AAIAABQICRAAIAAhQIA7AAIAABgIBtAAIAAh4IA7AAIAAEhgEglLgA9ICRAAIAAhBIiRAAgEhDwAAIIAAgxIH+AAIAAAxgAi/gEIAAkVIA5AAIAAEVgEBiWgAGIAAiTIieAAIAAgyICeAAIAAhOIA7AAIAAETgAkngGIAAh1IhGAAIAABjIjdAAIAAjtIA5AAIAABKIBrAAIAAhKIA5AAIAABYIBGAAIAAhlIA4AAIAAEMgAoRhJIBrAAIAAhBIhrAAgEAlfgBAQAqgQAbgMQAigPAegQQAOgIAMgJQALgIAHgLQAHgLADgNQADgMAAgSIAAgxIA7AAIAAAxQAAASADAMQADANAHALQAGAKALAJQAMAJAOAIQAfAQAhAPQAcAMApAQIgXAwQgugSgYgLIg6gcQgfgPgPgLQgPgLgGgLIgBAAQgFAKgQAMQgMAJgiASIg6AbQgkARgiANgEBcjgEEIA7AAIAACxIBDgBIA7gCIA4gEIA+gHIAGAxIg+AHQgmAEgaABIi3ADgA7KgrQghgJgXgPQgYgQgMgTQgMgUAAgYIAAgSQAAgWAMgVQAMgUAYgPQAXgQAhgIQAhgJAqAAQAqAAAhAJQAhAIAYAQQAWAOANAVQAMAVAAAWIAAASQAAAYgMAUQgNAUgWAPQgXAPgiAJQgfAIgsAAQgsAAgfgIgA6xjcQgVAFgRAJQgQAKgIALQgIALAAANIAAANQAAANAIALQAJAMAPAIQAOAIAYAHQAVAFAdAAQAdAAAVgFQAYgHAOgIQAOgIAKgMQAIgLAAgNIAAgNQAAgNgIgLQgJgLgPgKQgSgJgUgFQgXgFgbAAQgbAAgXAFgEgppgBDQAIggADghQADgfAAgZIAAgUIkzAAIAAgzIFwAAIgBBgIgOBngAb6hPQghgHgXgNQgVgLgOgTQgMgSAAgVIAAgOQAAgVAMgSQANgSAWgNQAYgNAggGQAigHApAAQApAAAhAHQAiAHAWAMQAXANANASQAMARAAAWIAAAOQAAAWgMARQgOATgWALQgVAMgjAIQghAHgpAAQgpAAgigHgAbtjXQgfAPAAATIAAAMQAAATAfAOQAfAPA5AAQA4AAAggPQAfgOAAgTIAAgMQAAgTgfgPQgfgOg5AAQg6AAgeAOgEhC2gBOIAAgwIBLAAIAAhaIhIAAIAAgwIGEAAIAAAwIhIAAIAABaIBLAAIAAAwgEhAxgB+ICAAAIAAhaIiAAAgAgoinIAAgzICEAAIAAhEIA7AAIAABEICAAAIAAAzgEA2UgCpIAAgzICDAAIAAhDIA7AAIAABDICBAAIAAAzgAH5itIAAgyICDAAIAAhCIA7AAIAABCICCAAIAAAyg");
	this.shape_2.setTransform(1029.525,396.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgICEIAAivIgnAAIAAgpQAbAAAPgNQAOgMAAgWIAnAAIAAEHg");
	this.shape_3.setTransform(572.525,318.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAfBkIAAhuQAAgZgGgLQgGgLgSAAQgMAAgKAIQgJAIAAAUIAAB5Ig4AAIAAjHIA4AAIAAANQAIgHAPgCQAOgEAPAAQAdAAASASQASASAAAkIAAB/g");
	this.shape_4.setTransform(546.925,321.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhABUQgXgTAAgnIAAgzQAAgoAXgSQAXgTApAAQArAAAWATQAWASAAAoIAAAzQAAAngWATQgWATgrAAQgpAAgXgTgAgfgXIAAAvQAAAeAfAAQAgAAgBgeIAAgvQABgeggAAQgfAAAAAeg");
	this.shape_5.setTransform(525.8,322.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgbCEIAAjDIA3AAIAADDgAgbhOIAAg1IA3AAIAAA1g");
	this.shape_6.setTransform(510.25,318.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAnCFIgggBQgNgCgKgFQgKgFgFgKQgHgKAAgRIAAheIgcAAIAAgyIAcAAIAAhIIA4AAIAABIIAxAAIAAAyIgxAAIAABYQAAAFAEABIAMACIAfAAIAAAwg");
	this.shape_7.setTransform(497.15,318.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgrBhQgRgFgKgJQgKgJgEgMQgEgMgBgOIA4AAQAAAIACAEQACAFAFACQAFADAGABIANABIANgBIALgCIAIgDQADgDAAgDQAAgJgHgEIgTgKIgkgQIgVgJQgLgFgIgGQgIgGgFgIQgFgIAAgLQAAgSAHgLQAHgLAMgGQALgGAQgDQAQgCAQAAQATAAAQADQAQADAMAIQAMAIAGANQAHAMAAAUIg3AAQAAgHgDgFQgDgFgFgDIgKgDIgMgBQgNAAgJACQgIADAAAHQAAAHAJAFIAYALIAsASIATAIQAHAFAGAGQAFAGADAJQADAJAAAMQAAAOgEAKQgEAKgKAGQgKAHgSACQgRADgbAAQgZAAgSgFg");
	this.shape_8.setTransform(478.975,321.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgjBhQgRgEgNgMQgMgLgIgTQgHgUAAgfQAAgaAHgTQAIgTAMgNQANgMARgGQARgFATAAQARAAAQAFQARAFANAKQAMAKAJAQQAIAQAAAWIAAAgIiAAAQACAUAIAKQAIAJAUAAQAOAAAKgFQAKgGAAgQIA3AAQgBAWgHAOQgJAOgMAIQgNAIgRAEQgQADgQAAQgTAAgRgEgAAmgbQgDgNgKgHQgKgGgMAAQgRAAgIAHQgHAGgDANIBGAAIAAAAg");
	this.shape_9.setTransform(458.65,321.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAfBjIAAgMQgIAGgPADQgOADgPAAQgdAAgSgSQgSgRAAglIAAh+IA4AAIAABtQAAAZAGALQAGAMASAAIAMgCQAGgDAEgDQAEgEADgHQACgIAAgJIAAh5IA4AAIAADGg");
	this.shape_10.setTransform(437.325,322.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AARCRIgIgUIgEAAIgFAAQgUAAgSgGQgSgFgNgLQgNgLgIgQQgHgPAAgUIAAhlQAAgTAHgQQAIgQANgKQANgLASgGQASgGAUAAQAVAAASAGQASAGANALQAOAKAGAQQAIAQAAATIAABlQAAAZgMATQgMASgVALIAOAfgAgShbQgHADgFAGQgGAGgCAHQgDAIAAAHIAABZQAAANAIAMQAHALAPAEIgMgeIAwAAIAHARQAFgFADgHQACgHAAgIIAAhZQAAgHgCgIQgDgHgFgGQgFgGgJgDQgHgEgLAAQgJAAgJAEg");
	this.shape_11.setTransform(414.8,319.475);

	this.text = new cjs.Text(" ", "35px '210 Darakbang B'", "#FFFFFF");
	this.text.lineHeight = 42;
	this.text.parent = this;
	this.text.setTransform(389.05,301.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2B294B").s().p("At3DsQg7AAgpgpQgqgqAAg7IAAi8QAAg6AqgqQApgpA7AAIbvAAQA7AAAqApQApAqAAA6IAAC8QAAA7gpAqQgqApg7AAg");
	this.shape_12.setTransform(494.25,320.275);

	this.instance_1 = new lib.Group_1();
	this.instance_1.setTransform(315.95,260);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1},{t:this.shape_12},{t:this.text},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},1).to({state:[]},1).wait(1));

	// Actions
	this.check_ans_timer_mc = new lib.show_timer_mc();
	this.check_ans_timer_mc.setTransform(-149.45,766);
	this.check_ans_timer_mc._off = true;

	this.timeline.addTween(cjs.Tween.get(this.check_ans_timer_mc).wait(1).to({_off:false},0).wait(2));

	// Layer_13
	this.btn_2 = new lib.cho_btn();
	this.btn_2.setTransform(1463.45,1362.55,1.1803,1.1777);
	new cjs.ButtonHelper(this.btn_2, 0, 1, 2, false, new lib.cho_btn(), 3);

	this.btn_1 = new lib.cho_btn();
	this.btn_1.setTransform(1027.15,1362.55,1.1803,1.1777);
	new cjs.ButtonHelper(this.btn_1, 0, 1, 2, false, new lib.cho_btn(), 3);

	this.btn_0 = new lib.cho_btn();
	this.btn_0.setTransform(583.85,1362.55,1.1803,1.1777);
	new cjs.ButtonHelper(this.btn_0, 0, 1, 2, false, new lib.cho_btn(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.btn_0},{t:this.btn_1},{t:this.btn_2}]},1).to({state:[]},1).wait(1));

	// Layer_2
	this.chos_btn_2 = new lib.chos_btn();
	this.chos_btn_2.setTransform(1464.05,1363.7);

	this.chos_btn_1 = new lib.chos_btn();
	this.chos_btn_1.setTransform(1027.75,1363.7);

	this.chos_btn_0 = new lib.chos_btn();
	this.chos_btn_0.setTransform(583.75,1363.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.chos_btn_0},{t:this.chos_btn_1},{t:this.chos_btn_2}]},1).to({state:[]},1).wait(1));

	// Layer_14
	this.ch_2_8 = new lib.chos_txt();
	this.ch_2_8.setTransform(1688.05,1109.1);

	this.ch_2_0 = new lib.chos_txt();
	this.ch_2_0.setTransform(238.05,1109.1);

	this.ch_2_7 = new lib.chos_txt();
	this.ch_2_7.setTransform(1506.8,1109.1);

	this.ch_2_1 = new lib.chos_txt();
	this.ch_2_1.setTransform(419.3,1109.1);

	this.ch_2_2 = new lib.chos_txt();
	this.ch_2_2.setTransform(600.55,1109.1);

	this.ch_2_6 = new lib.chos_txt();
	this.ch_2_6.setTransform(1325.55,1109.1);

	this.ch_2_5 = new lib.chos_txt();
	this.ch_2_5.setTransform(1144.3,1109.1);

	this.ch_2_4 = new lib.chos_txt();
	this.ch_2_4.setTransform(963.05,1109.1);

	this.ch_2_3 = new lib.chos_txt();
	this.ch_2_3.setTransform(781.8,1109.1);

	this.ch_1_8 = new lib.chos_txt();
	this.ch_1_8.setTransform(1688.05,926.6);

	this.ch_1_0 = new lib.chos_txt();
	this.ch_1_0.setTransform(238.05,926.6);

	this.ch_1_7 = new lib.chos_txt();
	this.ch_1_7.setTransform(1506.8,926.6);

	this.ch_1_1 = new lib.chos_txt();
	this.ch_1_1.setTransform(419.3,926.6);

	this.ch_1_2 = new lib.chos_txt();
	this.ch_1_2.setTransform(600.55,926.6);

	this.ch_1_6 = new lib.chos_txt();
	this.ch_1_6.setTransform(1325.55,926.6);

	this.ch_1_5 = new lib.chos_txt();
	this.ch_1_5.setTransform(1144.3,926.6);

	this.ch_1_4 = new lib.chos_txt();
	this.ch_1_4.setTransform(963.05,926.6);

	this.ch_1_3 = new lib.chos_txt();
	this.ch_1_3.setTransform(781.8,926.6);

	this.ch_0_8 = new lib.chos_txt();
	this.ch_0_8.setTransform(1688.05,745.75);

	this.ch_0_0 = new lib.chos_txt();
	this.ch_0_0.setTransform(238.05,745.75);

	this.ch_0_7 = new lib.chos_txt();
	this.ch_0_7.setTransform(1506.8,745.75);

	this.ch_0_1 = new lib.chos_txt();
	this.ch_0_1.setTransform(419.3,745.75);

	this.ch_0_2 = new lib.chos_txt();
	this.ch_0_2.setTransform(600.55,745.75);

	this.ch_0_6 = new lib.chos_txt();
	this.ch_0_6.setTransform(1325.55,745.75);

	this.ch_0_5 = new lib.chos_txt();
	this.ch_0_5.setTransform(1144.3,745.75);

	this.ch_0_4 = new lib.chos_txt();
	this.ch_0_4.setTransform(963.05,745.75);

	this.ch_0_3 = new lib.chos_txt();
	this.ch_0_3.setTransform(781.8,745.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.ch_0_3},{t:this.ch_0_4},{t:this.ch_0_5},{t:this.ch_0_6},{t:this.ch_0_2},{t:this.ch_0_1},{t:this.ch_0_7},{t:this.ch_0_0},{t:this.ch_0_8},{t:this.ch_1_3},{t:this.ch_1_4},{t:this.ch_1_5},{t:this.ch_1_6},{t:this.ch_1_2},{t:this.ch_1_1},{t:this.ch_1_7},{t:this.ch_1_0},{t:this.ch_1_8},{t:this.ch_2_3},{t:this.ch_2_4},{t:this.ch_2_5},{t:this.ch_2_6},{t:this.ch_2_2},{t:this.ch_2_1},{t:this.ch_2_7},{t:this.ch_2_0},{t:this.ch_2_8}]},1).wait(2));

	// start
	this.start_btn = new lib.hit_btn();
	this.start_btn.setTransform(1026.65,1244,1.1139,0.9471);
	new cjs.ButtonHelper(this.start_btn, 0, 1, 2, false, new lib.hit_btn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.start_btn).to({_off:true},1).wait(2));

	// Artboard_5_jpg
	this.instance_2 = new lib.Artboard5();
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).wait(1));

	// Layer_3
	this.instance_3 = new lib.lite_bg();
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).to({_off:true},1).wait(1));

	// Layer_4
	this.bgdes = new lib.bg();
	this.bgdes.setTransform(1024,768,1,1,0,0,0,1024,768);

	this.timeline.addTween(cjs.Tween.get(this.bgdes).to({_off:true},1).wait(2));

	// Artboard_1_jpg
	this.instance_4 = new lib.Artboard1();

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:true},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(704,448.2,3765,1408.5);
// library properties:
lib.properties = {
	id: '8D695CBD2ACF4276A87C94C39AF649A2',
	width: 2048,
	height: 1536,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Group.png", id:"Group"},
		{src:"images/Group_1.png", id:"Group_1"},
		{src:"images/Group_0.png", id:"Group_0"},
		{src:"images/Group_1_1.png", id:"Group_1_1"},
		{src:"images/Image.png", id:"Image"},
		{src:"images/Artboard1.jpg", id:"Artboard1"},
		{src:"images/Artboard5.jpg", id:"Artboard5"},
		{src:"images/Artboard3.jpg", id:"Artboard3"},
		{src:"images/lite_bg.png", id:"lite_bg"},
		{src:"images/ribbon.png", id:"ribbon"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8D695CBD2ACF4276A87C94C39AF649A2'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;